/**
 * AuthContext.tsx — Contexto global de autenticação.
 *
 * FONTE DA VERDADE: _liveSession
 * ─────────────────────────────────────────────────────────────────────────────
 * `supabase.auth.getSession()` lê do localStorage e pode retornar tokens
 * expirados ou divergentes do estado interno do SDK. Isso criava uma série
 * de race conditions:
 *
 *   1. INITIAL_SESSION dispara com token expirado do localStorage
 *   2. `getSession()` retorna esse token (ou um token diferente do SDK)
 *   3. Requests saem com token inválido → gateway rejeita com "Invalid JWT"
 *   4. `refreshSession()` falha com "Auth session missing!" (SDK já limpou)
 *
 * SOLUÇÃO: `_liveSession` — variável de módulo atualizada SINCRONAMENTE
 * apenas pelo `onAuthStateChange`. É a única fonte confiável do estado real
 * da sessão. `getLiveSession()` é exportada para uso em `auth.ts`.
 *
 * REGRAS:
 *   • O callback de `onAuthStateChange` DEVE ser síncrono. O SDK não faz
 *     await em callbacks assíncronos.
 *   • INITIAL_SESSION com token expirado é ignorado (não atualiza _liveSession
 *     nem o estado React) — aguarda TOKEN_REFRESHED ou SIGNED_OUT.
 *   • Todos os demais eventos atualizam _liveSession imediatamente.
 * ─────────────────────────────────────────────────────────────────────────────
 */

import {
  createContext,
  useContext,
  useEffect,
  useState,
  useCallback,
  useMemo,
  useRef,
  ReactNode,
} from 'react';
import { createClient, SupabaseClient, Session } from '@supabase/supabase-js';
import { projectId, publicAnonKey } from '/utils/supabase/info';

const supabaseUrl = `https://${projectId}.supabase.co`;

// Singleton — mesmo objeto em todo o ciclo de vida da aplicação
export const supabase: SupabaseClient = createClient(supabaseUrl, publicAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
    detectSessionInUrl: true,
  },
});

// ─── _liveSession: fonte da verdade ──────────────────────────────────────────
//
// Atualizada APENAS por onAuthStateChange (não por getSession()).
// Nunca contém um token expirado do INITIAL_SESSION.
// Sempre reflete o estado interno real do SDK Supabase.

let _liveSession: Session | null = null;

/** Retorna a sessão atual confirmada pelo SDK (nunca stale do localStorage). */
export function getLiveSession(): Session | null {
  return _liveSession;
}

// ─── Tipos ────────────────────────────────────────────────────────────────────

export interface AuthUser {
  id: string;
  email: string;
  name: string;
  role: 'admin' | 'member';
  permissions?: string[];
}

interface AuthContextType {
  user: AuthUser | null;
  session: Session | null;
  loading: boolean;
  signIn: (email: string, password: string) => Promise<{ error: string | null }>;
  signOut: () => Promise<void>;
  isAdmin: boolean;
}

const AuthContext = createContext<AuthContextType | null>(null);

// ─── Helpers síncronos ────────────────────────────────────────────────────────

function decodeJwtPayload(jwt: string): Record<string, unknown> | null {
  try {
    const parts = jwt.split('.');
    if (parts.length !== 3) return null;
    const b64 = parts[1].replace(/-/g, '+').replace(/_/g, '/');
    const padded = b64 + '='.repeat((4 - (b64.length % 4)) % 4);
    return JSON.parse(atob(padded));
  } catch {
    return null;
  }
}

/** True se o token expirou (comparando claim `exp` com Date.now()). */
function isJwtExpired(jwt: string): boolean {
  const p = decodeJwtPayload(jwt);
  if (typeof p?.exp !== 'number') return false;
  return p.exp < Math.floor(Date.now() / 1000);
}

/**
 * True se o token está expirado OU tem menos de 90 segundos restantes.
 * Usado no INITIAL_SESSION: tokens quase-expirados forçam o SDK a renovar
 * antes de liberar a UI, evitando "Invalid JWT" por clock-skew no gateway.
 */
function isJwtNearlyExpired(jwt: string): boolean {
  const p = decodeJwtPayload(jwt);
  if (typeof p?.exp !== 'number') return false;
  const secsLeft = (p.exp as number) - Math.floor(Date.now() / 1000);
  return secsLeft < 90; // expirado OU menos de 90s → aguardar renovação
}

function parseUser(supabaseUser: any): AuthUser | null {
  if (!supabaseUser) return null;
  return {
    id: supabaseUser.id,
    email: supabaseUser.email || '',
    name:
      supabaseUser.user_metadata?.name ||
      supabaseUser.email?.split('@')[0] ||
      'Usuário',
    role: supabaseUser.user_metadata?.role || 'member',
    permissions: supabaseUser.user_metadata?.permissions || [],
  };
}

// ─── Provider ─────────────────────────────────────────────────────────────────

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [session, setSession] = useState<Session | null>(null);
  const [loading, setLoading] = useState(true);
  const mountedRef = useRef(true);

  useEffect(() => {
    mountedRef.current = true;

    const {
      data: { subscription },
    } = supabase.auth.onAuthStateChange((event, newSession) => {
      if (!mountedRef.current) return;

      // ── Correção da race condition de startup ────────────────────────────
      // INITIAL_SESSION com token expirado: o SDK ainda vai tentar renovar.
      // Permanecer em loading=true até TOKEN_REFRESHED ou SIGNED_OUT chegue.
      // NÃO atualizar _liveSession com token expirado.
      if (
        event === 'INITIAL_SESSION' &&
        newSession?.access_token &&
        isJwtNearlyExpired(newSession.access_token)  // inclui quase-expirado (<90s)
      ) {
        const p = decodeJwtPayload(newSession.access_token);
        const secsLeft = typeof p?.exp === 'number'
          ? (p.exp as number) - Math.floor(Date.now() / 1000)
          : 0;
        console.log(
          `[AuthContext] INITIAL_SESSION com token quase/expirado (${secsLeft}s restantes) ` +
          '— aguardando SDK renovar…'
        );
        // _liveSession permanece null. loading permanece true.
        return;
      }

      // ── Evento terminal: atualizar tudo ────────────────────────────────────
      // Todos os outros eventos (INITIAL_SESSION válido, TOKEN_REFRESHED,
      // SIGNED_IN, SIGNED_OUT, USER_UPDATED) são estados definitivos.
      _liveSession = newSession;
      setSession(newSession);
      setUser(parseUser(newSession?.user ?? null));
      setLoading(false);

      console.log(`[AuthContext] Evento: ${event} | sessão: ${newSession ? 'presente' : 'null'}`);
    });

    // Fallback: se nenhum evento terminal chegar em 12s (sem rede, etc.)
    const fallback = setTimeout(() => {
      if (!mountedRef.current) return;
      setLoading((prev) => {
        if (prev) {
          console.warn('[AuthContext] Timeout 12s sem evento — forçando loading=false');
        }
        return false;
      });
    }, 12_000);

    return () => {
      mountedRef.current = false;
      subscription.unsubscribe();
      clearTimeout(fallback);
    };
  }, []);

  const signIn = useCallback(
    async (email: string, password: string): Promise<{ error: string | null }> => {
      try {
        const { error } = await supabase.auth.signInWithPassword({ email, password });
        if (error) return { error: error.message };
        return { error: null };
      } catch (err: any) {
        return { error: err.message || 'Erro ao fazer login' };
      }
    },
    []
  );

  const signOut = useCallback(async () => {
    await supabase.auth.signOut();
  }, []);

  const value = useMemo<AuthContextType>(
    () => ({
      user,
      session,
      loading,
      signIn,
      signOut,
      isAdmin: user?.role === 'admin',
    }),
    [user, session, loading, signIn, signOut]
  );

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

// ─── Hook ─────────────────────────────────────────────────────────────────────

export function useAuth(): AuthContextType {
  const ctx = useContext(AuthContext);
  if (!ctx) {
    throw new Error(
      '[useAuth] Chamado fora do AuthProvider. ' +
        'Verifique se o componente está dentro da árvore do RootLayout em routes.tsx.'
    );
  }
  return ctx;
}