import { useState, useEffect, useMemo } from "react";
import {
  TrendingUp, TrendingDown, DollarSign, AlertCircle, Plus,
  RefreshCw, CheckCircle2, Clock, XCircle, Edit2, Trash2,
  ChevronDown, X, ArrowUpRight, ArrowDownRight, Wallet,
} from "lucide-react";
import { projectId } from "/utils/supabase/info";
import { fetchWithAuth } from "../../utils/auth";

const API = `https://${projectId}.supabase.co/functions/v1/make-server-cee56a32`;

// ─── Types ────────────────────────────────────────────────────────────────────
export type EntryType = "receivable" | "payable";
export type EntryStatus = "pending" | "paid";

export interface FinancialEntry {
  id: string;
  type: EntryType;
  description: string;
  amount: number;
  dueDate: string;
  category: string;
  clientOrSupplier: string;
  notes: string;
  recurrence: "none" | "monthly";
  status: EntryStatus;
  paidAt: string | null;
  createdAt: string;
  updatedAt: string;
}

// ─── Constants ──────────────────────────────────────────────────────────────
const RECEIVABLE_CATEGORIES = [
  "Desenvolvimento Web", "Manutenção Mensal", "Consultoria", "Social Media",
  "SEO / Tráfego", "Design", "Hospedagem", "Outros",
];
const PAYABLE_CATEGORIES = [
  "Ferramentas / Software", "Marketing", "Freelancer", "Infraestrutura",
  "Impostos / Taxas", "Aluguel / Escritório", "Outros",
];

const PIE_COLORS = [
  "#10b981", "#3b82f6", "#8b5cf6", "#f59e0b",
  "#ef4444", "#06b6d4", "#ec4899", "#84cc16",
];

const MONTHS_PT = ["Jan", "Fev", "Mar", "Abr", "Mai", "Jun",
  "Jul", "Ago", "Set", "Out", "Nov", "Dez"];

// ─── Helpers ──────────────────────────────────────────────────────────────────
function formatBRL(value: number) {
  return value.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

function isOverdue(entry: FinancialEntry): boolean {
  if (entry.status === "paid") return false;
  return new Date(entry.dueDate) < new Date(new Date().toDateString());
}

function getEffectiveStatus(entry: FinancialEntry): "paid" | "overdue" | "pending" {
  if (entry.status === "paid") return "paid";
  if (isOverdue(entry)) return "overdue";
  return "pending";
}

function formatDate(iso: string) {
  try {
    const [y, m, d] = iso.split("-");
    return `${d}/${m}/${y}`;
  } catch { return iso; }
}

function todayISO() {
  return new Date().toISOString().split("T")[0];
}

// ─── Custom Bar Chart ─────────────────────────────────────────────────────────
interface BarData { label: string; receber: number; pagar: number; }

function CustomBarChart({ data }: { data: BarData[] }) {
  const [tooltip, setTooltip] = useState<{ x: number; y: number; item: BarData } | null>(null);
  const maxVal = Math.max(...data.flatMap(d => [d.receber, d.pagar]), 1);

  return (
    <div className="relative">
      <div className="flex items-end gap-2 h-48 px-2">
        {data.map((item) => {
          const rH = Math.round((item.receber / maxVal) * 100);
          const pH = Math.round((item.pagar / maxVal) * 100);
          return (
            <div
              key={item.label}
              className="flex-1 flex flex-col items-center gap-1 group cursor-pointer"
              onMouseEnter={e => {
                const rect = (e.currentTarget as HTMLElement).getBoundingClientRect();
                const parent = (e.currentTarget as HTMLElement).closest('.relative')!.getBoundingClientRect();
                setTooltip({ x: rect.left - parent.left + rect.width / 2, y: rect.top - parent.top, item });
              }}
              onMouseLeave={() => setTooltip(null)}
            >
              <div className="w-full flex items-end gap-0.5 h-40">
                <div
                  className="flex-1 bg-emerald-500 rounded-t-md transition-all duration-300 group-hover:bg-emerald-400"
                  style={{ height: `${rH}%`, minHeight: rH > 0 ? 2 : 0 }}
                />
                <div
                  className="flex-1 bg-rose-500 rounded-t-md transition-all duration-300 group-hover:bg-rose-400"
                  style={{ height: `${pH}%`, minHeight: pH > 0 ? 2 : 0 }}
                />
              </div>
              <span className="text-[10px] text-zinc-500 font-medium whitespace-nowrap">{item.label}</span>
            </div>
          );
        })}
      </div>

      {/* Y-axis hint */}
      <div className="absolute left-0 top-0 h-40 flex flex-col justify-between pointer-events-none pl-1">
        <span className="text-[9px] text-zinc-600">{formatBRL(maxVal).replace(",00", "")}</span>
        <span className="text-[9px] text-zinc-600">{formatBRL(maxVal / 2).replace(",00", "")}</span>
        <span className="text-[9px] text-zinc-600">R$0</span>
      </div>

      {/* Tooltip */}
      {tooltip && (
        <div
          className="absolute z-20 bg-zinc-800 border border-zinc-700 rounded-xl px-3 py-2 shadow-xl text-xs pointer-events-none -translate-x-1/2 -translate-y-full"
          style={{ left: tooltip.x, top: tooltip.y - 8 }}
        >
          <p className="font-bold text-zinc-200 mb-1">{tooltip.item.label}</p>
          <p className="text-emerald-400 font-semibold">A Receber: {formatBRL(tooltip.item.receber)}</p>
          <p className="text-rose-400 font-semibold">A Pagar: {formatBRL(tooltip.item.pagar)}</p>
        </div>
      )}
    </div>
  );
}

// ─── Custom Donut Chart ───────────────────────────────────────────────────────
interface PieData { name: string; value: number; }

function CustomDonutChart({ data }: { data: PieData[] }) {
  const [hovered, setHovered] = useState<number | null>(null);
  const total = data.reduce((s, d) => s + d.value, 0);
  const size = 160;
  const cx = size / 2;
  const cy = size / 2;
  const R = 60;
  const r = 36;

  // Build arc paths
  const arcs: { path: string; color: string; item: PieData; midAngle: number }[] = [];
  let angle = -Math.PI / 2;

  data.forEach((item, i) => {
    const sweep = (item.value / total) * 2 * Math.PI;
    const endAngle = angle + sweep;
    const midAngle = angle + sweep / 2;

    const x1 = cx + R * Math.cos(angle);
    const y1 = cy + R * Math.sin(angle);
    const x2 = cx + R * Math.cos(endAngle);
    const y2 = cy + R * Math.sin(endAngle);
    const ix1 = cx + r * Math.cos(endAngle);
    const iy1 = cy + r * Math.sin(endAngle);
    const ix2 = cx + r * Math.cos(angle);
    const iy2 = cy + r * Math.sin(angle);
    const large = sweep > Math.PI ? 1 : 0;

    const path = [
      `M ${x1} ${y1}`,
      `A ${R} ${R} 0 ${large} 1 ${x2} ${y2}`,
      `L ${ix1} ${iy1}`,
      `A ${r} ${r} 0 ${large} 0 ${ix2} ${iy2}`,
      "Z",
    ].join(" ");

    arcs.push({ path, color: PIE_COLORS[i % PIE_COLORS.length], item, midAngle });
    angle = endAngle;
  });

  const hoveredItem = hovered !== null ? data[hovered] : null;

  return (
    <div className="flex items-center gap-4">
      <div className="shrink-0 relative" style={{ width: size, height: size }}>
        <svg width={size} height={size}>
          {arcs.map((arc, i) => {
            const isHov = hovered === i;
            const scale = isHov ? 1.05 : 1;
            return (
              <path
                key={`arc-${i}-${arc.item.name}`}
                d={arc.path}
                fill={arc.color}
                opacity={hovered !== null && !isHov ? 0.5 : 1}
                transform={`scale(${scale})`}
                style={{ transformOrigin: `${cx}px ${cy}px`, transition: "all 0.15s ease", cursor: "pointer" }}
                onMouseEnter={() => setHovered(i)}
                onMouseLeave={() => setHovered(null)}
              />
            );
          })}
          {/* Center text */}
          <text x={cx} y={cy - 6} textAnchor="middle" fill="#f4f4f5" fontSize={10} fontWeight="600">
            {hoveredItem ? hoveredItem.name.split(" ")[0] : "Total"}
          </text>
          <text x={cx} y={cy + 10} textAnchor="middle" fill={hoveredItem ? PIE_COLORS[hovered!] : "#a1a1aa"} fontSize={9}>
            {hoveredItem ? formatBRL(hoveredItem.value) : formatBRL(total)}
          </text>
        </svg>
      </div>
      <div className="flex-1 space-y-2 min-w-0">
        {data.slice(0, 6).map((item, i) => (
          <div
            key={`legend-${item.name}`}
            className="flex items-center justify-between text-xs cursor-pointer"
            onMouseEnter={() => setHovered(i)}
            onMouseLeave={() => setHovered(null)}
          >
            <span className="flex items-center gap-1.5 text-zinc-400 min-w-0">
              <span className="w-2 h-2 rounded-full shrink-0" style={{ background: PIE_COLORS[i % PIE_COLORS.length] }} />
              <span className="truncate">{item.name}</span>
            </span>
            <span className="font-semibold text-zinc-300 ml-2 shrink-0">{formatBRL(item.value)}</span>
          </div>
        ))}
      </div>
    </div>
  );
}

// ─── Status Badge ─────────────────────────────────────────────────────────────
function StatusBadge({ entry }: { entry: FinancialEntry }) {
  const s = getEffectiveStatus(entry);
  if (s === "paid") return (
    <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-1 rounded-full bg-emerald-500/10 text-emerald-400 border border-emerald-500/20">
      <CheckCircle2 className="w-3 h-3" /> Pago
    </span>
  );
  if (s === "overdue") return (
    <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-1 rounded-full bg-rose-500/10 text-rose-400 border border-rose-500/20">
      <XCircle className="w-3 h-3" /> Vencido
    </span>
  );
  return (
    <span className="inline-flex items-center gap-1 text-[11px] font-bold px-2.5 py-1 rounded-full bg-amber-500/10 text-amber-400 border border-amber-500/20">
      <Clock className="w-3 h-3" /> Pendente
    </span>
  );
}

// ─── Summary Card ─────────────────────────────────────────────────────────────
function SummaryCard({
  label, value, sub, icon, color,
}: {
  label: string; value: string; sub?: string;
  icon: React.ReactNode; color: string;
}) {
  return (
    <div className={`bg-zinc-900 rounded-2xl border p-5 flex items-start gap-4 shadow-xl shadow-black/20 ${color}`}>
      <div className={`w-12 h-12 rounded-xl flex items-center justify-center shrink-0 border ${color}`}>
        {icon}
      </div>
      <div className="min-w-0">
        <p className="text-xs font-semibold text-zinc-400 uppercase tracking-wider">{label}</p>
        <p className="text-2xl font-bold text-zinc-50 mt-1 leading-tight truncate">{value}</p>
        {sub && <p className="text-xs text-zinc-500 mt-0.5">{sub}</p>}
      </div>
    </div>
  );
}

// ─── Entry Row ────────────────────────────────────────────────────────────────
function EntryRow({
  entry, onMarkPaid, onEdit, onDelete,
}: {
  entry: FinancialEntry;
  onMarkPaid: (e: FinancialEntry) => void;
  onEdit: (e: FinancialEntry) => void;
  onDelete: (e: FinancialEntry) => void;
}) {
  const isR = entry.type === "receivable";
  const overdue = isOverdue(entry);

  return (
    <tr className="border-b border-zinc-800/60 hover:bg-zinc-800/20 transition-colors group">
      <td className="px-4 py-3.5">
        <p className="text-sm font-semibold text-zinc-100">{entry.description}</p>
        {entry.clientOrSupplier && (
          <p className="text-xs text-zinc-500 mt-0.5">{entry.clientOrSupplier}</p>
        )}
      </td>
      <td className="px-4 py-3.5 hidden md:table-cell">
        <span className="text-xs px-2 py-1 rounded-lg bg-zinc-800 text-zinc-300 border border-zinc-700">
          {entry.category}
        </span>
      </td>
      <td className="px-4 py-3.5">
        <span className={`text-sm font-bold ${isR ? "text-emerald-400" : "text-rose-400"}`}>
          {isR ? "+" : "-"}{formatBRL(entry.amount)}
        </span>
      </td>
      <td className="px-4 py-3.5 hidden sm:table-cell">
        <span className={`text-xs font-medium ${overdue && entry.status !== "paid" ? "text-rose-400 font-bold" : "text-zinc-400"}`}>
          {formatDate(entry.dueDate)}
          {overdue && entry.status !== "paid" && " ⚠"}
        </span>
      </td>
      <td className="px-4 py-3.5">
        <StatusBadge entry={entry} />
      </td>
      <td className="px-4 py-3.5">
        <div className="flex items-center gap-1 justify-end opacity-0 group-hover:opacity-100 transition-opacity">
          {entry.status !== "paid" && (
            <button
              onClick={() => onMarkPaid(entry)}
              className="p-1.5 text-zinc-500 hover:text-emerald-400 hover:bg-emerald-500/10 rounded-lg transition-all"
              title="Marcar como Pago"
            >
              <CheckCircle2 className="w-4 h-4" />
            </button>
          )}
          <button
            onClick={() => onEdit(entry)}
            className="p-1.5 text-zinc-500 hover:text-blue-400 hover:bg-blue-500/10 rounded-lg transition-all"
            title="Editar"
          >
            <Edit2 className="w-4 h-4" />
          </button>
          <button
            onClick={() => onDelete(entry)}
            className="p-1.5 text-zinc-500 hover:text-rose-400 hover:bg-rose-500/10 rounded-lg transition-all"
            title="Excluir"
          >
            <Trash2 className="w-4 h-4" />
          </button>
        </div>
      </td>
    </tr>
  );
}

// ─── Entry Modal ──────────────────────────────────────────────────────────────
function EntryModal({
  isOpen, onClose, onSave, editing, defaultType,
}: {
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: Partial<FinancialEntry>) => void;
  editing: FinancialEntry | null;
  defaultType: EntryType;
}) {
  const [form, setForm] = useState<Partial<FinancialEntry>>({});
  const [saving, setSaving] = useState(false);

  useEffect(() => {
    if (editing) {
      setForm({ ...editing });
    } else {
      setForm({
        type: defaultType,
        description: "",
        amount: undefined,
        dueDate: todayISO(),
        category: defaultType === "receivable" ? RECEIVABLE_CATEGORIES[0] : PAYABLE_CATEGORIES[0],
        clientOrSupplier: "",
        notes: "",
        recurrence: "none",
      });
    }
  }, [editing, isOpen, defaultType]);

  if (!isOpen) return null;

  const categories = form.type === "receivable" ? RECEIVABLE_CATEGORIES : PAYABLE_CATEGORIES;
  const isR = form.type === "receivable";

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.description || !form.amount || !form.dueDate) return;
    setSaving(true);
    await onSave(form);
    setSaving(false);
    onClose();
  };

  const field = (key: keyof FinancialEntry, value: any) =>
    setForm(prev => ({ ...prev, [key]: value }));

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-zinc-950/80 backdrop-blur-sm p-4">
      <div className="bg-zinc-900 border border-zinc-800 rounded-2xl shadow-2xl w-full max-w-lg flex flex-col overflow-hidden ring-1 ring-white/5 max-h-[90vh]">
        {/* Header */}
        <div className={`px-6 py-4 border-b border-zinc-800 flex items-center justify-between ${isR ? "bg-emerald-500/5" : "bg-rose-500/5"}`}>
          <div className="flex items-center gap-3">
            <div className={`w-8 h-8 rounded-xl flex items-center justify-center ${isR ? "bg-emerald-500/15 text-emerald-400" : "bg-rose-500/15 text-rose-400"}`}>
              {isR ? <ArrowUpRight className="w-4 h-4" /> : <ArrowDownRight className="w-4 h-4" />}
            </div>
            <h2 className="text-base font-bold text-zinc-50">
              {editing ? "Editar Lançamento" : isR ? "Nova Conta a Receber" : "Nova Conta a Pagar"}
            </h2>
          </div>
          <button onClick={onClose} className="p-1.5 text-zinc-500 hover:text-zinc-200 hover:bg-zinc-800 rounded-lg transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto p-6 space-y-4">
          {/* Type toggle (only on new) */}
          {!editing && (
            <div>
              <label className="block text-xs font-bold text-zinc-400 uppercase tracking-wider mb-2">Tipo</label>
              <div className="flex gap-2">
                <button type="button"
                  onClick={() => { field("type", "receivable"); field("category", RECEIVABLE_CATEGORIES[0]); }}
                  className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-semibold border transition-all ${form.type === "receivable" ? "bg-emerald-600 border-emerald-500 text-white" : "border-zinc-700 text-zinc-400 hover:border-zinc-600"}`}
                >
                  <ArrowUpRight className="w-4 h-4" /> A Receber
                </button>
                <button type="button"
                  onClick={() => { field("type", "payable"); field("category", PAYABLE_CATEGORIES[0]); }}
                  className={`flex-1 flex items-center justify-center gap-2 py-2.5 rounded-xl text-sm font-semibold border transition-all ${form.type === "payable" ? "bg-rose-600 border-rose-500 text-white" : "border-zinc-700 text-zinc-400 hover:border-zinc-600"}`}
                >
                  <ArrowDownRight className="w-4 h-4" /> A Pagar
                </button>
              </div>
            </div>
          )}

          {/* Description */}
          <div>
            <label className="block text-xs font-bold text-zinc-400 uppercase tracking-wider mb-1.5">Descrição *</label>
            <input
              required
              value={form.description || ""}
              onChange={e => field("description", e.target.value)}
              placeholder="Ex: Desenvolvimento site cliente X"
              className="w-full px-3 py-2.5 bg-zinc-950/60 border border-zinc-800 rounded-xl text-sm text-zinc-50 placeholder-zinc-600 focus:outline-none focus:ring-2 focus:ring-emerald-500/40 focus:border-emerald-500 transition-all"
            />
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-zinc-400 uppercase tracking-wider mb-1.5">Valor (R$) *</label>
              <input
                required
                type="number"
                min="0.01"
                step="0.01"
                value={form.amount ?? ""}
                onChange={e => field("amount", parseFloat(e.target.value))}
                placeholder="0,00"
                className="w-full px-3 py-2.5 bg-zinc-950/60 border border-zinc-800 rounded-xl text-sm text-zinc-50 placeholder-zinc-600 focus:outline-none focus:ring-2 focus:ring-emerald-500/40 focus:border-emerald-500 transition-all"
              />
            </div>
            <div>
              <label className="block text-xs font-bold text-zinc-400 uppercase tracking-wider mb-1.5">Vencimento *</label>
              <input
                required
                type="date"
                value={form.dueDate || ""}
                onChange={e => field("dueDate", e.target.value)}
                className="w-full px-3 py-2.5 bg-zinc-950/60 border border-zinc-800 rounded-xl text-sm text-zinc-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/40 focus:border-emerald-500 transition-all [color-scheme:dark]"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-3">
            <div>
              <label className="block text-xs font-bold text-zinc-400 uppercase tracking-wider mb-1.5">Categoria</label>
              <div className="relative">
                <select
                  value={form.category || ""}
                  onChange={e => field("category", e.target.value)}
                  className="w-full px-3 py-2.5 bg-zinc-950/60 border border-zinc-800 rounded-xl text-sm text-zinc-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/40 focus:border-emerald-500 transition-all appearance-none cursor-pointer"
                >
                  {categories.map(c => <option key={c} value={c}>{c}</option>)}
                </select>
                <ChevronDown className="absolute right-3 top-3 w-4 h-4 text-zinc-500 pointer-events-none" />
              </div>
            </div>
            <div>
              <label className="block text-xs font-bold text-zinc-400 uppercase tracking-wider mb-1.5">Recorrência</label>
              <div className="relative">
                <select
                  value={form.recurrence || "none"}
                  onChange={e => field("recurrence", e.target.value)}
                  className="w-full px-3 py-2.5 bg-zinc-950/60 border border-zinc-800 rounded-xl text-sm text-zinc-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/40 focus:border-emerald-500 transition-all appearance-none cursor-pointer"
                >
                  <option value="none">Única vez</option>
                  <option value="monthly">Mensal</option>
                </select>
                <ChevronDown className="absolute right-3 top-3 w-4 h-4 text-zinc-500 pointer-events-none" />
              </div>
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-zinc-400 uppercase tracking-wider mb-1.5">
              {isR ? "Cliente" : "Fornecedor"}
            </label>
            <input
              value={form.clientOrSupplier || ""}
              onChange={e => field("clientOrSupplier", e.target.value)}
              placeholder={isR ? "Nome do cliente" : "Nome do fornecedor"}
              className="w-full px-3 py-2.5 bg-zinc-950/60 border border-zinc-800 rounded-xl text-sm text-zinc-50 placeholder-zinc-600 focus:outline-none focus:ring-2 focus:ring-emerald-500/40 focus:border-emerald-500 transition-all"
            />
          </div>

          <div>
            <label className="block text-xs font-bold text-zinc-400 uppercase tracking-wider mb-1.5">Observações</label>
            <textarea
              value={form.notes || ""}
              onChange={e => field("notes", e.target.value)}
              rows={2}
              placeholder="Detalhes adicionais..."
              className="w-full px-3 py-2.5 bg-zinc-950/60 border border-zinc-800 rounded-xl text-sm text-zinc-50 placeholder-zinc-600 focus:outline-none focus:ring-2 focus:ring-emerald-500/40 focus:border-emerald-500 transition-all resize-none"
            />
          </div>
        </form>

        <div className="border-t border-zinc-800 bg-zinc-900/50 px-6 py-4 flex gap-3">
          <button
            type="submit"
            onClick={handleSubmit}
            disabled={saving || !form.description || !form.amount || !form.dueDate}
            className={`flex-1 py-2.5 rounded-xl text-sm font-semibold text-white transition-all disabled:opacity-50 disabled:cursor-not-allowed shadow-lg ${isR ? "bg-emerald-600 hover:bg-emerald-500 shadow-emerald-900/20" : "bg-rose-600 hover:bg-rose-500 shadow-rose-900/20"}`}
          >
            {saving ? "Salvando..." : editing ? "Salvar Alterações" : "Criar Lançamento"}
          </button>
          <button
            onClick={onClose}
            className="px-4 py-2.5 border border-zinc-700 bg-zinc-800 text-zinc-300 rounded-xl text-sm font-medium hover:bg-zinc-700 hover:text-white transition-colors"
          >
            Cancelar
          </button>
        </div>
      </div>
    </div>
  );
}

// ─── Main Component ───────────────────────────────────────────────────────────
type Tab = "overview" | "receivable" | "payable";

import { useAuth } from '../../context/AuthContext';
import { Shield } from 'lucide-react';

export function Financeiro() {
  const { isAdmin, loading: authLoading } = useAuth();
  const [entries, setEntries] = useState<FinancialEntry[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [tab, setTab] = useState<Tab>("overview");
  const [filterStatus, setFilterStatus] = useState<"all" | "pending" | "paid" | "overdue">("all");
  const [modalOpen, setModalOpen] = useState(false);
  const [editing, setEditing] = useState<FinancialEntry | null>(null);
  const [defaultType, setDefaultType] = useState<EntryType>("receivable");
  const [confirmDelete, setConfirmDelete] = useState<FinancialEntry | null>(null);

  const load = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetchWithAuth(`${API}/financeiro/entries`);
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || "Erro ao carregar");
      setEntries(data.entries || []);
    } catch (e: any) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (authLoading) return;
    load();
  }, [authLoading]);

  const handleSave = async (form: Partial<FinancialEntry>) => {
    if (editing) {
      const res = await fetchWithAuth(`${API}/financeiro/entries/${encodeURIComponent(editing.id)}`, {
        method: "PUT", body: JSON.stringify(form),
      });
      const data = await res.json();
      if (res.ok) setEntries(prev => prev.map(e => e.id === editing.id ? data.entry : e));
    } else {
      const res = await fetchWithAuth(`${API}/financeiro/entries`, {
        method: "POST", body: JSON.stringify(form),
      });
      const data = await res.json();
      if (res.ok) setEntries(prev => [data.entry, ...prev]);
    }
    setEditing(null);
  };

  const handleMarkPaid = async (entry: FinancialEntry) => {
    const newStatus = entry.status === "paid" ? "pending" : "paid";
    const res = await fetchWithAuth(`${API}/financeiro/entries/${encodeURIComponent(entry.id)}`, {
      method: "PUT", body: JSON.stringify({ status: newStatus }),
    });
    const data = await res.json();
    if (res.ok) setEntries(prev => prev.map(e => e.id === entry.id ? data.entry : e));
  };

  const handleDelete = async (entry: FinancialEntry) => {
    await fetchWithAuth(`${API}/financeiro/entries/${encodeURIComponent(entry.id)}`, {
      method: "DELETE",
    });
    setEntries(prev => prev.filter(e => e.id !== entry.id));
    setConfirmDelete(null);
  };

  const receivables = entries.filter(e => e.type === "receivable");
  const payables = entries.filter(e => e.type === "payable");

  const stats = useMemo(() => {
    const totalReceivable = receivables.filter(e => e.status !== "paid").reduce((s, e) => s + e.amount, 0);
    const totalPayable = payables.filter(e => e.status !== "paid").reduce((s, e) => s + e.amount, 0);
    const overdueReceivable = receivables.filter(isOverdue).reduce((s, e) => s + e.amount, 0);
    const overduePayable = payables.filter(isOverdue).reduce((s, e) => s + e.amount, 0);
    return {
      totalReceivable,
      totalPayable,
      balance: totalReceivable - totalPayable,
      overdue: overdueReceivable + overduePayable,
    };
  }, [entries]);

  const monthlyData = useMemo((): BarData[] => {
    const now = new Date();
    return Array.from({ length: 6 }, (_, i) => {
      const d = new Date(now.getFullYear(), now.getMonth() - 5 + i, 1);
      const y = d.getFullYear();
      const m = d.getMonth();
      const label = `${MONTHS_PT[m]}/${String(y).slice(2)}`;
      const receber = entries
        .filter(e => e.type === "receivable")
        .filter(e => { const ed = new Date(e.dueDate); return ed.getFullYear() === y && ed.getMonth() === m; })
        .reduce((s, e) => s + e.amount, 0);
      const pagar = entries
        .filter(e => e.type === "payable")
        .filter(e => { const ed = new Date(e.dueDate); return ed.getFullYear() === y && ed.getMonth() === m; })
        .reduce((s, e) => s + e.amount, 0);
      return { label, receber, pagar };
    });
  }, [entries]);

  const categoryData = useMemo((): PieData[] => {
    const map: Record<string, number> = {};
    entries.forEach(e => {
      map[e.category] = (map[e.category] || 0) + e.amount;
    });
    return Object.entries(map)
      .sort((a, b) => b[1] - a[1])
      .slice(0, 6)
      .map(([name, value]) => ({ name, value }));
  }, [entries]);

  const listEntries = useMemo(() => {
    const base = tab === "receivable" ? receivables : payables;
    return base.filter(e => {
      if (filterStatus === "all") return true;
      if (filterStatus === "overdue") return isOverdue(e);
      return e.status === filterStatus;
    });
  }, [entries, tab, filterStatus]);

  const openNew = (type: EntryType) => {
    setEditing(null);
    setDefaultType(type);
    setModalOpen(true);
  };

  return (
    <div className="flex flex-col min-h-screen bg-zinc-950">
      {/* ── Page Header ── */}
      <div className="bg-zinc-900 border-b border-zinc-800 px-8 py-6">
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <div>
            <div className="flex items-center gap-3 mb-1">
              <div className="w-9 h-9 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center">
                <Wallet className="w-5 h-5 text-emerald-500" />
              </div>
              <h1 className="text-3xl font-bold tracking-tight text-zinc-50">Financeiro</h1>
            </div>
            <p className="text-sm text-zinc-400 font-medium mt-1">Controle de contas a receber e a pagar da agência</p>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={load}
              disabled={loading}
              className="p-2.5 text-zinc-400 hover:text-zinc-50 bg-zinc-900 border border-zinc-800 hover:bg-zinc-800 rounded-xl transition-all"
              title="Atualizar"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
            </button>
            <button
              onClick={() => openNew("receivable")}
              className="flex items-center gap-2 px-4 py-2.5 bg-emerald-600 text-white rounded-xl hover:bg-emerald-700 transition-colors font-medium text-sm shadow-lg shadow-emerald-900/20"
            >
              <ArrowUpRight className="w-4 h-4" /> A Receber
            </button>
            <button
              onClick={() => openNew("payable")}
              className="flex items-center gap-2 px-4 py-2.5 bg-rose-600 text-white rounded-xl hover:bg-rose-700 transition-colors font-medium text-sm shadow-lg shadow-rose-900/20"
            >
              <ArrowDownRight className="w-4 h-4" /> A Pagar
            </button>
          </div>
        </div>

        {/* ── Summary Cards ── */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mt-6">
          <SummaryCard
            label="A Receber"
            value={formatBRL(stats.totalReceivable)}
            sub={`${receivables.filter(e => e.status !== "paid").length} pendentes`}
            icon={<TrendingUp className="w-5 h-5 text-emerald-500" />}
            color="border-emerald-500/20 bg-emerald-500/5"
          />
          <SummaryCard
            label="A Pagar"
            value={formatBRL(stats.totalPayable)}
            sub={`${payables.filter(e => e.status !== "paid").length} pendentes`}
            icon={<TrendingDown className="w-5 h-5 text-rose-400" />}
            color="border-rose-500/20 bg-rose-500/5"
          />
          <SummaryCard
            label="Saldo Projetado"
            value={formatBRL(stats.balance)}
            sub="Receber − Pagar (pendentes)"
            icon={<DollarSign className={`w-5 h-5 ${stats.balance >= 0 ? "text-emerald-500" : "text-rose-400"}`} />}
            color={stats.balance >= 0 ? "border-emerald-500/20 bg-emerald-500/5" : "border-rose-500/20 bg-rose-500/5"}
          />
          <SummaryCard
            label="Vencidos"
            value={formatBRL(stats.overdue)}
            sub={`${entries.filter(isOverdue).length} lançamentos`}
            icon={<AlertCircle className="w-5 h-5 text-amber-400" />}
            color={stats.overdue > 0 ? "border-amber-500/20 bg-amber-500/5" : "border-zinc-800 bg-zinc-900"}
          />
        </div>
      </div>

      {/* ── Tabs ── */}
      <div className="bg-zinc-900 border-b border-zinc-800 px-8">
        <div className="flex gap-1">
          {(["overview", "receivable", "payable"] as Tab[]).map(t => {
            const labels: Record<Tab, string> = { overview: "Visão Geral", receivable: "A Receber", payable: "A Pagar" };
            const active = tab === t;
            return (
              <button
                key={t}
                onClick={() => setTab(t)}
                className={`px-5 py-3.5 text-sm font-semibold border-b-2 transition-all whitespace-nowrap ${
                  active
                    ? t === "payable"
                      ? "border-rose-500 text-rose-400"
                      : "border-emerald-500 text-emerald-400"
                    : "border-transparent text-zinc-500 hover:text-zinc-300"
                }`}
              >
                {labels[t]}
                {t === "receivable" && (
                  <span className="ml-2 text-[11px] bg-zinc-800 text-zinc-400 px-1.5 py-0.5 rounded-full border border-zinc-700">
                    {receivables.length}
                  </span>
                )}
                {t === "payable" && (
                  <span className="ml-2 text-[11px] bg-zinc-800 text-zinc-400 px-1.5 py-0.5 rounded-full border border-zinc-700">
                    {payables.length}
                  </span>
                )}
              </button>
            );
          })}
        </div>
      </div>

      {/* ── Content ── */}
      <div className="flex-1 p-6">
        {loading && (
          <div className="flex items-center justify-center h-48">
            <RefreshCw className="w-6 h-6 text-emerald-500 animate-spin" />
            <span className="ml-3 text-zinc-400">Carregando...</span>
          </div>
        )}

        {error && !loading && (
          <div className="flex items-center gap-3 bg-red-500/10 border border-red-500/20 rounded-2xl p-4 max-w-lg">
            <AlertCircle className="w-5 h-5 text-red-500 shrink-0" />
            <div>
              <p className="font-semibold text-red-400 text-sm">Erro ao carregar</p>
              <p className="text-red-300 text-xs mt-1">{error}</p>
              <button onClick={load} className="mt-2 text-xs text-red-400 underline">Tentar novamente</button>
            </div>
          </div>
        )}

        {!loading && !error && (
          <>
            {/* ── Overview Tab ── */}
            {tab === "overview" && (
              <div className="space-y-6">
                {entries.length === 0 ? (
                  <div className="flex flex-col items-center justify-center h-[50vh] text-center max-w-sm mx-auto">
                    <div className="w-20 h-20 bg-zinc-900 rounded-3xl flex items-center justify-center mb-6 border border-zinc-800">
                      <Wallet className="w-10 h-10 text-zinc-600" />
                    </div>
                    <p className="text-xl font-bold text-zinc-200">Nenhum lançamento ainda</p>
                    <p className="text-zinc-500 text-sm mt-2 mb-8 leading-relaxed">
                      Adicione contas a receber ou a pagar para visualizar os gráficos de fluxo de caixa.
                    </p>
                    <div className="flex gap-3">
                      <button onClick={() => openNew("receivable")} className="flex items-center gap-2 px-5 py-2.5 bg-emerald-600 text-white rounded-xl text-sm font-semibold hover:bg-emerald-700 transition-colors">
                        <Plus className="w-4 h-4" /> A Receber
                      </button>
                      <button onClick={() => openNew("payable")} className="flex items-center gap-2 px-5 py-2.5 bg-rose-600 text-white rounded-xl text-sm font-semibold hover:bg-rose-700 transition-colors">
                        <Plus className="w-4 h-4" /> A Pagar
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="grid grid-cols-1 xl:grid-cols-5 gap-6">
                    {/* Bar Chart */}
                    <div className="xl:col-span-3 bg-zinc-900 rounded-2xl border border-zinc-800 p-6 shadow-xl shadow-black/20">
                      <div className="mb-5">
                        <h3 className="font-bold text-zinc-100 text-base">Fluxo de Caixa Mensal</h3>
                        <p className="text-xs text-zinc-500 mt-0.5">Últimos 6 meses — valores por vencimento</p>
                      </div>
                      <CustomBarChart data={monthlyData} />
                      <div className="flex items-center gap-4 mt-4 justify-center">
                        <span className="flex items-center gap-1.5 text-xs text-zinc-400">
                          <span className="w-3 h-3 rounded-sm bg-emerald-500 inline-block" /> A Receber
                        </span>
                        <span className="flex items-center gap-1.5 text-xs text-zinc-400">
                          <span className="w-3 h-3 rounded-sm bg-rose-500 inline-block" /> A Pagar
                        </span>
                      </div>
                    </div>

                    {/* Donut Chart */}
                    <div className="xl:col-span-2 bg-zinc-900 rounded-2xl border border-zinc-800 p-6 shadow-xl shadow-black/20">
                      <div className="mb-5">
                        <h3 className="font-bold text-zinc-100 text-base">Por Categoria</h3>
                        <p className="text-xs text-zinc-500 mt-0.5">Total por categoria (todos os lançamentos)</p>
                      </div>
                      {categoryData.length > 0 ? (
                        <CustomDonutChart data={categoryData} />
                      ) : (
                        <div className="flex items-center justify-center h-40 text-zinc-600 text-sm">Sem dados</div>
                      )}
                    </div>

                    {/* Overdue panel */}
                    {entries.filter(isOverdue).length > 0 && (
                      <div className="xl:col-span-5 bg-amber-500/5 rounded-2xl border border-amber-500/20 p-5">
                        <div className="flex items-center gap-2 mb-4">
                          <AlertCircle className="w-4 h-4 text-amber-400 shrink-0" />
                          <span className="text-sm font-bold text-amber-300">Lançamentos Vencidos</span>
                          <span className="text-xs text-amber-400/60 ml-auto">{entries.filter(isOverdue).length} item(s)</span>
                        </div>
                        <div className="space-y-2">
                          {entries.filter(isOverdue).slice(0, 5).map(e => (
                            <div key={e.id} className="flex items-center justify-between bg-zinc-900/60 rounded-xl px-4 py-2.5 border border-zinc-800">
                              <div>
                                <p className="text-sm font-semibold text-zinc-200">{e.description}</p>
                                <p className="text-xs text-zinc-500">{e.type === "receivable" ? "A Receber" : "A Pagar"} · Venceu em {formatDate(e.dueDate)}</p>
                              </div>
                              <div className="flex items-center gap-3">
                                <span className={`text-sm font-bold ${e.type === "receivable" ? "text-emerald-400" : "text-rose-400"}`}>
                                  {formatBRL(e.amount)}
                                </span>
                                <button
                                  onClick={() => handleMarkPaid(e)}
                                  className="text-xs px-3 py-1.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-lg font-semibold transition-colors"
                                >
                                  Marcar Pago
                                </button>
                              </div>
                            </div>
                          ))}
                        </div>
                      </div>
                    )}
                  </div>
                )}
              </div>
            )}

            {/* ── List Tabs ── */}
            {(tab === "receivable" || tab === "payable") && (
              <div className="space-y-4">
                <div className="flex items-center justify-between gap-4 flex-wrap">
                  <div className="flex gap-1 bg-zinc-900 border border-zinc-800 rounded-xl p-1">
                    {(["all", "pending", "overdue", "paid"] as const).map(s => {
                      const labels = { all: "Todos", pending: "Pendentes", overdue: "Vencidos", paid: "Pagos" };
                      return (
                        <button
                          key={s}
                          onClick={() => setFilterStatus(s)}
                          className={`px-3 py-1.5 rounded-lg text-xs font-semibold transition-all ${
                            filterStatus === s
                              ? "bg-zinc-700 text-zinc-50 shadow-sm"
                              : "text-zinc-500 hover:text-zinc-300"
                          }`}
                        >
                          {labels[s]}
                        </button>
                      );
                    })}
                  </div>
                  <button
                    onClick={() => openNew(tab as EntryType)}
                    className={`flex items-center gap-2 px-4 py-2 rounded-xl text-sm font-semibold text-white transition-colors ${
                      tab === "receivable" ? "bg-emerald-600 hover:bg-emerald-500" : "bg-rose-600 hover:bg-rose-500"
                    }`}
                  >
                    <Plus className="w-4 h-4" />
                    {tab === "receivable" ? "Nova Conta a Receber" : "Nova Conta a Pagar"}
                  </button>
                </div>

                {listEntries.length === 0 ? (
                  <div className="flex flex-col items-center justify-center py-24 text-center">
                    <div className="w-16 h-16 bg-zinc-900 rounded-2xl flex items-center justify-center mb-4 border border-zinc-800">
                      {tab === "receivable"
                        ? <TrendingUp className="w-8 h-8 text-zinc-600" />
                        : <TrendingDown className="w-8 h-8 text-zinc-600" />
                      }
                    </div>
                    <p className="text-zinc-300 font-semibold">Nenhum lançamento encontrado</p>
                    <p className="text-zinc-500 text-sm mt-1">
                      {filterStatus !== "all" ? "Tente mudar o filtro de status." : "Adicione um lançamento para começar."}
                    </p>
                  </div>
                ) : (
                  <div className="bg-zinc-900 rounded-2xl border border-zinc-800 overflow-hidden shadow-xl shadow-black/20">
                    <table className="w-full">
                      <thead className="bg-zinc-950/50 border-b border-zinc-800">
                        <tr>
                          <th className="px-4 py-3 text-left text-xs font-bold text-zinc-400 uppercase tracking-wider">Descrição</th>
                          <th className="px-4 py-3 text-left text-xs font-bold text-zinc-400 uppercase tracking-wider hidden md:table-cell">Categoria</th>
                          <th className="px-4 py-3 text-left text-xs font-bold text-zinc-400 uppercase tracking-wider">Valor</th>
                          <th className="px-4 py-3 text-left text-xs font-bold text-zinc-400 uppercase tracking-wider hidden sm:table-cell">Vencimento</th>
                          <th className="px-4 py-3 text-left text-xs font-bold text-zinc-400 uppercase tracking-wider">Status</th>
                          <th className="px-4 py-3 text-right text-xs font-bold text-zinc-400 uppercase tracking-wider">Ações</th>
                        </tr>
                      </thead>
                      <tbody>
                        {listEntries.map(e => (
                          <EntryRow
                            key={e.id}
                            entry={e}
                            onMarkPaid={handleMarkPaid}
                            onEdit={entry => { setEditing(entry); setModalOpen(true); }}
                            onDelete={entry => setConfirmDelete(entry)}
                          />
                        ))}
                      </tbody>
                    </table>
                    <div className="px-4 py-3 border-t border-zinc-800 flex items-center justify-between text-xs text-zinc-500">
                      <span>{listEntries.length} lançamento{listEntries.length !== 1 ? "s" : ""}</span>
                      <span className={`font-bold text-sm ${tab === "receivable" ? "text-emerald-400" : "text-rose-400"}`}>
                        Total: {formatBRL(listEntries.reduce((s, e) => s + e.amount, 0))}
                      </span>
                    </div>
                  </div>
                )}
              </div>
            )}
          </>
        )}
      </div>

      {/* ── Entry Modal ── */}
      <EntryModal
        isOpen={modalOpen}
        onClose={() => { setModalOpen(false); setEditing(null); }}
        onSave={handleSave}
        editing={editing}
        defaultType={defaultType}
      />

      {/* ── Confirm Delete ── */}
      {confirmDelete && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-zinc-950/80 backdrop-blur-sm p-4">
          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl shadow-2xl w-full max-w-sm p-6 ring-1 ring-white/5">
            <div className="flex items-center gap-3 mb-4">
              <div className="w-10 h-10 bg-rose-500/10 border border-rose-500/20 rounded-xl flex items-center justify-center">
                <Trash2 className="w-5 h-5 text-rose-400" />
              </div>
              <div>
                <p className="font-bold text-zinc-50">Excluir lançamento?</p>
                <p className="text-xs text-zinc-500 mt-0.5">Esta ação não pode ser desfeita.</p>
              </div>
            </div>
            <div className="bg-zinc-950/50 rounded-xl p-3 mb-5 border border-zinc-800">
              <p className="text-sm font-semibold text-zinc-200">{confirmDelete.description}</p>
              <p className="text-xs text-zinc-500 mt-0.5">{formatBRL(confirmDelete.amount)} · {formatDate(confirmDelete.dueDate)}</p>
            </div>
            <div className="flex gap-3">
              <button
                onClick={() => handleDelete(confirmDelete)}
                className="flex-1 py-2.5 bg-rose-600 hover:bg-rose-500 text-white rounded-xl text-sm font-semibold transition-colors"
              >
                Excluir
              </button>
              <button
                onClick={() => setConfirmDelete(null)}
                className="px-4 py-2.5 border border-zinc-700 bg-zinc-800 text-zinc-300 rounded-xl text-sm font-medium hover:bg-zinc-700 hover:text-white transition-colors"
              >
                Cancelar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}