import { useState, useCallback } from "react";
import {
  X, Gauge, RefreshCw, Monitor, Smartphone, AlertTriangle,
  CheckCircle2, XCircle, ChevronDown, ChevronUp, Zap, Clock,
  LayoutGrid, MousePointer, FileText, ImageIcon,
} from "lucide-react";
import { projectId } from "/utils/supabase/info";
import { fetchWithAuth } from "../utils/auth";

const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-cee56a32`;

interface PageSpeedModalProps {
  isOpen: boolean;
  onClose: () => void;
  siteUrl: string;
  siteName: string;
}

interface Metric {
  displayValue: string;
  score: number | null;
  numericValue?: number;
}

interface Opportunity {
  id: string;
  title: string;
  description: string;
  displayValue: string;
  score: number;
}

interface PageSpeedResult {
  strategy: "mobile" | "desktop";
  performanceScore: number;
  metrics: {
    fcp: Metric;
    lcp: Metric;
    tbt: Metric;
    cls: Metric;
    si: Metric;
    tti: Metric;
  };
  opportunities: Opportunity[];
  pageStats: {
    totalByteWeight?: number;
    numRequests?: number;
    numImages?: number;
  };
  fetchTime: string;
}

function scoreColor(score: number): string {
  if (score >= 90) return "#10b981"; // emerald-500
  if (score >= 50) return "#eab308"; // yellow-500
  return "#ef4444"; // red-500
}

function scoreBg(score: number): string {
  if (score >= 90) return "bg-emerald-500/10 border-emerald-500/20";
  if (score >= 50) return "bg-yellow-500/10 border-yellow-500/20";
  return "bg-red-500/10 border-red-500/20";
}

function scoreLabel(score: number): string {
  if (score >= 90) return "Excelente";
  if (score >= 50) return "Precisa melhorar";
  return "Crítico";
}

function metricColor(score: number | null): string {
  if (score === null) return "text-zinc-500";
  if (score >= 0.9) return "text-emerald-500";
  if (score >= 0.5) return "text-yellow-500";
  return "text-red-500";
}

function metricBadge(score: number | null): string {
  if (score === null) return "bg-zinc-800 text-zinc-400 border border-zinc-700";
  if (score >= 0.9) return "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20";
  if (score >= 0.5) return "bg-yellow-500/10 text-yellow-400 border border-yellow-500/20";
  return "bg-red-500/10 text-red-400 border border-red-500/20";
}

function formatBytes(bytes: number): string {
  if (bytes < 1024) return bytes + " B";
  if (bytes < 1024 * 1024) return (bytes / 1024).toFixed(1) + " KB";
  return (bytes / (1024 * 1024)).toFixed(2) + " MB";
}

function ScoreCircle({ score }: { score: number }) {
  const radius = 54;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (score / 100) * circumference;
  const color = scoreColor(score);

  return (
    <div className="relative flex items-center justify-center w-36 h-36">
      <svg className="w-36 h-36 -rotate-90" viewBox="0 0 128 128">
        <circle cx="64" cy="64" r={radius} fill="none" stroke="#27272a" strokeWidth="10" />
        <circle
          cx="64" cy="64" r={radius}
          fill="none" stroke={color} strokeWidth="10"
          strokeDasharray={circumference} strokeDashoffset={offset}
          strokeLinecap="round"
          style={{ transition: "stroke-dashoffset 0.8s ease" }}
        />
      </svg>
      <div className="absolute flex flex-col items-center">
        <span className="text-3xl font-bold text-zinc-50">{score}</span>
        <span className="text-xs text-zinc-500 mt-0.5">/100</span>
      </div>
    </div>
  );
}

function MetricCard({ label, value, score, icon }: {
  label: string; value: string; score: number | null; icon: React.ReactNode;
}) {
  return (
    <div className="bg-zinc-800/30 rounded-2xl p-3 border border-zinc-700/50">
      <div className="flex items-center gap-2 mb-1.5">
        <span className="text-zinc-500">{icon}</span>
        <span className="text-xs text-zinc-400">{label}</span>
      </div>
      <div className="flex items-center justify-between gap-2">
        <span className={`text-sm font-bold ${metricColor(score)}`}>{value}</span>
        {score !== null && (
          <span className={`text-xs px-1.5 py-0.5 rounded-lg font-medium whitespace-nowrap ${metricBadge(score)}`}>
            {score >= 0.9 ? "✓ Bom" : score >= 0.5 ? "⚠ Médio" : "✗ Ruim"}
          </span>
        )}
      </div>
    </div>
  );
}

function parseGoogleResponse(data: any, strat: "mobile" | "desktop"): PageSpeedResult {
  const lhr = data.lighthouseResult;
  const audits = lhr.audits;
  const performanceScore = Math.round((lhr.categories?.performance?.score ?? 0) * 100);

  const getMetric = (key: string): Metric => {
    const a = audits[key];
    return {
      displayValue: a?.displayValue ?? "—",
      score: a?.score ?? null,
      numericValue: a?.numericValue,
    };
  };

  const opportunityIds = [
    "render-blocking-resources", "unused-css-rules", "unused-javascript",
    "uses-optimized-images", "uses-webp-images", "uses-text-compression",
    "uses-responsive-images", "uses-long-cache-ttl",
  ];

  const opportunities: Opportunity[] = opportunityIds
    .map((id) => {
      const a = audits[id];
      if (!a || a.score === null || a.score >= 0.9) return null;
      return {
        id,
        title: a.title,
        description: a.description,
        displayValue: a.displayValue ?? "",
        score: a.score ?? 0,
      };
    })
    .filter(Boolean)
    .sort((a, b) => (a!.score ?? 1) - (b!.score ?? 1))
    .slice(0, 6) as Opportunity[];

  const networkItems: any[] = audits["network-requests"]?.details?.items ?? [];

  return {
    strategy: strat,
    performanceScore,
    metrics: {
      fcp: getMetric("first-contentful-paint"),
      lcp: getMetric("largest-contentful-paint"),
      tbt: getMetric("total-blocking-time"),
      cls: getMetric("cumulative-layout-shift"),
      si: getMetric("speed-index"),
      tti: getMetric("interactive"),
    },
    opportunities,
    pageStats: {
      totalByteWeight: audits["total-byte-weight"]?.numericValue,
      numRequests: networkItems.length || undefined,
      numImages: networkItems.filter((i: any) => i.resourceType === "Image").length || undefined,
    },
    fetchTime: new Date().toLocaleTimeString("pt-BR"),
  };
}

export function PageSpeedModal({ isOpen, onClose, siteUrl, siteName }: PageSpeedModalProps) {
  const [loading, setLoading] = useState(false);
  const [strategy, setStrategy] = useState<"mobile" | "desktop">("mobile");
  const [results, setResults] = useState<{ mobile?: PageSpeedResult; desktop?: PageSpeedResult }>({});
  const [hasRun, setHasRun] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [showOpportunities, setShowOpportunities] = useState(false);

  const fetchStrategy = useCallback(async (strat: "mobile" | "desktop") => {
    const params = new URLSearchParams({ url: siteUrl, strategy: strat });
    const res = await fetchWithAuth(`${API_BASE}/pagespeed?${params}`);
    const data = await res.json();
    if (!res.ok) {
      throw new Error(data?.error || `Erro HTTP ${res.status}`);
    }
    return parseGoogleResponse(data, strat);
  }, [siteUrl]);

  const runBoth = useCallback(async () => {
    setLoading(true);
    setError(null);
    setHasRun(false);
    setShowOpportunities(false);

    try {
      const [mobile, desktop] = await Promise.all([
        fetchStrategy("mobile"),
        fetchStrategy("desktop"),
      ]);
      setResults({ mobile, desktop });
      setStrategy("mobile");
      setHasRun(true);
    } catch (err: any) {
      console.error("[PageSpeed] Error:", err);
      setError(err.message || "Erro desconhecido ao analisar o site.");
    } finally {
      setLoading(false);
    }
  }, [fetchStrategy]);

  if (!isOpen) return null;

  const current = results[strategy];

  return (
    <div className="fixed inset-0 bg-zinc-950/80 backdrop-blur-sm flex items-center justify-center z-50 p-4 transition-all">
      <div className="bg-zinc-900 rounded-2xl shadow-2xl w-full max-w-2xl max-h-[92vh] flex flex-col border border-zinc-800 animate-in fade-in zoom-in-95 duration-200">

        {/* Header */}
        <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-800">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-emerald-500/10 rounded-xl flex items-center justify-center border border-emerald-500/20">
              <Gauge className="w-5 h-5 text-emerald-500" />
            </div>
            <div>
              <h2 className="text-base font-bold text-zinc-50">Análise de Performance</h2>
              <p className="text-xs text-zinc-400 truncate max-w-xs">{siteUrl}</p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 text-zinc-500 hover:text-zinc-300 hover:bg-zinc-800 rounded-xl transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="overflow-y-auto flex-1 px-6 py-5 space-y-5">

          {/* Initial state */}
          {!hasRun && !loading && !error && (
            <div className="text-center py-10">
              <div className="w-20 h-20 bg-emerald-500/10 rounded-full flex items-center justify-center mx-auto mb-4 border border-emerald-500/20">
                <Gauge className="w-10 h-10 text-emerald-500" />
              </div>
              <p className="text-zinc-50 font-semibold mb-1">Pronto para analisar</p>
              <p className="text-zinc-400 text-sm mb-6 max-w-sm mx-auto">
                Usa a API oficial do Google PageSpeed Insights (Lighthouse) para medir a velocidade real do site.
              </p>
              <button
                onClick={runBoth}
                className="inline-flex items-center gap-2 px-6 py-3 bg-emerald-600 text-white rounded-2xl hover:bg-emerald-700 transition-colors font-semibold text-sm shadow-lg shadow-emerald-900/20"
              >
                <Zap className="w-4 h-4" />
                Analisar Mobile + Desktop
              </button>
              <p className="text-xs text-zinc-500 mt-4">Powered by Google Lighthouse · Pode levar 15–30s</p>
            </div>
          )}

          {/* Loading */}
          {loading && (
            <div className="text-center py-12">
              <div className="w-20 h-20 bg-emerald-500/10 rounded-full flex items-center justify-center mx-auto mb-4 border border-emerald-500/20">
                <RefreshCw className="w-10 h-10 text-emerald-500 animate-spin" />
              </div>
              <p className="text-zinc-50 font-semibold">Analisando {siteName}...</p>
              <p className="text-zinc-400 text-sm mt-1">O Google Lighthouse está carregando e avaliando o site.</p>
              <div className="mt-4 flex justify-center gap-1.5">
                {[0, 1, 2].map((i) => (
                  <div key={i} className="w-2 h-2 rounded-full bg-emerald-500 animate-bounce"
                    style={{ animationDelay: `${i * 0.15}s` }} />
                ))}
              </div>
            </div>
          )}

          {/* Error */}
          {error && !loading && (
            <div className="bg-red-500/10 border border-red-500/20 rounded-2xl p-4 flex items-start gap-3">
              <XCircle className="w-5 h-5 text-red-500 shrink-0 mt-0.5" />
              <div className="flex-1">
                <p className="font-semibold text-red-400 text-sm">Erro ao analisar</p>
                <p className="text-red-300 text-xs mt-1 break-words">{error}</p>
                <p className="text-red-400/80 text-xs mt-2">
                  Verifique se a URL do site está correta, acessível publicamente e com HTTPS.
                </p>
              </div>
            </div>
          )}

          {/* Results */}
          {hasRun && !loading && current && (
            <>
              {/* Strategy tabs */}
              <div className="flex gap-2 bg-zinc-800/50 p-1 rounded-2xl border border-zinc-700/50">
                {(["mobile", "desktop"] as const).map((s) => (
                  <button
                    key={s}
                    onClick={() => setStrategy(s)}
                    className={`flex-1 flex items-center justify-center gap-2 py-2 rounded-xl text-sm font-medium transition-all ${
                      strategy === s ? "bg-zinc-900 shadow text-emerald-500 border border-zinc-700" : "text-zinc-400 hover:text-zinc-300 hover:bg-zinc-800/50"
                    }`}
                  >
                    {s === "mobile" ? <Smartphone className="w-4 h-4" /> : <Monitor className="w-4 h-4" />}
                    {s === "mobile" ? "Mobile" : "Desktop"}
                    {results[s] && (
                      <span
                        className="text-xs font-bold px-1.5 py-0.5 rounded-lg"
                        style={{
                          background: scoreColor(results[s]!.performanceScore) + "22",
                          color: scoreColor(results[s]!.performanceScore),
                        }}
                      >
                        {results[s]!.performanceScore}
                      </span>
                    )}
                  </button>
                ))}
              </div>

              {/* Score card */}
              <div className={`rounded-2xl border p-5 flex items-center gap-6 ${scoreBg(current.performanceScore)}`}>
                <ScoreCircle score={current.performanceScore} />
                <div className="flex-1">
                  <p className="text-2xl font-bold text-zinc-50">{scoreLabel(current.performanceScore)}</p>
                  <p className="text-sm text-zinc-400 mt-1">
                    {strategy === "mobile" ? "Mobile" : "Desktop"} · Às {current.fetchTime}
                  </p>
                  <div className="mt-3 flex flex-wrap gap-2">
                    {current.performanceScore >= 90 && (
                      <span className="inline-flex items-center gap-1 text-xs bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 px-2 py-1 rounded-lg">
                        <CheckCircle2 className="w-3 h-3" /> Performance excelente
                      </span>
                    )}
                    {current.performanceScore < 90 && current.performanceScore >= 50 && (
                      <span className="inline-flex items-center gap-1 text-xs bg-yellow-500/10 border border-yellow-500/20 text-yellow-400 px-2 py-1 rounded-lg">
                        <AlertTriangle className="w-3 h-3" /> Melhorias recomendadas
                      </span>
                    )}
                    {current.performanceScore < 50 && (
                      <span className="inline-flex items-center gap-1 text-xs bg-red-500/10 border border-red-500/20 text-red-400 px-2 py-1 rounded-lg">
                        <XCircle className="w-3 h-3" /> Performance crítica
                      </span>
                    )}
                  </div>
                </div>
              </div>

              {/* Core Web Vitals */}
              <div>
                <h3 className="text-sm font-semibold text-zinc-50 mb-3 flex items-center gap-2">
                  <Zap className="w-4 h-4 text-emerald-500" /> Core Web Vitals & Métricas
                </h3>
                <div className="grid grid-cols-2 gap-2.5">
                  <MetricCard label="First Contentful Paint" value={current.metrics.fcp.displayValue} score={current.metrics.fcp.score} icon={<Clock className="w-3.5 h-3.5" />} />
                  <MetricCard label="Largest Contentful Paint" value={current.metrics.lcp.displayValue} score={current.metrics.lcp.score} icon={<ImageIcon className="w-3.5 h-3.5" />} />
                  <MetricCard label="Total Blocking Time" value={current.metrics.tbt.displayValue} score={current.metrics.tbt.score} icon={<MousePointer className="w-3.5 h-3.5" />} />
                  <MetricCard label="Cumulative Layout Shift" value={current.metrics.cls.displayValue} score={current.metrics.cls.score} icon={<LayoutGrid className="w-3.5 h-3.5" />} />
                  <MetricCard label="Speed Index" value={current.metrics.si.displayValue} score={current.metrics.si.score} icon={<Gauge className="w-3.5 h-3.5" />} />
                  <MetricCard label="Time to Interactive" value={current.metrics.tti.displayValue} score={current.metrics.tti.score} icon={<Clock className="w-3.5 h-3.5" />} />
                </div>
              </div>

              {/* Page stats */}
              {current.pageStats.totalByteWeight != null && (
                <div className="grid grid-cols-3 gap-2.5">
                  <div className="bg-zinc-800/30 rounded-2xl p-3 text-center border border-zinc-700/50">
                    <FileText className="w-4 h-4 text-zinc-500 mx-auto mb-1.5" />
                    <p className="text-lg font-bold text-zinc-50">{formatBytes(current.pageStats.totalByteWeight)}</p>
                    <p className="text-xs text-zinc-400">Tamanho total</p>
                  </div>
                  {current.pageStats.numRequests != null && (
                    <div className="bg-zinc-800/30 rounded-2xl p-3 text-center border border-zinc-700/50">
                      <Zap className="w-4 h-4 text-zinc-500 mx-auto mb-1.5" />
                      <p className="text-lg font-bold text-zinc-50">{current.pageStats.numRequests}</p>
                      <p className="text-xs text-zinc-400">Requisições</p>
                    </div>
                  )}
                  {current.pageStats.numImages != null && (
                    <div className="bg-zinc-800/30 rounded-2xl p-3 text-center border border-zinc-700/50">
                      <ImageIcon className="w-4 h-4 text-zinc-500 mx-auto mb-1.5" />
                      <p className="text-lg font-bold text-zinc-50">{current.pageStats.numImages}</p>
                      <p className="text-xs text-zinc-400">Imagens</p>
                    </div>
                  )}
                </div>
              )}

              {/* Opportunities */}
              {current.opportunities.length > 0 && (
                <div>
                  <button
                    onClick={() => setShowOpportunities(!showOpportunities)}
                    className="w-full flex items-center justify-between text-sm font-semibold text-zinc-300 hover:text-zinc-50 transition-colors mb-2"
                  >
                    <span className="flex items-center gap-2">
                      <AlertTriangle className="w-4 h-4 text-yellow-500" />
                      Oportunidades de melhoria ({current.opportunities.length})
                    </span>
                    {showOpportunities ? <ChevronUp className="w-4 h-4" /> : <ChevronDown className="w-4 h-4" />}
                  </button>
                  {showOpportunities && (
                    <div className="space-y-2">
                      {current.opportunities.map((op) => (
                        <div key={op.id} className="bg-yellow-500/5 border border-yellow-500/20 rounded-2xl p-3">
                          <div className="flex items-start justify-between gap-2">
                            <p className="text-sm font-medium text-zinc-300">{op.title}</p>
                            {op.displayValue && (
                              <span className="text-xs bg-yellow-500/10 text-yellow-500 px-2 py-0.5 rounded-lg shrink-0 border border-yellow-500/20">
                                {op.displayValue}
                              </span>
                            )}
                          </div>
                          <p className="text-xs text-zinc-500 mt-1.5 line-clamp-2">{op.description}</p>
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              )}
            </>
          )}
        </div>

        {/* Footer */}
        <div className="px-6 py-4 border-t border-zinc-800 flex gap-3 bg-zinc-900 rounded-b-2xl">
          {(hasRun || error) && !loading && (
            <button
              onClick={runBoth}
              className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 bg-emerald-600 text-white rounded-2xl hover:bg-emerald-700 transition-colors font-medium text-sm shadow-lg shadow-emerald-900/20"
            >
              <RefreshCw className="w-4 h-4" />
              {error ? "Tentar novamente" : "Analisar novamente"}
            </button>
          )}
          <button
            onClick={onClose}
            className="px-5 py-2.5 border border-zinc-700 text-zinc-300 rounded-2xl hover:bg-zinc-800 hover:text-zinc-50 transition-colors text-sm font-medium"
          >
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
}