import React, { useState, useEffect, useRef } from "react";
import { Plus, Search, FileText, Trash2, Eye, X, UploadCloud, Loader2, Play } from "lucide-react";
import { projectId } from "/utils/supabase/info";
import { fetchWithAuth } from "../../utils/auth";

const API = `https://${projectId}.supabase.co/functions/v1/make-server-cee56a32/pdfs`;

interface PdfRecord {
  id: string;
  title: string;
  fileName: string;
  filePath: string;
  size: number;
  createdAt: string;
}

export function PdfSyntax() {
  const [pdfs, setPdfs] = useState<PdfRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchQuery, setSearchQuery] = useState("");
  
  // Upload State
  const [isUploading, setIsUploading] = useState(false);
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [uploadTitle, setUploadTitle] = useState("");
  const [uploadFile, setUploadFile] = useState<File | null>(null);

  // Viewer State
  const [viewingPdf, setViewingPdf] = useState<PdfRecord | null>(null);
  const [pdfUrl, setPdfUrl] = useState<string | null>(null);
  const [loadingPdf, setLoadingPdf] = useState(false);

  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    fetchPdfs();
  }, []);

  const fetchPdfs = async () => {
    try {
      const res = await fetchWithAuth(API);
      if (res.ok) {
        const data = await res.json();
        setPdfs(data.pdfs || []);
      }
    } catch (error) {
      console.error("Failed to fetch pdfs", error);
    } finally {
      setLoading(false);
    }
  };

  const filteredPdfs = pdfs.filter((p) => 
    p.title.toLowerCase().includes(searchQuery.toLowerCase()) || 
    p.fileName.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleUpload = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!uploadFile || !uploadTitle) return;

    setIsUploading(true);
    const formData = new FormData();
    formData.append("file", uploadFile);
    formData.append("title", uploadTitle);

    try {
      const res = await fetchWithAuth(API, {
        method: "POST",
        body: formData,
      });
      if (res.ok) {
        await fetchPdfs();
        setIsUploadModalOpen(false);
        setUploadFile(null);
        setUploadTitle("");
      } else {
        alert("Erro ao fazer upload do PDF.");
      }
    } catch (error) {
      console.error("Upload error:", error);
      alert("Erro ao fazer upload.");
    } finally {
      setIsUploading(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!confirm("Tem certeza que deseja excluir este PDF?")) return;
    try {
      const res = await fetchWithAuth(`${API}/${encodeURIComponent(id)}`, { 
        method: "DELETE",
      });
      if (res.ok) {
        setPdfs((prev) => prev.filter((p) => p.id !== id));
        if (viewingPdf?.id === id) {
          closeViewer();
        }
      }
    } catch (error) {
      console.error("Delete error:", error);
    }
  };

  const openViewer = async (pdf: PdfRecord) => {
    setViewingPdf(pdf);
    setLoadingPdf(true);
    try {
      const res = await fetchWithAuth(`${API}/${encodeURIComponent(pdf.id)}/url`);
      if (res.ok) {
        const data = await res.json();
        setPdfUrl(data.url);
      }
    } catch (error) {
      console.error("Failed to get pdf url:", error);
    } finally {
      setLoadingPdf(false);
    }
  };

  const closeViewer = () => {
    setViewingPdf(null);
    setPdfUrl(null);
  };

  const formatSize = (bytes: number) => {
    if (bytes === 0) return "0 B";
    const k = 1024;
    const sizes = ["B", "KB", "MB", "GB"];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + " " + sizes[i];
  };

  return (
    <div className="flex-1 min-w-0 flex flex-col bg-black">
      {/* Header */}
      <header className="flex-shrink-0 h-16 border-b border-zinc-800 bg-zinc-900/50 flex items-center justify-between px-6 z-10">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-red-500/20 flex items-center justify-center">
            <FileText className="w-4 h-4 text-red-400" />
          </div>
          <h1 className="text-xl font-semibold text-white">PDF Syntax</h1>
        </div>

        <div className="flex items-center gap-4">
          <div className="relative">
            <Search className="w-4 h-4 text-zinc-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Buscar PDFs..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-64 h-10 pl-10 pr-4 bg-zinc-900 border border-zinc-800 rounded-lg text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-red-500/50 focus:ring-1 focus:ring-red-500/50 transition-all"
            />
          </div>
          <button
            onClick={() => setIsUploadModalOpen(true)}
            className="h-10 px-4 bg-red-600 hover:bg-red-500 text-white text-sm font-medium rounded-lg flex items-center gap-2 transition-colors shadow-lg shadow-red-500/20"
          >
            <Plus className="w-4 h-4" />
            Novo PDF
          </button>
        </div>
      </header>

      {/* Main Content */}
      <main className="flex-1 p-6 overflow-y-auto">
        {loading ? (
          <div className="flex items-center justify-center h-full">
            <Loader2 className="w-8 h-8 text-red-500 animate-spin" />
          </div>
        ) : filteredPdfs.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full text-zinc-500">
            <FileText className="w-16 h-16 mb-4 text-zinc-700" />
            <p className="text-lg text-white font-medium mb-1">Nenhum PDF encontrado</p>
            <p className="text-sm">Faça upload do seu primeiro arquivo para apresentações.</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 lg:grid-cols-4 xl:grid-cols-5 gap-4">
            {filteredPdfs.map((pdf) => (
              <div 
                key={pdf.id}
                className="group relative bg-zinc-900 border border-zinc-800 rounded-xl overflow-hidden hover:border-red-500/30 transition-all shadow-sm hover:shadow-red-500/5 flex flex-col h-48"
              >
                <div className="flex-1 bg-zinc-800/50 flex flex-col items-center justify-center gap-3 p-4 relative group-hover:bg-zinc-800/80 transition-colors">
                  <FileText className="w-12 h-12 text-red-500/70" />
                  
                  {/* Action Overlay */}
                  <div className="absolute inset-0 bg-black/60 opacity-0 group-hover:opacity-100 transition-opacity flex items-center justify-center gap-2 backdrop-blur-[2px]">
                    <button
                      onClick={() => openViewer(pdf)}
                      className="p-3 bg-red-600 hover:bg-red-500 text-white rounded-full transition-colors transform translate-y-4 group-hover:translate-y-0 duration-200"
                      title="Apresentar"
                    >
                      <Play className="w-5 h-5 ml-0.5" />
                    </button>
                  </div>
                </div>

                <div className="p-3 border-t border-zinc-800 bg-zinc-900 flex flex-col gap-1">
                  <div className="flex items-start justify-between gap-2">
                    <h3 className="text-sm font-medium text-white truncate" title={pdf.title}>
                      {pdf.title}
                    </h3>
                    <button
                      onClick={() => handleDelete(pdf.id)}
                      className="text-zinc-500 hover:text-red-400 opacity-0 group-hover:opacity-100 transition-opacity flex-shrink-0"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                  <div className="flex items-center justify-between text-xs text-zinc-500">
                    <span className="truncate">{formatSize(pdf.size)}</span>
                    <span>{new Date(pdf.createdAt).toLocaleDateString()}</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </main>

      {/* Upload Modal */}
      {isUploadModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/80 backdrop-blur-sm">
          <div className="w-full max-w-md bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden shadow-2xl">
            <div className="flex items-center justify-between p-4 border-b border-zinc-800">
              <h2 className="text-lg font-semibold text-white">Upload de PDF</h2>
              <button 
                onClick={() => { setIsUploadModalOpen(false); setUploadFile(null); setUploadTitle(""); }}
                className="text-zinc-400 hover:text-white transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <form onSubmit={handleUpload} className="p-6 flex flex-col gap-5">
              <div>
                <label className="block text-sm font-medium text-zinc-300 mb-1.5">
                  Título da Apresentação
                </label>
                <input
                  type="text"
                  required
                  value={uploadTitle}
                  onChange={(e) => setUploadTitle(e.target.value)}
                  placeholder="Ex: Proposta Comercial Syntax"
                  className="w-full h-10 px-3 bg-zinc-800 border border-zinc-700 rounded-lg text-sm text-white placeholder-zinc-500 focus:outline-none focus:border-red-500 focus:ring-1 focus:ring-red-500 transition-all"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-zinc-300 mb-1.5">
                  Arquivo PDF
                </label>
                <div 
                  className={`border-2 border-dashed rounded-xl p-8 flex flex-col items-center justify-center text-center transition-colors cursor-pointer ${
                    uploadFile ? 'border-red-500/50 bg-red-500/5' : 'border-zinc-700 hover:border-zinc-500 bg-zinc-800/50'
                  }`}
                  onClick={() => fileInputRef.current?.click()}
                >
                  <input
                    type="file"
                    ref={fileInputRef}
                    accept="application/pdf"
                    onChange={(e) => {
                      if (e.target.files && e.target.files[0]) {
                        setUploadFile(e.target.files[0]);
                        if (!uploadTitle) {
                          setUploadTitle(e.target.files[0].name.replace('.pdf', ''));
                        }
                      }
                    }}
                    className="hidden"
                  />
                  {uploadFile ? (
                    <>
                      <FileText className="w-10 h-10 text-red-500 mb-3" />
                      <p className="text-sm font-medium text-white break-all px-4">{uploadFile.name}</p>
                      <p className="text-xs text-zinc-500 mt-1">{formatSize(uploadFile.size)}</p>
                    </>
                  ) : (
                    <>
                      <UploadCloud className="w-10 h-10 text-zinc-500 mb-3" />
                      <p className="text-sm font-medium text-zinc-300">Clique para selecionar</p>
                      <p className="text-xs text-zinc-500 mt-1">Apenas arquivos PDF</p>
                    </>
                  )}
                </div>
              </div>

              <div className="flex justify-end gap-3 mt-2">
                <button
                  type="button"
                  onClick={() => { setIsUploadModalOpen(false); setUploadFile(null); setUploadTitle(""); }}
                  className="px-4 py-2 text-sm font-medium text-zinc-400 hover:text-white transition-colors"
                >
                  Cancelar
                </button>
                <button
                  type="submit"
                  disabled={isUploading || !uploadFile || !uploadTitle}
                  className="px-4 py-2 bg-red-600 hover:bg-red-500 disabled:opacity-50 disabled:cursor-not-allowed text-white text-sm font-medium rounded-lg flex items-center gap-2 transition-colors"
                >
                  {isUploading ? (
                    <>
                      <Loader2 className="w-4 h-4 animate-spin" />
                      Enviando...
                    </>
                  ) : (
                    "Fazer Upload"
                  )}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* PDF Viewer Fullscreen */}
      {viewingPdf && (
        <div className="fixed inset-0 z-[100] bg-black flex flex-col">
          <div className="h-14 bg-zinc-900 border-b border-zinc-800 flex items-center justify-between px-4 flex-shrink-0">
            <div className="flex items-center gap-3">
              <FileText className="w-5 h-5 text-red-500" />
              <h2 className="text-sm font-medium text-white">{viewingPdf.title}</h2>
            </div>
            <div className="flex items-center gap-3">
              <a 
                href={pdfUrl || "#"} 
                target="_blank" 
                rel="noreferrer"
                className="text-xs font-medium text-zinc-400 hover:text-white transition-colors px-3 py-1.5 rounded bg-zinc-800 hover:bg-zinc-700"
              >
                Abrir em Nova Guia
              </a>
              <button 
                onClick={closeViewer}
                className="p-1.5 text-zinc-400 hover:text-white hover:bg-zinc-800 rounded-lg transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
          </div>
          
          <div className="flex-1 w-full bg-zinc-950 relative">
            {loadingPdf ? (
              <div className="absolute inset-0 flex flex-col items-center justify-center gap-3">
                <Loader2 className="w-8 h-8 text-red-500 animate-spin" />
                <p className="text-sm text-zinc-400">Carregando apresentação...</p>
              </div>
            ) : pdfUrl ? (
              <iframe
                src={`${pdfUrl}#toolbar=0&navpanes=0&scrollbar=0`}
                className="w-full h-full border-none"
                title={viewingPdf.title}
              />
            ) : (
              <div className="absolute inset-0 flex items-center justify-center text-zinc-500">
                Erro ao carregar PDF
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}