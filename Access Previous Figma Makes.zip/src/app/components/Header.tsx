import { Link } from "react-router";
import { Code2, HelpCircle } from "lucide-react";

export function Header() {
  return (
    <header className="bg-zinc-950 border-b border-zinc-800 sticky top-0 z-10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <Link to="/" className="flex items-center gap-2">
            <div className="bg-emerald-600 p-2 rounded-2xl">
              <Code2 className="w-6 h-6 text-white" />
            </div>
            <div>
              <span className="text-xl font-bold text-zinc-50">Syntax</span>
              <span className="text-xs text-zinc-400 block leading-none">Agency Dashboard</span>
            </div>
          </Link>
          
          <Link
            to="/instructions"
            className="flex items-center gap-2 text-zinc-400 hover:text-zinc-50 px-3 py-2 rounded-2xl hover:bg-zinc-800/50 transition-colors"
          >
            <HelpCircle className="w-5 h-5" />
            <span className="text-sm font-medium">Como Usar</span>
          </Link>
        </div>
      </div>
    </header>
  );
}
