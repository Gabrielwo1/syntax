import React, { useState, useEffect, useMemo } from "react";
import { Plus, Search, Calendar, ChevronDown, CheckSquare, MessageSquare, MoreHorizontal, FileText, CheckCircle2, Clock, Circle, LayoutGrid, List, Sparkles, Check } from "lucide-react";
import { projectId } from "/utils/supabase/info";
import { fetchWithAuth } from "../utils/auth";
import { TaskModal, type Task, type TaskStatus } from "./TaskModal";
import { AITaskModal } from "./AITaskModal";
import { useAuth } from "../context/AuthContext";

const API = `https://${projectId}.supabase.co/functions/v1/make-server-cee56a32/tasks`;

const STATUS_CONFIG = {
  not_started: {
    label: "Não iniciada",
    icon: Circle,
    colors: "bg-zinc-800 text-zinc-300 border-zinc-700",
  },
  in_progress: {
    label: "Em andamento",
    icon: Clock,
    colors: "bg-blue-500/20 text-blue-400 border-blue-500/30",
  },
  done: {
    label: "Concluída",
    icon: CheckCircle2,
    colors: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30",
  },
};

export function Tasks() {
  const { loading: authLoading } = useAuth();
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isAIModalOpen, setIsAIModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);
  
  // View and Filters state
  const [viewMode, setViewMode] = useState<"list" | "kanban">("list");
  const [searchQuery, setSearchQuery] = useState("");
  const [groupBy, setGroupBy] = useState<"none" | "project" | "assignee">("none");

  const filteredTasks = useMemo(() => {
    return tasks.filter((t) => {
      const matchSearch = !searchQuery || 
        t.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
        (t.project && t.project.toLowerCase().includes(searchQuery.toLowerCase()));
      return matchSearch;
    });
  }, [tasks, searchQuery]);

  const groupedTasks = useMemo(() => {
    if (groupBy === "none") {
      return { "Todas as Tarefas": filteredTasks };
    }

    const groups: Record<string, Task[]> = {};
    filteredTasks.forEach((task) => {
      let key = "Outros";
      if (groupBy === "project" && task.project) key = task.project;
      if (groupBy === "assignee" && task.assignee) key = task.assignee;
      
      if (!groups[key]) groups[key] = [];
      groups[key].push(task);
    });

    // Ordenar as chaves para "Outros" ficar no final se existir
    const sortedGroups: Record<string, Task[]> = {};
    Object.keys(groups).sort((a, b) => {
      if (a === "Outros") return 1;
      if (b === "Outros") return -1;
      return a.localeCompare(b);
    }).forEach(key => {
      sortedGroups[key] = groups[key];
    });

    return sortedGroups;
  }, [filteredTasks, groupBy]);

  const fetchTasks = async () => {
    try {
      const res = await fetchWithAuth(API);
      if (res.ok) {
        const data = await res.json();
        setTasks(data.tasks || []);
      }
    } catch (error) {
      console.error("Failed to fetch tasks", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    if (authLoading) return;
    fetchTasks();
  }, [authLoading]);

  const handleSaveTask = async (task: Task) => {
    try {
      // Optimistic update
      setTasks(prev => {
        const exists = prev.some(t => t.id === task.id);
        if (exists) return prev.map(t => t.id === task.id ? task : t);
        return [...prev, { ...task, id: task.id || 'temp-id' }];
      });

      const method = task.id ? "PUT" : "POST";
      const url = task.id ? `${API}/${task.id}` : API;
      
      const res = await fetchWithAuth(url, {
        method,
        body: JSON.stringify(task),
      });

      if (res.ok) {
        await fetchTasks();
        setIsModalOpen(false);
        setEditingTask(null);
      }
    } catch (error) {
      console.error("Failed to save task", error);
    }
  };

  const toggleTaskStatus = async (task: Task, e: React.MouseEvent) => {
    e.stopPropagation();
    const newStatus = task.status === 'done' ? 'not_started' : 'done';
    const updatedTask = { ...task, status: newStatus };
    await handleSaveTask(updatedTask);
  };

  const openNewTask = () => {
    setEditingTask(null);
    setIsModalOpen(true);
  };

  const openEditTask = (task: Task) => {
    setEditingTask(task);
    setIsModalOpen(true);
  };

  const formatDate = (dateStr: string) => {
    if (!dateStr) return "—";
    const date = new Date(dateStr);
    return new Intl.DateTimeFormat('pt-BR', { 
      day: 'numeric', 
      month: 'long', 
      year: 'numeric' 
    }).format(date);
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-[#111111] overflow-hidden">
      {/* Header */}
      <header className="flex-shrink-0 px-8 py-6 border-b border-zinc-800/50">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-8 h-8 rounded-lg bg-zinc-800 border border-zinc-700 flex items-center justify-center">
            <CheckSquare className="w-5 h-5 text-zinc-300" />
          </div>
          <h1 className="text-2xl font-semibold text-zinc-50 tracking-tight">Tarefas</h1>
        </div>

        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-3 flex-wrap">
            {/* View Mode Toggle */}
            <div className="flex bg-zinc-900 rounded-lg p-1 border border-zinc-800">
              <button
                onClick={() => setViewMode("list")}
                className={`p-1.5 rounded-md transition-colors ${
                  viewMode === "list" ? "bg-zinc-800 text-zinc-100 shadow-sm" : "text-zinc-500 hover:text-zinc-300"
                }`}
                title="Lista"
              >
                <List className="w-4 h-4" />
              </button>
              <button
                onClick={() => setViewMode("kanban")}
                className={`p-1.5 rounded-md transition-colors ${
                  viewMode === "kanban" ? "bg-zinc-800 text-zinc-100 shadow-sm" : "text-zinc-500 hover:text-zinc-300"
                }`}
                title="Kanban"
              >
                <LayoutGrid className="w-4 h-4" />
              </button>
            </div>
            
            <div className="h-5 w-px bg-zinc-800 mx-1" />
            
            {/* Group By Toggle */}
            <div className="flex bg-zinc-900 rounded-lg p-1 border border-zinc-800">
              <button
                onClick={() => setGroupBy("none")}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                  groupBy === "none" ? "bg-zinc-800 text-zinc-100 shadow-sm" : "text-zinc-500 hover:text-zinc-300"
                }`}
              >
                Todas as Tarefas
              </button>
              <button
                onClick={() => setGroupBy("project")}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                  groupBy === "project" ? "bg-zinc-800 text-zinc-100 shadow-sm" : "text-zinc-500 hover:text-zinc-300"
                }`}
              >
                Por Projeto
              </button>
              <button
                onClick={() => setGroupBy("assignee")}
                className={`px-3 py-1.5 text-xs font-medium rounded-md transition-colors ${
                  groupBy === "assignee" ? "bg-zinc-800 text-zinc-100 shadow-sm" : "text-zinc-500 hover:text-zinc-300"
                }`}
              >
                Por Responsável
              </button>
            </div>
            
            <div className="relative ml-2">
              <Search className="w-4 h-4 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Buscar tarefa..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9 pr-4 py-1.5 bg-zinc-900 border border-zinc-800 rounded-lg text-sm text-zinc-100 focus:outline-none focus:border-zinc-600 w-64 placeholder:text-zinc-600 transition-colors"
              />
            </div>
          </div>
          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsAIModalOpen(true)}
              className="flex items-center gap-2 bg-indigo-600/10 hover:bg-indigo-600/20 text-indigo-400 border border-indigo-500/20 hover:border-indigo-500/40 px-4 py-2 rounded-lg text-sm font-medium transition-all shadow-sm shrink-0"
            >
              <Sparkles className="w-4 h-4" />
              Criar com IA
            </button>
            <button
              onClick={openNewTask}
              className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-all shadow-sm shrink-0"
            >
              <Plus className="w-4 h-4" />
              Nova Tarefa
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <div className="flex-1 overflow-auto p-8">
        {loading ? (
          <div className="flex flex-col items-center justify-center h-64 gap-4 text-zinc-500">
            <div className="w-8 h-8 border-2 border-zinc-600 border-t-zinc-400 rounded-full animate-spin"></div>
            <p className="font-medium">Carregando tarefas...</p>
          </div>
        ) : filteredTasks.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-64 gap-4 text-zinc-500">
            <CheckSquare className="w-12 h-12 text-zinc-700" />
            <p className="font-medium">Nenhuma tarefa encontrada.</p>
          </div>
        ) : viewMode === "list" ? (
          <div className="space-y-8">
            {Object.entries(groupedTasks).map(([groupName, groupTasks]) => (
              <div key={groupName} className="space-y-4">
                {groupBy !== "none" && (
                  <h2 className="text-lg font-semibold text-zinc-100 flex items-center gap-2">
                    {groupBy === "project" ? <LayoutGrid className="w-5 h-5 text-emerald-500" /> : <div className="w-5 h-5 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center text-[10px] font-bold">{groupName.substring(0,2).toUpperCase()}</div>}
                    {groupName}
                    <span className="text-xs font-medium bg-zinc-800 text-zinc-400 px-2 py-0.5 rounded-full ml-2">
                      {groupTasks.length}
                    </span>
                  </h2>
                )}
                <div className="bg-zinc-900/50 border border-zinc-800/50 rounded-xl overflow-hidden shadow-xl shadow-black/10">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="border-b border-zinc-800/50 text-xs font-semibold text-zinc-400 bg-zinc-900/30">
                        <th className="py-3.5 px-5 w-12 text-center">
                          <div className="w-4 h-4 border border-zinc-700 rounded bg-zinc-900 mx-auto"></div>
                        </th>
                        <th className="py-3.5 px-5 w-48 uppercase tracking-wider">
                          <div className="flex items-center gap-2">
                            <LayoutGrid className="w-3.5 h-3.5 text-zinc-500" /> Projeto
                          </div>
                        </th>
                        <th className="py-3.5 px-5 uppercase tracking-wider">
                          <div className="flex items-center gap-2">
                            <FileText className="w-3.5 h-3.5 text-zinc-500" /> Nome da Tarefa
                          </div>
                        </th>
                        <th className="py-3.5 px-5 w-48 uppercase tracking-wider">
                          <div className="flex items-center gap-2">
                            <Circle className="w-3.5 h-3.5 text-zinc-500" /> Status
                          </div>
                        </th>
                        <th className="py-3.5 px-5 w-48 uppercase tracking-wider">
                          <div className="flex items-center gap-2">
                            <Calendar className="w-3.5 h-3.5 text-zinc-500" /> Prazo
                          </div>
                        </th>
                        <th className="py-3.5 px-5 w-48 uppercase tracking-wider">
                          <div className="flex items-center gap-2">
                            <MoreHorizontal className="w-3.5 h-3.5 text-zinc-500" /> Responsável
                          </div>
                        </th>
                        <th className="py-3.5 px-5 w-12"></th>
                      </tr>
                    </thead>
                    <tbody className="text-sm">
                      {groupTasks.map((task) => {
                        const statusConf = STATUS_CONFIG[task.status] || STATUS_CONFIG.not_started;
                        const StatusIcon = statusConf.icon;

                        return (
                          <tr 
                            key={task.id} 
                            onClick={() => openEditTask(task)}
                            className="border-b border-zinc-800/50 hover:bg-zinc-800/40 transition-colors cursor-pointer group last:border-0"
                          >
                            <td className="py-4 px-5 text-center">
                              <button 
                                onClick={(e) => toggleTaskStatus(task, e)}
                                className={`w-5 h-5 border rounded mx-auto transition-all flex items-center justify-center ${
                                  task.status === 'done' 
                                    ? 'bg-emerald-500 border-emerald-500 text-white' 
                                    : 'bg-zinc-900 border-zinc-600 hover:border-emerald-500 hover:bg-emerald-500/10'
                                }`}
                                title={task.status === 'done' ? "Marcar como pendente" : "Marcar como concluída"}
                              >
                                {task.status === 'done' && <Check className="w-3.5 h-3.5" />}
                              </button>
                            </td>
                            <td className="py-4 px-5 font-medium text-zinc-400 text-xs">
                              {task.project ? (
                                <span className="bg-zinc-800/80 border border-zinc-700/50 px-2.5 py-1 rounded-md">
                                  {task.project}
                                </span>
                              ) : (
                                "—"
                              )}
                            </td>
                            <td className="py-4 px-5 text-zinc-100 font-medium">
                              <div className="flex items-center gap-3">
                                <span className={`${task.status === 'done' ? 'line-through text-zinc-500' : ''}`}>
                                  {task.name}
                                </span>
                                {task.attachments?.length > 0 && (
                                  <div className="flex items-center gap-1 text-zinc-500 px-1.5 py-0.5 rounded-md bg-zinc-800/80 border border-zinc-700/50">
                                    <MessageSquare className="w-3 h-3" />
                                    <span className="text-[10px] font-bold">{task.attachments.length}</span>
                                  </div>
                                )}
                              </div>
                            </td>
                            <td className="py-4 px-5">
                              <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md border text-xs font-semibold tracking-wide ${statusConf.colors}`}>
                                <StatusIcon className="w-3.5 h-3.5" />
                                {statusConf.label}
                              </span>
                            </td>
                            <td className="py-4 px-5 text-zinc-400 text-sm">
                              <div className="flex items-center gap-2">
                                {formatDate(task.due)}
                              </div>
                            </td>
                            <td className="py-4 px-5">
                              {task.assignee ? (
                                <div className="flex items-center gap-2.5">
                                  <div className="w-7 h-7 rounded-full bg-zinc-800 border border-zinc-700 flex items-center justify-center text-[11px] font-bold text-zinc-300 uppercase shadow-sm">
                                    {task.assignee.substring(0, 2)}
                                  </div>
                                  <span className="text-zinc-300 text-sm font-medium">{task.assignee}</span>
                                </div>
                              ) : (
                                <span className="text-zinc-600 text-sm">—</span>
                              )}
                            </td>
                            <td className="py-4 px-5 text-zinc-600 group-hover:text-zinc-300 transition-colors">
                              <MoreHorizontal className="w-5 h-5 ml-auto" />
                            </td>
                          </tr>
                        );
                      })}
                    </tbody>
                  </table>
                </div>
              </div>
            ))}
          </div>
        ) : (
          /* Kanban View */
          <div className="space-y-8 min-h-[500px]">
            {Object.entries(groupedTasks).map(([groupName, groupTasks]) => (
              <div key={groupName} className="flex flex-col gap-4">
                {groupBy !== "none" && (
                  <h2 className="text-lg font-semibold text-zinc-100 flex items-center gap-2">
                    {groupBy === "project" ? <LayoutGrid className="w-5 h-5 text-emerald-500" /> : <div className="w-5 h-5 rounded-full bg-blue-500/20 text-blue-400 flex items-center justify-center text-[10px] font-bold">{groupName.substring(0,2).toUpperCase()}</div>}
                    {groupName}
                    <span className="text-xs font-medium bg-zinc-800 text-zinc-400 px-2 py-0.5 rounded-full ml-2">
                      {groupTasks.length}
                    </span>
                  </h2>
                )}
                
                <div className="flex gap-6 overflow-x-auto pb-4 custom-scrollbar">
                  {(Object.entries(STATUS_CONFIG) as [TaskStatus, typeof STATUS_CONFIG[keyof typeof STATUS_CONFIG]][]).map(([statusKey, conf]) => {
                    const columnTasks = groupTasks.filter(t => t.status === statusKey);
                    const StatusIcon = conf.icon;
                    
                    return (
                      <div key={statusKey} className="flex-1 min-w-[320px] max-w-[400px] bg-zinc-900/30 rounded-2xl border border-zinc-800/50 flex flex-col overflow-hidden max-h-[70vh]">
                        <div className={`p-4 border-b border-zinc-800/50 flex items-center justify-between shrink-0 ${
                          statusKey === 'done' ? 'bg-emerald-500/5' : 
                          statusKey === 'in_progress' ? 'bg-blue-500/5' : 'bg-zinc-800/20'
                        }`}>
                          <div className="flex items-center gap-2.5">
                            <StatusIcon className={`w-4 h-4 ${
                              statusKey === 'done' ? 'text-emerald-500' : 
                              statusKey === 'in_progress' ? 'text-blue-500' : 'text-zinc-400'
                            }`} />
                            <h3 className="font-semibold text-zinc-200">{conf.label}</h3>
                            <span className="ml-2 bg-zinc-800 text-zinc-400 text-xs px-2 py-0.5 rounded-full font-medium">
                              {columnTasks.length}
                            </span>
                          </div>
                        </div>
                        
                        <div className="p-4 flex-1 overflow-y-auto space-y-3 custom-scrollbar">
                          {columnTasks.map(task => (
                            <div 
                              key={task.id}
                              onClick={() => openEditTask(task)}
                              className="bg-zinc-900 border border-zinc-800 p-4 rounded-xl cursor-pointer hover:border-zinc-600 transition-all shadow-lg shadow-black/20 group"
                            >
                              <div className="flex items-start justify-between gap-3 mb-3">
                                <div className="flex items-start gap-2">
                                  <button
                                    onClick={(e) => toggleTaskStatus(task, e)}
                                    className={`mt-0.5 shrink-0 w-4 h-4 border rounded transition-all flex items-center justify-center ${
                                      task.status === 'done' 
                                        ? 'bg-emerald-500 border-emerald-500 text-white' 
                                        : 'bg-zinc-900 border-zinc-600 hover:border-emerald-500 hover:bg-emerald-500/10'
                                    }`}
                                  >
                                    {task.status === 'done' && <Check className="w-3 h-3" />}
                                  </button>
                                  <h4 className={`text-sm font-medium leading-snug ${task.status === 'done' ? 'line-through text-zinc-500' : 'text-zinc-100 group-hover:text-blue-400 transition-colors'}`}>
                                    {task.name}
                                  </h4>
                                </div>
                              </div>
                              
                              {task.project && groupBy !== 'project' && (
                                <div className="mb-4 inline-block bg-zinc-800/80 border border-zinc-700/50 px-2 py-0.5 rounded text-[10px] font-bold text-zinc-400 uppercase tracking-wider">
                                  {task.project}
                                </div>
                              )}
                              
                              <div className="flex items-center justify-between pt-3 border-t border-zinc-800/60 mt-2">
                                <div className="flex items-center gap-3 text-zinc-500 text-xs">
                                  {task.due && (
                                    <div className="flex items-center gap-1.5" title="Prazo">
                                      <Calendar className="w-3.5 h-3.5" />
                                      <span>{formatDate(task.due).split(' de ')[0]} {formatDate(task.due).split(' de ')[1]?.substring(0,3)}</span>
                                    </div>
                                  )}
                                  
                                  {task.attachments?.length > 0 && (
                                    <div className="flex items-center gap-1" title="Anexos">
                                      <MessageSquare className="w-3.5 h-3.5" />
                                      <span>{task.attachments.length}</span>
                                    </div>
                                  )}
                                </div>
                                
                                {task.assignee && groupBy !== 'assignee' && (
                                  <div className="w-6 h-6 rounded-full bg-zinc-800 border border-zinc-700 flex items-center justify-center text-[10px] font-bold text-zinc-300 uppercase shadow-sm" title={task.assignee}>
                                    {task.assignee.substring(0, 2)}
                                  </div>
                                )}
                              </div>
                            </div>
                          ))}
                          {columnTasks.length === 0 && !loading && (
                            <div className="h-24 border-2 border-dashed border-zinc-800/50 rounded-xl flex items-center justify-center text-zinc-600 text-sm font-medium">
                              Solte tarefas aqui
                            </div>
                          )}
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {isModalOpen && (
        <TaskModal
          task={editingTask}
          onClose={() => setIsModalOpen(false)}
          onSave={handleSaveTask}
        />
      )}

      {isAIModalOpen && (
        <AITaskModal
          onClose={() => setIsAIModalOpen(false)}
          onGenerate={async (generatedTasks) => {
            setIsAIModalOpen(false);
            // Array of generated tasks
            for (const task of generatedTasks) {
              try {
                await fetchWithAuth(API, {
                  method: "POST",
                  body: JSON.stringify(task),
                });
              } catch (e) {
                console.error("Failed to generate task", e);
              }
            }
            fetchTasks();
          }}
        />
      )}
    </div>
  );
}