import { useState } from "react";
import { X, Copy, Check } from "lucide-react";
import { publicAnonKey } from "/utils/supabase/info";

interface TrackingCodeModalProps {
  isOpen: boolean;
  onClose: () => void;
  siteId: string;
  projectId: string;
}

function buildTrackingCode(siteId: string, projectId: string, anonKey: string): string {
  const lines: string[] = [
    "<!-- Syntax Analytics -->",
    "<script>",
    "  window.SYNTAX_SITE_ID = '" + siteId + "';",
    "  window.SYNTAX_PROJECT_ID = '" + projectId + "';",
    "  window.SYNTAX_ANON_KEY = '" + anonKey + "';",
    "</script>",
    "<script>",
    "  (function() {",
    "    'use strict';",
    "    var SITE_ID = window.SYNTAX_SITE_ID;",
    "    var PROJECT_ID = window.SYNTAX_PROJECT_ID;",
    "    var ANON_KEY = window.SYNTAX_ANON_KEY;",
    "    var API_URL = 'https://' + PROJECT_ID + '.supabase.co/functions/v1/make-server-cee56a32';",
    "",
    "    if (!SITE_ID) {",
    "      console.warn('Syntax Analytics: SYNTAX_SITE_ID nao foi definido');",
    "      return;",
    "    }",
    "",
    "    function track(eventData) {",
    "      var data = Object.assign({",
    "        siteId: SITE_ID,",
    "        page: window.location.pathname,",
    "        referrer: document.referrer,",
    "        userAgent: navigator.userAgent,",
    "        screenSize: window.screen.width + 'x' + window.screen.height",
    "      }, eventData);",
    "",
    "      fetch(API_URL + '/track', {",
    "        method: 'POST',",
    "        headers: {",
    "          'Content-Type': 'application/json',",
    "          'Authorization': 'Bearer ' + ANON_KEY",
    "        },",
    "        body: JSON.stringify(data),",
    "        keepalive: true",
    "      }).catch(function(err) {",
    "        console.error('Syntax Analytics error:', err);",
    "      });",
    "    }",
    "",
    "    track({ event: 'pageview' });",
    "",
    "    var startTime = Date.now();",
    "    window.addEventListener('beforeunload', function() {",
    "      var timeOnPage = Math.round((Date.now() - startTime) / 1000);",
    "      track({ event: 'session_end', duration: timeOnPage });",
    "    });",
    "",
    "    document.addEventListener('click', function(ev) {",
    "      var link = ev.target.closest('a');",
    "      if (link && link.href) {",
    "        try {",
    "          var url = new URL(link.href, window.location.href);",
    "          if (url.hostname !== window.location.hostname) {",
    "            track({ event: 'external_link', url: link.href });",
    "          }",
    "        } catch(ex) {}",
    "      }",
    "    }, true);",
    "",
    "    window.syntaxAnalytics = {",
    "      track: function(eventName, properties) {",
    "        track(Object.assign({ event: eventName }, properties || {}));",
    "      }",
    "    };",
    "",
    "    console.log('Syntax Analytics initialized for site:', SITE_ID);",
    "  })();",
    "</script>",
    "<!-- Fim Syntax Analytics -->",
  ];
  return lines.join("\n");
}

export function TrackingCodeModal({ isOpen, onClose, siteId, projectId }: TrackingCodeModalProps) {
  const [copied, setCopied] = useState(false);

  if (!isOpen) return null;

  const trackingCode = buildTrackingCode(siteId, projectId, publicAnonKey);

  const handleCopy = () => {
    const textarea = document.createElement("textarea");
    textarea.value = trackingCode;
    textarea.style.position = "fixed";
    textarea.style.opacity = "0";
    document.body.appendChild(textarea);
    textarea.select();

    try {
      document.execCommand("copy");
      setCopied(true);
      setTimeout(() => setCopied(false), 2000);
    } catch (err) {
      console.error("Erro ao copiar:", err);
      alert("Erro ao copiar. Por favor, selecione e copie manualmente.");
    } finally {
      document.body.removeChild(textarea);
    }
  };

  return (
    <div className="fixed inset-0 bg-zinc-950/80 backdrop-blur-sm flex items-center justify-center z-50 p-4 transition-all">
      <div className="bg-zinc-900 rounded-2xl shadow-2xl max-w-3xl w-full max-h-[90vh] flex flex-col border border-zinc-800 animate-in fade-in zoom-in-95 duration-200">
        <div className="flex items-center justify-between p-6 border-b border-zinc-800">
          <h2 className="text-xl font-bold text-zinc-50">Código de Tracking</h2>
          <button onClick={onClose} className="text-zinc-500 hover:text-zinc-300 hover:bg-zinc-800 p-2 rounded-2xl transition-colors">
            <X className="w-6 h-6" />
          </button>
        </div>

        <div className="p-6 overflow-auto flex-1">
          <div className="mb-4">
            <h3 className="font-semibold text-zinc-50 mb-2">Como instalar:</h3>
            <ol className="list-decimal list-inside space-y-2 text-sm text-zinc-300">
              <li>Copie o código abaixo</li>
              <li>
                Cole no site do cliente <strong>no FINAL do HTML, antes da tag</strong>{" "}
                <code className="bg-zinc-800 px-1 rounded">&lt;/body&gt;</code>
              </li>
              <li>Os dados começarão a ser coletados automaticamente</li>
            </ol>

            <div className="mt-3 p-3 bg-yellow-900/20 border border-yellow-700/50 rounded-2xl">
              <p className="text-xs text-yellow-500">
                <strong>⚠️ Importante:</strong> Cole o código no <strong>FINAL do body</strong> (antes do &lt;/body&gt;),
                não no início. Isso garante que a página carregue rapidamente sem travamentos.
              </p>
            </div>
          </div>

          <div className="relative">
            <pre className="bg-zinc-950 text-zinc-300 p-4 rounded-2xl overflow-x-auto text-sm border border-zinc-800">
              <code>{trackingCode}</code>
            </pre>
            <button
              onClick={handleCopy}
              className="absolute top-2 right-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-50 px-3 py-1.5 rounded-xl flex items-center gap-2 text-sm transition-colors border border-zinc-700"
            >
              {copied ? (
                <>
                  <Check className="w-4 h-4 text-emerald-500" />
                  <span className="text-emerald-500">Copiado!</span>
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  Copiar
                </>
              )}
            </button>
          </div>

          <div className="mt-4 p-4 bg-emerald-500/5 border border-emerald-500/20 rounded-2xl">
            <h4 className="font-semibold text-emerald-500 mb-2">📊 O que será rastreado:</h4>
            <ul className="text-sm text-emerald-400/80 space-y-1">
              <li>✓ Visualizações de página</li>
              <li>✓ Tempo de permanência</li>
              <li>✓ Tipo de dispositivo (desktop/mobile/tablet)</li>
              <li>✓ Cliques em links externos</li>
              <li>✓ Referência de origem</li>
            </ul>
          </div>

          <div className="mt-4 p-4 bg-zinc-800/30 border border-zinc-700/50 rounded-2xl">
            <h4 className="font-semibold text-zinc-50 mb-2">🎯 Tracking customizado (opcional):</h4>
            <p className="text-sm text-zinc-400 mb-2">
              Você também pode rastrear eventos personalizados no site do cliente:
            </p>
            <pre className="bg-zinc-950 text-zinc-300 p-3 rounded-2xl text-xs overflow-x-auto border border-zinc-800">
              <code>{[
                "// Exemplo: rastrear clique em botão",
                "document.getElementById('btnComprar').addEventListener('click', function() {",
                "  window.syntaxAnalytics.track('compra_iniciada', {",
                "    produto: 'Plano Premium',",
                "    valor: 99.90",
                "  });",
                "});",
              ].join("\n")}</code>
            </pre>
          </div>
        </div>

        <div className="p-6 border-t border-zinc-800">
          <button
            onClick={onClose}
            className="w-full px-4 py-2.5 bg-emerald-600 text-white font-medium rounded-2xl hover:bg-emerald-700 transition-colors shadow-lg shadow-emerald-900/20"
          >
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
}
