import { useParams, Link } from "react-router";
import { useState, useEffect, useId } from "react";
import {
  ArrowLeft,
  ExternalLink,
  TrendingUp,
  TrendingDown,
  Users,
  Eye,
  Clock,
  Mail,
  Phone,
  Calendar,
  Loader2,
  Signal,
  Code2,
  Gauge,
} from "lucide-react";
import {
  AreaChart,
  Area,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import { generateWeeklyData } from "../data/mockData";
import { projectId } from "/utils/supabase/info";
import { fetchWithAuth } from "../utils/auth";
import { TrackingCodeModal } from "./TrackingCodeModal";
import { TrackingVerifierModal } from "./TrackingVerifierModal";
import { PageSpeedModal } from "./PageSpeedModal";
import type { Site } from "../types";

const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-cee56a32`;
const COLORS = ["#10b981", "#34d399", "#059669", "#047857"];

export function SiteDetails() {
  const { id } = useParams();
  const gradientId = useId().replace(/:/g, "");
  const [site, setSite] = useState<Site | null>(null);
  const [loading, setLoading] = useState(true);
  const [notFound, setNotFound] = useState(false);
  const [isRealData, setIsRealData] = useState(false);
  const [showTrackingCode, setShowTrackingCode] = useState(false);
  const [showVerifier, setShowVerifier] = useState(false);
  const [showPageSpeed, setShowPageSpeed] = useState(false);

  // Real page views from backend
  const [pageViewsData, setPageViewsData] = useState<{ page: string; views: number }[]>([]);
  const [deviceData, setDeviceData] = useState<{ name: string; value: number }[]>([]);
  const [weeklyData, setWeeklyData] = useState<{ day: string; visitors: number }[]>([]);

  useEffect(() => {
    if (!id) return;

    async function loadSite() {
      setLoading(true);

      // 1. Try to load from backend first
      try {
        const encodedId = encodeURIComponent(id!);
        const res = await fetchWithAuth(`${API_BASE}/sites/${encodedId}`);

        if (res.ok) {
          const data = await res.json();
          if (data && data.id) {
            setSite(data as Site);
            setIsRealData(true);

            // Build page views chart data from real analytics
            if (data.analytics?.pageViews) {
              const pvEntries = Object.entries(data.analytics.pageViews as Record<string, number>)
                .sort((a, b) => b[1] - a[1])
                .slice(0, 8)
                .map(([page, views]) => ({ page, views }));
              setPageViewsData(pvEntries.length > 0 ? pvEntries : []);
            }

            // Build device chart data from real analytics
            if (data.analytics?.devices) {
              const d = data.analytics.devices as Record<string, number>;
              const deviceEntries = [
                { name: "Desktop", value: d.desktop || 0 },
                { name: "Mobile", value: d.mobile || 0 },
                { name: "Tablet", value: d.tablet || 0 },
              ].filter((e) => e.value > 0);
              setDeviceData(deviceEntries.length > 0 ? deviceEntries : []);
            }

            // Fetch recent events to build real weekly data
            try {
              const eventsRes = await fetchWithAuth(`${API_BASE}/events/${encodedId}?limit=2000`);
              if (eventsRes.ok) {
                const eventsData = await eventsRes.json();
                const events: Array<{ event: string; timestamp: string }> = eventsData.events || [];

                // Build last 7 days buckets
                const now = new Date();
                const days: { label: string; date: Date }[] = [];
                for (let i = 6; i >= 0; i--) {
                  const d = new Date(now);
                  d.setDate(now.getDate() - i);
                  days.push({
                    label: d.toLocaleDateString("pt-BR", { weekday: "short" }),
                    date: d,
                  });
                }

                const counts: Record<string, number> = {};
                days.forEach((d) => {
                  counts[d.label] = 0;
                });

                events.forEach((ev) => {
                  if (ev.event !== "pageview") return;
                  const evDate = new Date(ev.timestamp);
                  const diffDays = Math.floor((now.getTime() - evDate.getTime()) / 86400000);
                  if (diffDays < 0 || diffDays > 6) return;
                  const dayEntry = days[6 - diffDays];
                  if (dayEntry) counts[dayEntry.label] = (counts[dayEntry.label] || 0) + 1;
                });

                const built = days.map((d) => ({ day: d.label, visitors: counts[d.label] || 0 }));
                setWeeklyData(built);
              }
            } catch (evErr) {
              console.error("Erro ao buscar eventos para gráfico semanal:", evErr);
            }

            setLoading(false);
            return;
          }
        }
      } catch (err) {
        console.error("Erro ao buscar site do backend:", err);
      }

      setNotFound(true);
      setLoading(false);
    }

    loadSite();
  }, [id]);

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex items-center justify-center py-20">
          <Loader2 className="w-8 h-8 text-emerald-600 animate-spin mr-3" />
          <p className="text-zinc-400">Carregando detalhes do site...</p>
        </div>
      </div>
    );
  }

  if (notFound || !site) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <Link to="/" className="inline-flex items-center gap-2 text-zinc-400 hover:text-zinc-50 mb-6 transition-colors">
          <ArrowLeft className="w-5 h-5" />
          Voltar ao Dashboard
        </Link>
        <div className="bg-zinc-900 rounded-2xl shadow-xl border border-zinc-800 p-12 text-center">
          <p className="text-zinc-400 text-lg">Site não encontrado.</p>
          <p className="text-zinc-500 text-sm mt-2">O site com ID <code className="bg-zinc-800 px-1 rounded">{id}</code> não existe.</p>
          <Link to="/" className="mt-4 inline-block px-4 py-2 bg-emerald-600 text-white rounded-xl hover:bg-emerald-700 transition-colors text-sm font-medium">
            Voltar ao Dashboard
          </Link>
        </div>
      </div>
    );
  }

  const isPositiveTrend = site.analytics.trend >= 0;

  // For mock sites, use generated data for charts
  const finalPageViewsData = isRealData && pageViewsData.length > 0
    ? pageViewsData
    : [
        { page: "/home", views: 5240 },
        { page: "/produtos", views: 3890 },
        { page: "/sobre", views: 2150 },
        { page: "/contato", views: 1680 },
        { page: "/blog", views: 1420 },
      ];

  const finalDeviceData = isRealData && deviceData.length > 0
    ? deviceData
    : [
        { name: "Desktop", value: 45 },
        { name: "Mobile", value: 40 },
        { name: "Tablet", value: 12 },
        { name: "Outros", value: 3 },
      ];

  return (
    <>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Back Button */}
        <Link to="/" className="inline-flex items-center gap-2 text-zinc-400 hover:text-zinc-50 mb-6 transition-colors">
          <ArrowLeft className="w-5 h-5" />
          Voltar ao Dashboard
        </Link>

        {/* Demo badge */}
        {!isRealData && (
          <div className="mb-4 p-3 bg-yellow-900/20 border border-yellow-700/50 rounded-2xl">
            <p className="text-sm text-yellow-500">
              📊 Exibindo dados de demonstração. Instale o código de tracking no site do cliente para ver dados reais.
            </p>
          </div>
        )}

        {/* Site Header */}
        <div className="bg-zinc-900 rounded-2xl border border-zinc-800 shadow-xl shadow-black/20 p-6 mb-6">
          <div className="flex items-start justify-between flex-wrap gap-4">
            <div>
              <h1 className="text-3xl font-bold text-zinc-50 mb-2">{site.name}</h1>
              <a
                href={site.url}
                target="_blank"
                rel="noopener noreferrer"
                className="text-emerald-500 hover:text-emerald-400 flex items-center gap-1 transition-colors"
              >
                {site.url}
                <ExternalLink className="w-4 h-4" />
              </a>
            </div>
            <div className="flex items-center gap-3">
              <span
                className={`px-3 py-1 rounded-full text-xs font-semibold border ${
                  site.status === "active"
                    ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
                    : "bg-amber-500/10 text-amber-400 border-amber-500/20"
                }`}
              >
                {site.status === "active" ? "Ativo" : "Manutenção"}
              </span>
              <button
                onClick={() => setShowVerifier(true)}
                className="flex items-center gap-2 px-3 py-1.5 border border-zinc-700 text-zinc-300 text-sm rounded-2xl hover:bg-zinc-800 transition-colors"
                title="Verificar captação de dados"
              >
                <Signal className="w-4 h-4" />
                Verificar Tracking
              </button>
              <button
                onClick={() => setShowPageSpeed(true)}
                className="flex items-center gap-2 px-3 py-1.5 border border-zinc-700 text-zinc-300 text-sm rounded-2xl hover:bg-zinc-800 transition-colors"
                title="Análise de performance"
              >
                <Gauge className="w-4 h-4" />
                Performance
              </button>
              <button
                onClick={() => setShowTrackingCode(true)}
                className="flex items-center gap-2 px-3 py-1.5 border border-zinc-700 text-zinc-300 text-sm rounded-2xl hover:bg-zinc-800 transition-colors"
                title="Ver código de tracking"
              >
                <Code2 className="w-4 h-4" />
                Código
              </button>
            </div>
          </div>

          <div className="mt-6 grid grid-cols-1 md:grid-cols-3 gap-4">
            {site.client?.email && (
              <div className="flex items-center gap-3">
                <Mail className="w-5 h-5 text-zinc-500" />
                <div>
                  <p className="text-xs text-zinc-500">Email</p>
                  <p className="text-sm font-medium text-zinc-300">{site.client.email}</p>
                </div>
              </div>
            )}
            {site.client?.phone && (
              <div className="flex items-center gap-3">
                <Phone className="w-5 h-5 text-zinc-500" />
                <div>
                  <p className="text-xs text-zinc-500">Telefone</p>
                  <p className="text-sm font-medium text-zinc-300">{site.client.phone}</p>
                </div>
              </div>
            )}
            {site.lastUpdated && (
              <div className="flex items-center gap-3">
                <Calendar className="w-5 h-5 text-zinc-500" />
                <div>
                  <p className="text-xs text-zinc-500">Última Atualização</p>
                  <p className="text-sm font-medium text-zinc-300">
                    {new Date(site.lastUpdated).toLocaleDateString("pt-BR")}
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Analytics Stats */}
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
          <div className="bg-zinc-900 rounded-2xl border border-zinc-800 shadow-xl shadow-black/20 p-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="bg-emerald-500/10 p-2 rounded-xl border border-emerald-500/20">
                <Eye className="w-5 h-5 text-emerald-500" />
              </div>
              <p className="text-sm text-zinc-400">Visitas Totais</p>
            </div>
            <p className="text-2xl font-bold text-zinc-50">{site.analytics.totalVisits.toLocaleString()}</p>
            <div className={`flex items-center gap-1 mt-1 text-sm font-medium ${isPositiveTrend ? "text-emerald-500" : "text-rose-500"}`}>
              {isPositiveTrend ? <TrendingUp className="w-4 h-4" /> : <TrendingDown className="w-4 h-4" />}
              <span>{Math.abs(site.analytics.trend)}% vs. mês anterior</span>
            </div>
          </div>

          <div className="bg-zinc-900 rounded-2xl border border-zinc-800 shadow-xl shadow-black/20 p-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="bg-emerald-500/10 p-2 rounded-xl border border-emerald-500/20">
                <Users className="w-5 h-5 text-emerald-500" />
              </div>
              <p className="text-sm text-zinc-400">Visitantes Únicos</p>
            </div>
            <p className="text-2xl font-bold text-zinc-50">{site.analytics.uniqueVisitors.toLocaleString()}</p>
          </div>

          <div className="bg-zinc-900 rounded-2xl border border-zinc-800 shadow-xl shadow-black/20 p-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="bg-emerald-500/10 p-2 rounded-xl border border-emerald-500/20">
                <TrendingUp className="w-5 h-5 text-emerald-500" />
              </div>
              <p className="text-sm text-zinc-400">Taxa de Rejeição</p>
            </div>
            <p className="text-2xl font-bold text-zinc-50">{site.analytics.bounceRate}%</p>
          </div>

          <div className="bg-zinc-900 rounded-2xl border border-zinc-800 shadow-xl shadow-black/20 p-6">
            <div className="flex items-center gap-3 mb-2">
              <div className="bg-emerald-500/10 p-2 rounded-xl border border-emerald-500/20">
                <Clock className="w-5 h-5 text-emerald-500" />
              </div>
              <p className="text-sm text-zinc-400">Duração Média</p>
            </div>
            <p className="text-2xl font-bold text-zinc-50">{site.analytics.avgSessionDuration}</p>
          </div>
        </div>

        {/* Charts */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6 mb-6">
          {/* Visitors Over Time */}
          <div className="bg-zinc-900 rounded-2xl border border-zinc-800 shadow-xl shadow-black/20 p-6">
            <h3 className="text-lg font-bold text-zinc-50 mb-4">
              Visitantes nos Últimos 7 Dias
              {isRealData && <span className="ml-2 text-xs font-normal text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-full">dados reais</span>}
              {!isRealData && <span className="ml-2 text-xs font-normal text-yellow-500 bg-yellow-500/10 border border-yellow-500/20 px-2 py-0.5 rounded-full">demonstração</span>}
            </h3>
            {isRealData && weeklyData.every((d) => d.visitors === 0) ? (
              <div className="h-[250px] flex flex-col items-center justify-center text-zinc-500 text-sm gap-2">
                <Eye className="w-8 h-8 opacity-30" />
                <p>Nenhuma visita registrada nos últimos 7 dias.</p>
                <p className="text-xs">Instale o código de tracking no site do cliente para começar.</p>
              </div>
            ) : (
              <ResponsiveContainer width="100%" height={250}>
                <AreaChart data={weeklyData}>
                  <defs>
                    <linearGradient id={`colorVisitors-${gradientId}`} x1="0" y1="0" x2="0" y2="1">
                      <stop offset="5%" stopColor="#10b981" stopOpacity={0.3} />
                      <stop offset="95%" stopColor="#10b981" stopOpacity={0} />
                    </linearGradient>
                  </defs>
                  <CartesianGrid strokeDasharray="3 3" stroke="#27272a" />
                  <XAxis dataKey="day" stroke="#71717a" />
                  <YAxis stroke="#71717a" />
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#18181b', borderColor: '#27272a', color: '#f4f4f5' }}
                    itemStyle={{ color: '#10b981' }}
                  />
                  <Area type="monotone" dataKey="visitors" stroke="#10b981" fillOpacity={1} fill={`url(#colorVisitors-${gradientId})`} />
                </AreaChart>
              </ResponsiveContainer>
            )}
          </div>

          {/* Device Distribution */}
          <div className="bg-zinc-900 rounded-2xl border border-zinc-800 shadow-xl shadow-black/20 p-6">
            <h3 className="text-lg font-bold text-zinc-50 mb-4">Distribuição por Dispositivo</h3>
            {finalDeviceData.every((d) => d.value === 0) ? (
              <div className="h-[250px] flex items-center justify-center text-zinc-500 text-sm">
                Sem dados de dispositivo ainda.
              </div>
            ) : (
              <ResponsiveContainer width="100%" height={250}>
                <PieChart>
                  <Pie
                    data={finalDeviceData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name}: ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#10b981"
                    dataKey="value"
                  >
                    {finalDeviceData.map((_, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip 
                    contentStyle={{ backgroundColor: '#18181b', borderColor: '#27272a', color: '#f4f4f5' }}
                    itemStyle={{ color: '#10b981' }}
                  />
                </PieChart>
              </ResponsiveContainer>
            )}
          </div>
        </div>

        {/* Top Pages */}
        <div className="bg-zinc-900 rounded-2xl border border-zinc-800 shadow-xl shadow-black/20 p-6">
          <h3 className="text-lg font-bold text-zinc-50 mb-4">
            Páginas Mais Visitadas
            {isRealData && <span className="ml-2 text-xs font-normal text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-2 py-0.5 rounded-full">dados reais</span>}
          </h3>
          {finalPageViewsData.length === 0 ? (
            <div className="h-[200px] flex items-center justify-center text-zinc-500 text-sm">
              Sem dados de páginas ainda.
            </div>
          ) : (
            <ResponsiveContainer width="100%" height={300}>
              <BarChart data={finalPageViewsData}>
                <CartesianGrid strokeDasharray="3 3" stroke="#27272a" />
                <XAxis dataKey="page" stroke="#71717a" tick={{ fontSize: 12 }} />
                <YAxis stroke="#71717a" />
                <Tooltip 
                  contentStyle={{ backgroundColor: '#18181b', borderColor: '#27272a', color: '#f4f4f5' }}
                  cursor={{ fill: '#27272a' }}
                />
                <Bar dataKey="views" fill="#10b981" radius={[8, 8, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>

      <PageSpeedModal
        isOpen={showPageSpeed}
        onClose={() => setShowPageSpeed(false)}
        siteUrl={site.url}
        siteName={site.name}
      />
      <TrackingCodeModal
        isOpen={showTrackingCode}
        onClose={() => setShowTrackingCode(false)}
        siteId={site.id}
        projectId={projectId}
      />

      <TrackingVerifierModal
        isOpen={showVerifier}
        onClose={() => setShowVerifier(false)}
        siteId={site.id}
        siteName={site.name}
      />
    </>
  );
}