import { ArrowLeft, Code2, BarChart3, CheckCircle, AlertCircle } from "lucide-react";
import { Link } from "react-router";

export function Instructions() {
  return (
    <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      <Link
        to="/"
        className="inline-flex items-center gap-2 text-zinc-400 hover:text-zinc-50 mb-6 transition-colors"
      >
        <ArrowLeft className="w-5 h-5" />
        Voltar ao Dashboard
      </Link>

      <h1 className="text-3xl font-bold text-zinc-50 mb-8">
        📊 Como Usar o Sistema de Analytics
      </h1>

      {/* Passo a Passo */}
      <div className="space-y-8">
        {/* Step 1 */}
        <div className="bg-zinc-900 rounded-2xl border border-zinc-800 shadow-xl shadow-black/20 p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="bg-emerald-500/10 text-emerald-500 w-8 h-8 rounded-full flex items-center justify-center font-bold border border-emerald-500/20">
              1
            </div>
            <h2 className="text-xl font-bold text-zinc-50">Adicionar Site no Dashboard</h2>
          </div>
          <ol className="list-decimal list-inside space-y-2 text-zinc-300">
            <li>Clique no botão "Adicionar Site" no dashboard principal</li>
            <li>Preencha o nome do cliente e a URL do site (ex: <code className="bg-zinc-800 px-1 py-0.5 rounded text-sm text-zinc-300">https://meucliente.com.br</code>)</li>
            <li>O site aparecerá na sua lista de clientes</li>
          </ol>
        </div>

        {/* Step 2 */}
        <div className="bg-zinc-900 rounded-2xl border border-zinc-800 shadow-xl shadow-black/20 p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="bg-emerald-500/10 text-emerald-500 w-8 h-8 rounded-full flex items-center justify-center font-bold border border-emerald-500/20">
              2
            </div>
            <h2 className="text-xl font-bold text-zinc-50">Instalar o Código de Tracking</h2>
          </div>
          <p className="text-zinc-300 mb-4">
            Para que o sistema comece a coletar dados, você precisa instalar o script no site do cliente:
          </p>
          <ol className="list-decimal list-inside space-y-2 text-zinc-300 mb-4">
            <li>No card do site, clique no ícone de código <Code2 className="w-4 h-4 inline" /> ou vá em Detalhes</li>
            <li>Copie o script fornecido</li>
            <li>Cole o script dentro da tag <code className="bg-zinc-800 px-1 py-0.5 rounded text-emerald-400">&lt;head&gt;</code> do site do cliente</li>
          </ol>
          <div className="bg-zinc-950/50 border border-zinc-800 rounded-xl p-4 mt-4">
            <p className="text-sm font-semibold text-zinc-50 mb-2">Exemplo de instalação (HTML):</p>
            <div className="bg-zinc-950 border border-zinc-800 text-zinc-300 rounded-xl p-4 overflow-x-auto text-sm font-mono">
{`<!DOCTYPE html>
<html>
<head>
  <title>Meu Site</title>
  <!-- Syntax Analytics -->
  <script src="https://SEU_PROJETO.supabase.co/functions/v1/make-server-cee56a32/track.js"></script>
  <script>
    SyntaxAnalytics.init('ID_DO_SITE');
  </script>
</head>
<body>...</body>
</html>`}
            </div>
          </div>
        </div>

        {/* Step 3 */}
        <div className="bg-zinc-900 rounded-2xl border border-zinc-800 shadow-xl shadow-black/20 p-6">
          <div className="flex items-center gap-3 mb-4">
            <div className="bg-emerald-500/10 text-emerald-500 w-8 h-8 rounded-full flex items-center justify-center font-bold border border-emerald-500/20">
              3
            </div>
            <h2 className="text-xl font-bold text-zinc-50">Testar a Instalação</h2>
          </div>
          <p className="text-zinc-300 mb-4">
            Depois de instalar o código, você pode verificar se está funcionando:
          </p>
          <ul className="space-y-3">
            <li className="flex items-start gap-2">
              <CheckCircle className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
              <span className="text-zinc-300">Acesse o site do cliente e abra as ferramentas de desenvolvedor (F12)</span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
              <span className="text-zinc-300">Na aba "Console", procure pela mensagem: <code className="bg-zinc-800 px-2 py-1 rounded text-sm">"Syntax Analytics initialized"</code></span>
            </li>
            <li className="flex items-start gap-2">
              <CheckCircle className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
              <span className="text-zinc-300">No dashboard, clique no botão "Verificar Tracking" no card do site para ver os eventos em tempo real.</span>
            </li>
          </ul>
        </div>

        {/* Informações Técnicas */}
        <div className="bg-zinc-800/30 border border-zinc-700/50 rounded-2xl p-6">
          <div className="flex items-center gap-2 mb-4">
            <AlertCircle className="w-6 h-6 text-emerald-500" />
            <h3 className="text-lg font-bold text-zinc-50">Detalhes Técnicos</h3>
          </div>
          <div className="space-y-4 text-zinc-300 text-sm">
            <p>O script coleta automaticamente:</p>
            <ul className="list-disc list-inside ml-4 space-y-1">
              <li>Visualizações de página (pageviews)</li>
              <li>Tempo de permanência na página (ping a cada 10s)</li>
              <li>Cliques em botões e links</li>
              <li>Informações do dispositivo (Desktop/Mobile)</li>
              <li>Origem do tráfego (Referrer)</li>
            </ul>
            <p className="mt-4">
              <strong>Privacidade:</strong> O sistema não coleta dados pessoais identificáveis (PII) 
              sem consentimento, utilizando identificadores anônimos baseados na sessão do navegador, 
              em conformidade com a LGPD/GDPR.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
}
