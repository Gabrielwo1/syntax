import { projectId } from "/utils/supabase/info";
import { fetchWithAuth } from "../../utils/auth";
import Masonry, { ResponsiveMasonry } from "react-responsive-masonry";

const API = `https://${projectId}.supabase.co/functions/v1/make-server-cee56a32/repo`;

interface RepoItem {
  id: string;
  path: string;
  fileName: string;
  title: string;
  tags: string[];
  createdAt: string;
}

// Helper to load image signed url
function RepoImage({ item, onClick, onLinkClick }: { item: RepoItem, onClick: () => void, onLinkClick: (e: React.MouseEvent, item: RepoItem) => void }) {
  const [url, setUrl] = useState<string | null>(null);

  useEffect(() => {
    let active = true;
    const fetchSignedUrl = async () => {
      try {
        const res = await fetchWithAuth(`${API}/attachment?path=${encodeURIComponent(item.path)}`);
        const data = await res.json();
        if (active && data.signedUrl) setUrl(data.signedUrl);
      } catch (e) {
        console.error(e);
      }
    };
    fetchSignedUrl();
    return () => { active = false; };
  }, [item.path]);

  if (!url) {
    return (
      <div className="w-full h-48 bg-zinc-800 animate-pulse rounded-2xl" />
    );
  }

  return (
    <div 
      className="relative group cursor-pointer overflow-hidden rounded-2xl bg-zinc-900 border border-zinc-800"
      onClick={onClick}
    >
      <img src={url} alt={item.title || item.fileName} className="w-full block object-cover" />
      <div className="absolute inset-0 bg-zinc-950/60 opacity-0 group-hover:opacity-100 transition-opacity flex flex-col justify-end p-4">
        <p className="text-zinc-50 font-medium truncate">{item.title || item.fileName}</p>
        <div className="flex gap-2 mt-2 flex-wrap items-center w-full">
          <div className="flex gap-1 flex-wrap flex-1">
            {item.tags?.map(tag => (
              <span key={tag} className="text-[10px] px-2 py-0.5 bg-zinc-800 text-zinc-300 rounded-full">
                {tag}
              </span>
            ))}
          </div>
          <button 
            onClick={(e) => onLinkClick(e, item)}
            className="flex items-center gap-1 px-2.5 py-1 bg-emerald-500/10 text-emerald-400 hover:bg-emerald-500/20 rounded-full text-[10px] font-medium transition-colors border border-emerald-500/20"
            title="Vincular a uma arte solicitada"
          >
            <svg xmlns="http://www.w3.org/2000/svg" width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
              <path d="M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71" />
              <path d="M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71" />
            </svg>
            Vincular
          </button>
        </div>
      </div>
    </div>
  );
}

export function SocialMediaRepository() {
  const [items, setItems] = useState<RepoItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [isUploadModalOpen, setIsUploadModalOpen] = useState(false);
  const [searchTerm, setSearchTerm] = useState("");
  const [linkSearchTerm, setLinkSearchTerm] = useState("");
  
  // View Modal state
  const [viewIndex, setViewIndex] = useState<number | null>(null);
  const [viewUrl, setViewUrl] = useState<string | null>(null);
  
  // Link item modal state
  const [linkItem, setLinkItem] = useState<RepoItem | null>(null);

  const fetchItems = useCallback(async () => {
    setLoading(true);
    try {
      const res = await fetchWithAuth(API);
      if (res.ok) {
        const data = await res.json();
        setItems(data.items || []);
      }
    } catch (e) {
      console.error(e);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    console.log("[Repo] Fetching items...");
    fetchItems();
  }, [fetchItems]);

  const handleDelete = async (id: string) => {
    if (!confirm("Tem certeza que deseja remover esta referência?")) return;
    try {
      await fetchWithAuth(`${API}/${id}`, { method: 'DELETE' });
      setItems(items.filter(i => i.id !== id));
      if (viewIndex !== null) {
        setViewIndex(null);
      }
    } catch (e) {
      console.error(e);
    }
  };

  const filteredItems = items.filter(item => {
    const search = searchTerm.toLowerCase();
    return (item.title || "").toLowerCase().includes(search) ||
           (item.fileName || "").toLowerCase().includes(search) ||
           (item.tags || []).some(t => t.toLowerCase().includes(search));
  });

  const openView = (idx: number) => {
    setViewIndex(idx);
  };

  const closeView = () => {
    setViewIndex(null);
    setViewUrl(null);
  };

  const nextView = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (viewIndex !== null && viewIndex < filteredItems.length - 1) {
      setViewIndex(viewIndex + 1);
      setViewUrl(null);
    }
  };

  const prevView = (e: React.MouseEvent) => {
    e.stopPropagation();
    if (viewIndex !== null && viewIndex > 0) {
      setViewIndex(viewIndex - 1);
      setViewUrl(null);
    }
  };

  // Fetch viewUrl when viewIndex changes
  useEffect(() => {
    if (viewIndex !== null) {
      const item = filteredItems[viewIndex];
      let active = true;
      const fetchViewUrl = async () => {
        try {
          const res = await fetchWithAuth(`${API}/attachment?path=${encodeURIComponent(item.path)}`);
          const data = await res.json();
          if (active && data.signedUrl) setViewUrl(data.signedUrl);
        } catch (e) {
          console.error(e);
        }
      };
      fetchViewUrl();
      return () => { active = false; };
    }
  }, [viewIndex, filteredItems]);

  return (
    <div className="flex-1 flex flex-col h-full bg-zinc-950 text-zinc-50 overflow-hidden">
      <div className="flex-none p-6 md:p-8 border-b border-zinc-800 bg-zinc-900/50 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-zinc-50 tracking-tight">Repositório de Referências</h1>
          <p className="text-zinc-400 text-sm mt-1">Galeria de inspirações e prints de artes</p>
        </div>
        
        <div className="flex items-center gap-3">
          <div className="relative">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
            <input
              type="text"
              placeholder="Buscar referências..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-9 pr-4 py-2 bg-zinc-900 border border-zinc-800 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50 w-full sm:w-64 transition-all"
            />
          </div>
          <button
            onClick={() => setIsUploadModalOpen(true)}
            className="flex items-center gap-2 bg-emerald-500 hover:bg-emerald-600 text-white px-4 py-2 rounded-xl text-sm font-medium transition-colors whitespace-nowrap"
          >
            <Plus className="w-4 h-4" />
            Adicionar
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-y-auto p-6 md:p-8">
        {loading ? (
          <div className="flex items-center justify-center h-64">
            <div className="animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-emerald-500"></div>
          </div>
        ) : filteredItems.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-64 text-zinc-500">
            <Search className="w-12 h-12 mb-4 text-zinc-700" />
            <p className="text-lg font-medium text-zinc-400">Nenhuma referência encontrada</p>
            <p className="text-sm mt-1 text-zinc-500">
              {searchTerm ? "Tente buscar com outras palavras-chave." : "Adicione imagens e prints para começar a montar o repositório."}
            </p>
          </div>
        ) : (
          <ResponsiveMasonry columnsCountBreakPoints={{ 350: 1, 750: 2, 900: 3, 1200: 4 }}>
            <Masonry gutter="1rem">
              {filteredItems.map((item, idx) => (
                <RepoImage 
                  key={item.id} 
                  item={item} 
                  onClick={() => openView(idx)} 
                  onLinkClick={(e, clickedItem) => {
                    e.stopPropagation();
                    setLinkItem(clickedItem);
                  }}
                />
              ))}
            </Masonry>
          </ResponsiveMasonry>
        )}
      </div>

      {isUploadModalOpen && (
        <UploadModal 
          onClose={() => setIsUploadModalOpen(false)} 
          onSuccess={() => {
            setIsUploadModalOpen(false);
            fetchItems();
          }} 
        />
      )}

      {/* Viewer Modal */}
      {viewIndex !== null && filteredItems[viewIndex] && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-zinc-950/95 backdrop-blur-sm p-4 md:p-8" onClick={closeView}>
          <button onClick={closeView} className="absolute top-6 right-6 p-2 bg-zinc-900/50 hover:bg-zinc-800 text-zinc-400 hover:text-zinc-50 rounded-full transition-colors z-50">
            <X className="w-6 h-6" />
          </button>
          
          <button 
            onClick={(e) => { e.stopPropagation(); handleDelete(filteredItems[viewIndex].id); }} 
            className="absolute top-6 right-20 p-2 bg-red-500/10 hover:bg-red-500/20 text-red-500 rounded-full transition-colors z-50"
            title="Deletar Referência"
          >
            <Trash2 className="w-5 h-5" />
          </button>

          <div className="relative w-full max-w-5xl h-full flex items-center justify-center">
            {/* Prev Button */}
            {viewIndex > 0 && (
              <button 
                onClick={prevView}
                className="absolute left-0 p-3 bg-zinc-900/50 hover:bg-zinc-800 text-zinc-400 hover:text-zinc-50 rounded-full transition-colors z-50"
              >
                <ChevronLeft className="w-8 h-8" />
              </button>
            )}

            <div className="relative max-h-full max-w-full flex items-center justify-center" onClick={e => e.stopPropagation()}>
              {!viewUrl ? (
                <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-emerald-500"></div>
              ) : (
                <img 
                  src={viewUrl} 
                  alt={filteredItems[viewIndex].title} 
                  className="max-h-[85vh] max-w-[85vw] object-contain rounded-md shadow-2xl"
                />
              )}
              
              <div className="absolute bottom-[-4rem] left-0 right-0 text-center">
                <h3 className="text-lg font-medium text-zinc-100">{filteredItems[viewIndex].title || filteredItems[viewIndex].fileName}</h3>
                <div className="flex justify-center gap-2 mt-2 flex-wrap">
                  {filteredItems[viewIndex].tags?.map(tag => (
                    <span key={tag} className="text-xs px-2.5 py-1 bg-zinc-800 text-zinc-300 rounded-full">
                      {tag}
                    </span>
                  ))}
                </div>
              </div>
            </div>

            {/* Next Button */}
            {viewIndex < filteredItems.length - 1 && (
              <button 
                onClick={nextView}
                className="absolute right-0 p-3 bg-zinc-900/50 hover:bg-zinc-800 text-zinc-400 hover:text-zinc-50 rounded-full transition-colors z-50"
              >
                <ChevronRight className="w-8 h-8" />
              </button>
            )}
          </div>
        </div>
      )}

      {/* Link Modal */}
      {linkItem && (
        <LinkItemModal 
          item={linkItem} 
          onClose={() => setLinkItem(null)} 
          onLink={(reqId) => {
            alert(`Imagem vinculada com sucesso à solicitação #${reqId}!`);
            setLinkItem(null);
          }} 
        />
      )}
    </div>
  );
}

function LinkItemModal({ item, onClose, onLink }: { item: RepoItem, onClose: () => void, onLink: (id: string) => void }) {
  const [searchTerm, setSearchTerm] = useState("");
  // Dados simulados para ilustrar os itens que podem ser vinculados
  const [mockItems] = useState([
    { id: '1', title: 'Arte para Campanha Black Friday', status: 'solicitado' },
    { id: '2', title: 'Post Instagram - Lançamento Produto X', status: 'em andamento' },
    { id: '3', title: 'Banner Site Principal', status: 'solicitado' },
    { id: '4', title: 'Carrossel Dicas B2B', status: 'concluído' },
  ]);

  const filteredItems = mockItems.filter(i => i.title.toLowerCase().includes(searchTerm.toLowerCase()));

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-zinc-950/80 backdrop-blur-sm" onClick={onClose}>
      <div className="bg-zinc-900 border border-zinc-800 rounded-2xl w-full max-w-md overflow-hidden flex flex-col shadow-2xl" onClick={e => e.stopPropagation()}>
        <div className="flex justify-between items-center p-5 border-b border-zinc-800">
          <h3 className="text-lg font-medium text-zinc-50">Vincular a uma Solicitação</h3>
          <button onClick={onClose} className="text-zinc-400 hover:text-zinc-50 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>
        <div className="p-5">
          <p className="text-sm text-zinc-400 mb-4">
            Selecione a arte solicitada para vincular a imagem <strong className="text-zinc-200">{item.title || item.fileName}</strong>.
          </p>

          <div className="relative mb-4">
            <Search className="w-4 h-4 absolute left-3 top-1/2 -translate-y-1/2 text-zinc-500" />
            <input
              type="text"
              placeholder="Buscar solicitação..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-zinc-950 border border-zinc-800 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50 text-zinc-50"
            />
          </div>

          <div className="space-y-2 max-h-60 overflow-y-auto pr-1">
            {filteredItems.length === 0 ? (
              <p className="text-sm text-zinc-500 text-center py-4">Nenhuma solicitação encontrada.</p>
            ) : (
              filteredItems.map(req => (
                <button
                  key={req.id}
                  onClick={() => onLink(req.id)}
                  className="w-full text-left p-3 rounded-xl border border-zinc-800 bg-zinc-950 hover:border-emerald-500/50 hover:bg-zinc-900 transition-all flex justify-between items-center group"
                >
                  <div>
                    <p className="text-sm font-medium text-zinc-200 group-hover:text-zinc-50">{req.title}</p>
                    <p className="text-xs text-zinc-500 mt-1 capitalize">{req.status}</p>
                  </div>
                  <Plus className="w-4 h-4 text-zinc-500 group-hover:text-emerald-500" />
                </button>
              ))
            )}
          </div>
        </div>
      </div>
    </div>
  );
}

function UploadModal({ onClose, onSuccess }: { onClose: () => void, onSuccess: () => void }) {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [title, setTitle] = useState("");
  const [tagsInput, setTagsInput] = useState("");
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleFileChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files.length > 0) {
      const selected = e.target.files[0];
      setFile(selected);
      const objUrl = URL.createObjectURL(selected);
      setPreview(objUrl);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      const selected = e.dataTransfer.files[0];
      if (selected.type.startsWith('image/')) {
        setFile(selected);
        setPreview(URL.createObjectURL(selected));
      }
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!file) return;
    
    setUploading(true);
    const tags = tagsInput.split(",").map(t => t.trim()).filter(Boolean);
    
    try {
      const formData = new FormData();
      formData.append("file", file);
      formData.append("title", title);
      formData.append("tags", JSON.stringify(tags));

      const res = await fetchWithAuth(API, {
        method: "POST",
        body: formData
      });

      if (res.ok) {
        onSuccess();
      } else {
        const err = await res.json();
        console.error("Upload error", err);
        alert("Erro no upload");
      }
    } catch (err) {
      console.error(err);
      alert("Erro no upload");
    } finally {
      setUploading(false);
    }
  };

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4 bg-zinc-950/80 backdrop-blur-sm">
      <div className="bg-zinc-900 border border-zinc-800 rounded-3xl w-full max-w-xl overflow-hidden flex flex-col shadow-2xl">
        <div className="flex justify-between items-center p-6 border-b border-zinc-800">
          <h3 className="text-lg font-medium text-zinc-50">Adicionar Referência</h3>
          <button onClick={onClose} className="text-zinc-400 hover:text-zinc-50 transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>
        
        <form onSubmit={handleSubmit} className="p-6 space-y-6">
          {!file ? (
            <div 
              onDragOver={(e) => e.preventDefault()}
              onDrop={handleDrop}
              onClick={() => fileInputRef.current?.click()}
              className="border-2 border-dashed border-zinc-700 hover:border-emerald-500/50 bg-zinc-950/50 rounded-2xl h-48 flex flex-col items-center justify-center cursor-pointer transition-colors group"
            >
              <div className="w-12 h-12 bg-zinc-900 group-hover:bg-emerald-500/10 rounded-full flex items-center justify-center mb-4 transition-colors">
                <UploadCloud className="w-6 h-6 text-zinc-400 group-hover:text-emerald-500 transition-colors" />
              </div>
              <p className="text-zinc-300 font-medium">Clique ou arraste a imagem aqui</p>
              <p className="text-zinc-500 text-xs mt-1">PNG, JPG, WEBP, etc.</p>
              <input 
                type="file" 
                ref={fileInputRef} 
                className="hidden" 
                accept="image/*" 
                onChange={handleFileChange}
              />
            </div>
          ) : (
            <div className="relative rounded-2xl overflow-hidden bg-zinc-950 border border-zinc-800">
              <img src={preview!} alt="Preview" className="w-full h-48 object-contain" />
              <button 
                type="button"
                onClick={() => { setFile(null); setPreview(null); }}
                className="absolute top-2 right-2 p-1.5 bg-zinc-900/80 text-zinc-300 hover:text-white rounded-full"
              >
                <X className="w-4 h-4" />
              </button>
            </div>
          )}

          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-zinc-400 mb-1.5">Título / Descrição</label>
              <input
                type="text"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="Ex: Ref layout clean B2B"
                className="w-full px-4 py-2.5 bg-zinc-950 border border-zinc-800 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50 text-zinc-50"
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium text-zinc-400 mb-1.5">Tags (separadas por vírgula)</label>
              <input
                type="text"
                value={tagsInput}
                onChange={(e) => setTagsInput(e.target.value)}
                placeholder="Ex: dark mode, dashboard, ui, mobile"
                className="w-full px-4 py-2.5 bg-zinc-950 border border-zinc-800 rounded-xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/50 text-zinc-50"
              />
            </div>
          </div>

          <div className="pt-4 flex justify-end gap-3">
            <button
              type="button"
              onClick={onClose}
              className="px-5 py-2.5 text-sm font-medium text-zinc-300 hover:text-zinc-50 transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              disabled={!file || uploading}
              className="px-5 py-2.5 bg-emerald-500 hover:bg-emerald-600 disabled:opacity-50 disabled:hover:bg-emerald-500 text-white rounded-xl text-sm font-medium transition-colors flex items-center gap-2"
            >
              {uploading && <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />}
              {uploading ? "Salvando..." : "Salvar Referência"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}