import { useState, useMemo } from "react";
import { Plus, LayoutGrid, Calendar as CalendarIcon, Clock, ChevronLeft, ChevronRight, Image as ImageIcon, CheckCircle2, Upload, Download, X } from "lucide-react";
import { format, addMonths, subMonths, startOfMonth, endOfMonth, startOfWeek, endOfWeek, eachDayOfInterval, isSameMonth, isSameDay, parseISO } from "date-fns";
import { ptBR } from "date-fns/locale";

type Status = "solicitado" | "em_andamento" | "concluido";

interface Task {
  id: string;
  title: string;
  description: string;
  dueDate: string;
  status: Status;
  imageUrl?: string;
  client: string;
}

const INITIAL_TASKS: Task[] = [
  {
    id: "1",
    title: "Post de Lançamento",
    description: "Criar arte para o lançamento do novo produto no Instagram.",
    dueDate: new Date(new Date().setDate(new Date().getDate() + 2)).toISOString().split('T')[0],
    status: "solicitado",
    client: "Acme Corp"
  },
  {
    id: "2",
    title: "Capa do YouTube",
    description: "Atualizar banner do canal.",
    dueDate: new Date().toISOString().split('T')[0],
    status: "em_andamento",
    client: "Tech Start"
  },
  {
    id: "3",
    title: "Carrossel Dicas",
    description: "Carrossel com 5 dicas de marketing.",
    dueDate: new Date(new Date().setDate(new Date().getDate() - 3)).toISOString().split('T')[0],
    status: "concluido",
    imageUrl: "https://images.unsplash.com/photo-1611162617474-5b21e879e113?q=80&w=400&auto=format&fit=crop",
    client: "Global Solutions"
  }
];

export function SocialMedia() {
  const [tasks, setTasks] = useState<Task[]>(INITIAL_TASKS);
  const [view, setView] = useState<"list" | "calendar">("list");
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);

  const handleSave = (task: Task) => {
    if (editingTask) {
      setTasks(tasks.map(t => t.id === task.id ? task : t));
    } else {
      setTasks([...tasks, { ...task, id: Math.random().toString(36).substr(2, 9) }]);
    }
    setIsModalOpen(false);
    setEditingTask(null);
  };

  const handleDeliver = (task: Task) => {
    setEditingTask({ ...task, status: "concluido" });
    setIsModalOpen(true);
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-zinc-950 text-zinc-50 overflow-hidden">
      <div className="flex-none p-6 md:p-8 border-b border-zinc-800 bg-zinc-900/50 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-zinc-50 tracking-tight">Social Media</h1>
          <p className="text-zinc-400 text-sm mt-1">Gerencie solicitações e entregas de artes</p>
        </div>
        
        <div className="flex items-center gap-3">
          <div className="flex bg-zinc-900 p-1 rounded-xl border border-zinc-800">
            <button
              onClick={() => setView("list")}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                view === "list" ? "bg-zinc-800 text-emerald-400 shadow" : "text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/50"
              }`}
            >
              <LayoutGrid className="w-4 h-4" />
              <span className="hidden sm:inline">Lista</span>
            </button>
            <button
              onClick={() => setView("calendar")}
              className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-colors ${
                view === "calendar" ? "bg-zinc-800 text-emerald-400 shadow" : "text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/50"
              }`}
            >
              <CalendarIcon className="w-4 h-4" />
              <span className="hidden sm:inline">Calendário</span>
            </button>
          </div>
          
          <button
            onClick={() => { setEditingTask(null); setIsModalOpen(true); }}
            className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-white px-4 py-2 rounded-xl text-sm font-medium transition-all shadow-[0_0_15px_rgba(16,185,129,0.2)]"
          >
            <Plus className="w-4 h-4" />
            <span className="hidden sm:inline">Nova Solicitação</span>
          </button>
        </div>
      </div>

      <div className="flex-1 overflow-auto">
        {view === "list" ? (
          <ListView tasks={tasks} onEdit={(t) => { setEditingTask(t); setIsModalOpen(true); }} onDeliver={handleDeliver} />
        ) : (
          <CalendarView tasks={tasks} onEdit={(t) => { setEditingTask(t); setIsModalOpen(true); }} />
        )}
      </div>

      {isModalOpen && (
        <TaskModal
          task={editingTask}
          onClose={() => { setIsModalOpen(false); setEditingTask(null); }}
          onSave={handleSave}
        />
      )}
    </div>
  );
}

function ListView({ tasks, onEdit, onDeliver }: { tasks: Task[], onEdit: (t: Task) => void, onDeliver: (t: Task) => void }) {
  const pendingTasks = tasks.filter(t => t.status !== "concluido");
  const completedTasks = tasks.filter(t => t.status === "concluido");

  return (
    <div className="p-6 md:p-8 flex flex-col gap-10 h-full overflow-y-auto">
      
      {/* Tabela de Pendentes */}
      <div className="shrink-0">
        <div className="flex items-center gap-2 mb-4 px-1">
          <Clock className="w-5 h-5 text-amber-500" />
          <h3 className="text-lg font-semibold text-zinc-50">Artes Solicitadas</h3>
        </div>
        
        <div className="bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden ring-1 ring-white/5 shadow-lg">
          <div className="overflow-x-auto">
            <table className="w-full text-left text-sm whitespace-nowrap">
              <thead className="bg-zinc-900/50 border-b border-zinc-800 text-zinc-400">
                <tr>
                  <th className="px-6 py-4 font-medium">Título</th>
                  <th className="px-6 py-4 font-medium">Cliente</th>
                  <th className="px-6 py-4 font-medium">Data de Entrega</th>
                  <th className="px-6 py-4 font-medium">Status</th>
                  <th className="px-6 py-4 font-medium text-right">Ações</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800/50">
                {pendingTasks.map(task => (
                  <tr key={`pending-${task.id}`} className="hover:bg-zinc-800/20 transition-colors group">
                    <td className="px-6 py-4 font-medium text-zinc-100">{task.title}</td>
                    <td className="px-6 py-4 text-zinc-400">
                      <span className="inline-block bg-zinc-800 px-2 py-1 rounded-md text-xs font-medium uppercase tracking-wider">
                        {task.client}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-zinc-400">
                      <div className={`flex items-center gap-1.5 ${new Date(task.dueDate) < new Date() ? "text-red-400 font-medium" : ""}`}>
                        <CalendarIcon className="w-3.5 h-3.5" />
                        {new Date(task.dueDate).toLocaleDateString("pt-BR", { day: "2-digit", month: "short", year: "numeric" })}
                      </div>
                    </td>
                    <td className="px-6 py-4">
                      <span className={`inline-flex items-center px-2 py-1 rounded-md text-xs font-medium border ${
                        task.status === "em_andamento" 
                          ? "bg-blue-500/10 text-blue-400 border-blue-500/20" 
                          : "bg-amber-500/10 text-amber-400 border-amber-500/20"
                      }`}>
                        {task.status === "em_andamento" ? "Em Andamento" : "Solicitado"}
                      </span>
                    </td>
                    <td className="px-6 py-4 text-right flex items-center justify-end gap-2">
                      <button
                        onClick={() => onEdit(task)}
                        className="px-3 py-2 rounded-xl font-medium text-xs text-zinc-300 hover:text-white hover:bg-zinc-800 transition-colors border border-transparent hover:border-zinc-700"
                      >
                        Editar
                      </button>
                      <button
                        onClick={() => onDeliver(task)}
                        className="inline-flex items-center gap-2 px-3 py-2 bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 hover:bg-emerald-500/20 rounded-xl font-medium text-xs transition-colors"
                      >
                        <Upload className="w-3.5 h-3.5" />
                        Entregar Arte
                      </button>
                    </td>
                  </tr>
                ))}
                {pendingTasks.length === 0 && (
                  <tr>
                    <td colSpan={5} className="px-6 py-8 text-center text-zinc-500">
                      Nenhuma solicitação pendente.
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
          </div>
        </div>
      </div>

      {/* Tabela de Concluídos */}
      {completedTasks.length > 0 && (
        <div className="shrink-0 mb-6">
          <div className="flex items-center gap-2 mb-4 px-1">
            <CheckCircle2 className="w-5 h-5 text-emerald-500" />
            <h3 className="text-lg font-semibold text-zinc-50">Artes Entregues</h3>
          </div>
          
          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden ring-1 ring-white/5 shadow-lg">
            <div className="overflow-x-auto">
              <table className="w-full text-left text-sm whitespace-nowrap">
                <thead className="bg-zinc-900/50 border-b border-zinc-800 text-zinc-400">
                  <tr>
                    <th className="px-6 py-4 font-medium w-16">Preview</th>
                    <th className="px-6 py-4 font-medium">Título</th>
                    <th className="px-6 py-4 font-medium">Cliente</th>
                    <th className="px-6 py-4 font-medium">Data de Entrega</th>
                    <th className="px-6 py-4 font-medium text-right">Ação</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-800/50">
                  {completedTasks.map(task => (
                    <tr key={`completed-${task.id}`} className="hover:bg-zinc-800/20 transition-colors group">
                      <td className="px-6 py-3">
                        {task.imageUrl ? (
                          <div className="w-10 h-10 rounded-lg overflow-hidden border border-zinc-700">
                            <img src={task.imageUrl} alt={task.title} className="w-full h-full object-cover" />
                          </div>
                        ) : (
                          <div className="w-10 h-10 rounded-lg bg-zinc-800 border border-zinc-700 flex items-center justify-center">
                            <ImageIcon className="w-4 h-4 text-zinc-500" />
                          </div>
                        )}
                      </td>
                      <td className="px-6 py-3 font-medium text-zinc-100">{task.title}</td>
                      <td className="px-6 py-3 text-zinc-400">
                        <span className="inline-block bg-zinc-800 px-2 py-1 rounded-md text-xs font-medium uppercase tracking-wider">
                          {task.client}
                        </span>
                      </td>
                      <td className="px-6 py-3 text-zinc-400">
                        {new Date(task.dueDate).toLocaleDateString("pt-BR", { day: "2-digit", month: "short", year: "numeric" })}
                      </td>
                      <td className="px-6 py-3 text-right">
                        <a
                          href={task.imageUrl || "#"}
                          target="_blank"
                          rel="noopener noreferrer"
                          download
                          onClick={(e) => {
                            if (!task.imageUrl) e.preventDefault();
                          }}
                          className={`inline-flex items-center gap-2 px-3 py-2 rounded-xl font-medium text-xs transition-colors ${
                            task.imageUrl 
                              ? "bg-zinc-800 text-zinc-300 hover:text-white hover:bg-zinc-700 border border-zinc-700" 
                              : "bg-zinc-900 text-zinc-600 cursor-not-allowed border border-zinc-800"
                          }`}
                        >
                          <Download className="w-4 h-4" />
                          Baixar Arte
                        </a>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function CalendarView({ tasks, onEdit }: { tasks: Task[], onEdit: (t: Task) => void }) {
  const [currentDate, setCurrentDate] = useState(new Date());

  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(monthStart);
  const startDate = startOfWeek(monthStart);
  const endDate = endOfWeek(monthEnd);

  const dateFormat = "d";
  const days = eachDayOfInterval({ start: startDate, end: endDate });

  const weekDays = ["Dom", "Seg", "Ter", "Qua", "Qui", "Sex", "Sáb"];

  const nextMonth = () => setCurrentDate(addMonths(currentDate, 1));
  const prevMonth = () => setCurrentDate(subMonths(currentDate, 1));

  return (
    <div className="p-6 md:p-8 h-full flex flex-col">
      <div className="flex items-center justify-between mb-6 bg-zinc-900 border border-zinc-800 p-4 rounded-2xl">
        <h2 className="text-lg font-bold text-zinc-50 capitalize">
          {format(currentDate, "MMMM yyyy", { locale: ptBR })}
        </h2>
        <div className="flex gap-2">
          <button onClick={prevMonth} className="p-2 bg-zinc-800 rounded-xl hover:bg-zinc-700 transition-colors text-zinc-300">
            <ChevronLeft className="w-5 h-5" />
          </button>
          <button onClick={() => setCurrentDate(new Date())} className="px-4 py-2 bg-zinc-800 rounded-xl hover:bg-zinc-700 transition-colors text-sm font-medium text-zinc-300">
            Hoje
          </button>
          <button onClick={nextMonth} className="p-2 bg-zinc-800 rounded-xl hover:bg-zinc-700 transition-colors text-zinc-300">
            <ChevronRight className="w-5 h-5" />
          </button>
        </div>
      </div>

      <div className="flex-1 bg-zinc-900 border border-zinc-800 rounded-2xl overflow-hidden flex flex-col">
        <div className="grid grid-cols-7 border-b border-zinc-800 bg-zinc-900/50">
          {weekDays.map(day => (
            <div key={day} className="py-3 text-center text-xs font-semibold text-zinc-400 uppercase tracking-wider">
              {day}
            </div>
          ))}
        </div>
        <div className="grid grid-cols-7 flex-1 auto-rows-fr">
          {days.map((day, idx) => {
            const dayTasks = tasks.filter(t => t.dueDate === format(day, "yyyy-MM-dd"));
            const isCurrentMonth = isSameMonth(day, monthStart);
            const isToday = isSameDay(day, new Date());

            return (
              <div
                key={day.toString()}
                className={`min-h-[100px] border-b border-r border-zinc-800/50 p-2 transition-colors hover:bg-zinc-800/20 ${
                  !isCurrentMonth ? "bg-zinc-950/50 text-zinc-600" : "bg-transparent text-zinc-300"
                }`}
              >
                <div className="flex items-center justify-between mb-2">
                  <span className={`w-7 h-7 flex items-center justify-center rounded-full text-xs font-medium ${
                    isToday ? "bg-emerald-500 text-white" : ""
                  }`}>
                    {format(day, dateFormat)}
                  </span>
                </div>
                <div className="space-y-1">
                  {dayTasks.map(task => (
                    <div
                      key={task.id}
                      onClick={() => onEdit(task)}
                      className={`text-[10px] px-2 py-1.5 rounded-md cursor-pointer truncate font-medium border ${
                        task.status === "concluido" ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20" :
                        task.status === "em_andamento" ? "bg-blue-500/10 text-blue-400 border-blue-500/20" :
                        "bg-amber-500/10 text-amber-400 border-amber-500/20"
                      }`}
                      title={task.title}
                    >
                      {task.title}
                    </div>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

function TaskModal({ task, onClose, onSave }: { task: Task | null, onClose: () => void, onSave: (t: Task) => void }) {
  const [form, setForm] = useState<Partial<Task>>(
    task || { title: "", description: "", dueDate: new Date().toISOString().split('T')[0], status: "solicitado", client: "", imageUrl: "" }
  );

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-zinc-950/80 backdrop-blur-sm p-4">
      <div className="bg-zinc-900 border border-zinc-800 rounded-2xl shadow-2xl w-full max-w-lg flex flex-col overflow-hidden ring-1 ring-white/5">
        <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-800 bg-zinc-900/50">
          <h2 className="text-lg font-semibold text-zinc-50">{task ? "Editar Solicitação" : "Nova Solicitação de Arte"}</h2>
          <button onClick={onClose} className="p-2 text-zinc-400 hover:text-zinc-50 hover:bg-zinc-800 rounded-xl transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-4 overflow-y-auto max-h-[70vh]">
          <div>
            <label className="block text-sm font-medium text-zinc-300 mb-1.5">Título da Arte</label>
            <input
              value={form.title}
              onChange={e => setForm({ ...form, title: e.target.value })}
              placeholder="Ex: Post Carrossel Instagram"
              className="w-full px-3 py-2 bg-zinc-950/50 border border-zinc-800 rounded-xl text-sm text-zinc-50 placeholder-zinc-600 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500 transition-all"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-zinc-300 mb-1.5">Cliente / Projeto</label>
            <input
              value={form.client}
              onChange={e => setForm({ ...form, client: e.target.value })}
              placeholder="Ex: Acme Corp"
              className="w-full px-3 py-2 bg-zinc-950/50 border border-zinc-800 rounded-xl text-sm text-zinc-50 placeholder-zinc-600 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500 transition-all"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-zinc-300 mb-1.5">Descrição / Briefing</label>
            <textarea
              value={form.description}
              onChange={e => setForm({ ...form, description: e.target.value })}
              placeholder="Detalhes sobre a arte, copy, referências..."
              rows={4}
              className="w-full px-3 py-2 bg-zinc-950/50 border border-zinc-800 rounded-xl text-sm text-zinc-50 placeholder-zinc-600 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500 resize-none transition-all"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-zinc-300 mb-1.5">Data de Entrega</label>
              <input
                type="date"
                value={form.dueDate}
                onChange={e => setForm({ ...form, dueDate: e.target.value })}
                className="w-full px-3 py-2 bg-zinc-950/50 border border-zinc-800 rounded-xl text-sm text-zinc-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500 transition-all [color-scheme:dark]"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-zinc-300 mb-1.5">Status</label>
              <select
                value={form.status}
                onChange={e => setForm({ ...form, status: e.target.value as Status })}
                className="w-full px-3 py-2 bg-zinc-950/50 border border-zinc-800 rounded-xl text-sm text-zinc-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500 transition-all"
              >
                <option value="solicitado" className="bg-zinc-900">Solicitado</option>
                <option value="em_andamento" className="bg-zinc-900">Em Andamento</option>
                <option value="concluido" className="bg-zinc-900">Concluído</option>
              </select>
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-zinc-300 mb-1.5 flex items-center gap-2">
              <Upload className="w-4 h-4" />
              Upload da Arte Final (Arquivo)
            </label>
            <div className="flex gap-2 relative">
              <input
                type="file"
                accept="image/*"
                onChange={e => {
                  const file = e.target.files?.[0];
                  if (file) {
                    const objectUrl = URL.createObjectURL(file);
                    setForm({ ...form, imageUrl: objectUrl });
                  }
                }}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              />
              <div className="flex-1 flex items-center justify-center gap-2 px-3 py-4 bg-zinc-950/50 border-2 border-dashed border-zinc-800 rounded-xl text-sm text-zinc-400 hover:border-emerald-500/50 hover:bg-emerald-500/5 transition-all">
                <Upload className="w-5 h-5 text-zinc-500" />
                <span>Clique ou arraste a imagem aqui</span>
              </div>
            </div>
            {form.imageUrl && (
              <div className="mt-3 rounded-lg overflow-hidden border border-zinc-800 h-40 relative group">
                <img src={form.imageUrl} alt="Preview" className="w-full h-full object-cover" />
                <button
                  onClick={() => setForm({ ...form, imageUrl: undefined })}
                  className="absolute top-2 right-2 p-1.5 bg-zinc-900/80 text-white rounded-lg opacity-0 group-hover:opacity-100 transition-opacity hover:bg-red-500"
                  title="Remover imagem"
                >
                  <X className="w-4 h-4" />
                </button>
              </div>
            )}
          </div>
        </div>

        <div className="border-t border-zinc-800 bg-zinc-900/50 px-6 py-4 flex gap-3">
          <button
            onClick={() => onSave(form as Task)}
            disabled={!form.title || !form.dueDate}
            className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-medium text-sm transition-colors shadow-[0_0_15px_rgba(16,185,129,0.2)] disabled:opacity-60"
          >
            Salvar
          </button>
          <button
            onClick={onClose}
            className="px-5 py-2.5 border border-zinc-700 bg-zinc-800 text-zinc-300 rounded-xl text-sm hover:bg-zinc-700 hover:text-white transition-colors"
          >
            Cancelar
          </button>
        </div>
      </div>
    </div>
  );
}
