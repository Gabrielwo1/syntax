import { Link } from "react-router";
import { ExternalLink, TrendingUp, TrendingDown, Users, Eye, Code2, Signal, Gauge } from "lucide-react";
import { useState } from "react";
import type { Site } from "../types";
import { TrackingCodeModal } from "./TrackingCodeModal";
import { TrackingVerifierModal } from "./TrackingVerifierModal";
import { PageSpeedModal } from "./PageSpeedModal";
import { projectId } from "/utils/supabase/info";

interface SiteCardProps {
  site: Site;
}

export function SiteCard({ site }: SiteCardProps) {
  const isPositiveTrend = site.analytics.trend > 0;
  const [showTrackingCode, setShowTrackingCode] = useState(false);
  const [showVerifier, setShowVerifier] = useState(false);
  const [showPageSpeed, setShowPageSpeed] = useState(false);

  return (
    <>
      <div className="bg-zinc-900 rounded-2xl border border-zinc-800 shadow-xl shadow-black/20 hover:border-zinc-700 transition-all p-6 group">
        <div className="flex items-start justify-between mb-5">
          <div className="flex-1 pr-4">
            <h3 className="font-bold text-zinc-50 text-lg mb-1 group-hover:text-emerald-500 transition-colors">{site.name}</h3>
            <a
              href={site.url}
              target="_blank"
              rel="noopener noreferrer"
              className="text-sm text-zinc-400 hover:text-emerald-500 flex items-center gap-1.5 transition-colors"
            >
              {site.url}
              <ExternalLink className="w-3.5 h-3.5" />
            </a>
          </div>
          <span
            className={`px-3 py-1 text-xs font-semibold rounded-full border ${
              site.status === "active"
                ? "bg-emerald-500/10 text-emerald-400 border-emerald-500/20"
                : "bg-amber-500/10 text-amber-400 border-amber-500/20"
            }`}
          >
            {site.status === "active" ? "Ativo" : "Manutenção"}
          </span>
        </div>

        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5 text-zinc-400">
              <div className="bg-zinc-800/50 p-1.5 rounded-2xl border border-zinc-800">
                <Eye className="w-4 h-4 text-zinc-400" />
              </div>
              <span className="text-sm font-medium">Visitas</span>
            </div>
            <div className="text-right">
              <p className="font-bold text-zinc-50">{site.analytics.totalVisits.toLocaleString()}</p>
              <div className={`flex items-center justify-end gap-1 text-xs font-medium mt-0.5 ${isPositiveTrend ? 'text-emerald-500' : 'text-rose-500'}`}>
                {isPositiveTrend ? <TrendingUp className="w-3.5 h-3.5" /> : <TrendingDown className="w-3.5 h-3.5" />}
                <span>{Math.abs(site.analytics.trend)}%</span>
              </div>
            </div>
          </div>

          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2.5 text-zinc-400">
              <div className="bg-zinc-800/50 p-1.5 rounded-2xl border border-zinc-800">
                <Users className="w-4 h-4 text-zinc-400" />
              </div>
              <span className="text-sm font-medium">Visitantes Únicos</span>
            </div>
            <p className="font-bold text-zinc-50">{site.analytics.uniqueVisitors.toLocaleString()}</p>
          </div>

          <div className="pt-4 border-t border-zinc-800">
            <div className="flex items-center justify-between text-sm mb-2">
              <span className="text-zinc-500">Taxa de Rejeição</span>
              <span className="font-semibold text-zinc-50">{site.analytics.bounceRate}%</span>
            </div>
            <div className="flex items-center justify-between text-sm">
              <span className="text-zinc-500">Duração Média</span>
              <span className="font-semibold text-zinc-50">{site.analytics.avgSessionDuration}</span>
            </div>
          </div>
        </div>

        <div className="mt-5 pt-5 border-t border-zinc-800 space-y-4">
          <div className="flex items-center gap-2">
            <div className="w-6 h-6 rounded-full bg-zinc-800 flex items-center justify-center text-xs font-bold text-zinc-300">
              {site.client.name.charAt(0).toUpperCase()}
            </div>
            <p className="text-sm text-zinc-400 font-medium truncate">Cliente: {site.client.name}</p>
          </div>
          
          <div className="flex gap-2">
            <Link
              to={`/site/${site.id}`}
              className="flex-1 text-center px-3 py-2.5 bg-emerald-600 text-white text-sm font-medium rounded-2xl hover:bg-emerald-700 transition-colors shadow-lg shadow-emerald-900/20"
            >
              Ver Detalhes
            </Link>
            <button
              onClick={() => setShowPageSpeed(true)}
              className="flex items-center justify-center w-10 h-10 border border-zinc-700 text-zinc-400 rounded-2xl hover:bg-zinc-800 hover:text-zinc-50 transition-colors"
              title="Análise de performance (PageSpeed)"
            >
              <Gauge className="w-4 h-4" />
            </button>
            <button
              onClick={() => setShowVerifier(true)}
              className="flex items-center justify-center w-10 h-10 border border-zinc-700 text-zinc-400 rounded-2xl hover:bg-zinc-800 hover:text-zinc-50 transition-colors"
              title="Verificar captação de dados"
            >
              <Signal className="w-4 h-4" />
            </button>
            <button
              onClick={() => setShowTrackingCode(true)}
              className="flex items-center justify-center w-10 h-10 border border-zinc-700 text-zinc-400 rounded-2xl hover:bg-zinc-800 hover:text-zinc-50 transition-colors"
              title="Ver código de tracking"
            >
              <Code2 className="w-4 h-4" />
            </button>
          </div>
        </div>
      </div>

      <PageSpeedModal
        isOpen={showPageSpeed}
        onClose={() => setShowPageSpeed(false)}
        siteUrl={site.url}
        siteName={site.name}
      />

      <TrackingCodeModal
        isOpen={showTrackingCode}
        onClose={() => setShowTrackingCode(false)}
        siteId={site.id}
        projectId={projectId}
      />

      <TrackingVerifierModal
        isOpen={showVerifier}
        onClose={() => setShowVerifier(false)}
        siteId={site.id}
        siteName={site.name}
      />
    </>
  );
}
