import { Link } from "react-router";
import { Code2, X } from "lucide-react";
import { useState } from "react";

export function QuickStartGuide() {
  const [isVisible, setIsVisible] = useState(true);

  if (!isVisible) return null;

  return (
    null
  );
}
