import { useState, useEffect } from "react";
import { Plus, TrendingUp, TrendingDown, Users, Eye, Clock } from "lucide-react";
import { SiteCard } from "./SiteCard";
import { AddSiteModal } from "./AddSiteModal";
import { QuickStartGuide } from "./QuickStartGuide";
import { projectId } from "/utils/supabase/info";
import { fetchWithAuth } from "../utils/auth";

import { useAuth } from '../context/AuthContext';
import { Shield } from 'lucide-react';

export function Dashboard() {
  const { isAdmin, loading: authLoading, user } = useAuth();
  const [sites, setSites] = useState<any[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [loading, setLoading] = useState(true);

  // Carregar sites do backend
  useEffect(() => {
    // Guard: don't fetch if auth is still loading OR if user is not authenticated.
    // The user check prevents a spurious re-fetch when session becomes null
    // after sign-out (session?.access_token dependency would otherwise re-run
    // this effect before Root has a chance to redirect to /login).
    if (authLoading || !user) return;

    async function loadSites() {
      setLoading(true);
      try {
        const response = await fetchWithAuth(
          `https://${projectId}.supabase.co/functions/v1/make-server-cee56a32/sites`
        );

        if (response.ok) {
          const data = await response.json();
          if (data.sites) {
            setSites(data.sites);
          }
        } else {
          const errBody = await response.json().catch(() => ({}));
          console.error("Failed to fetch sites:", response.status, errBody);
        }
      } catch (error) {
        console.error("Erro ao carregar sites:", error);
      } finally {
        setLoading(false);
      }
    }

    loadSites();
  }, [authLoading, user]);

  const totalVisits = sites.reduce((sum, site) => sum + site.analytics.totalVisits, 0);
  const totalUsers = sites.reduce((sum, site) => sum + site.analytics.uniqueVisitors, 0);
  const avgBounceRate = sites.reduce((sum, site) => sum + site.analytics.bounceRate, 0) / (sites.length || 1);

  const handleAddSite = async (url: string, clientName: string) => {
    try {
      const response = await fetchWithAuth(
        `https://${projectId}.supabase.co/functions/v1/make-server-cee56a32/sites`,
        {
          method: "POST",
          body: JSON.stringify({
            name: clientName,
            url: url,
            clientName: clientName,
            clientEmail: `contato@${clientName.toLowerCase().replace(/\\s+/g, '')}.com`,
            clientPhone: "(11) 9999-9999",
          }),
        }
      );

      if (response.ok) {
        const data = await response.json();
        const newSite = {
          ...data.site,
          analytics: {
            totalVisits: 0,
            uniqueVisitors: 0,
            bounceRate: 0,
            avgSessionDuration: "0m 0s",
            trend: 0,
          },
        };
        setSites([...sites, newSite]);
      }
    } catch (error) {
      console.error("Erro ao adicionar site:", error);
      // Fallback para dados locais
      const newSite = {
        id: String(sites.length + 1),
        name: clientName,
        url: url,
        status: "active" as const,
        client: {
          name: clientName,
          email: `contato@${clientName.toLowerCase().replace(/\\s+/g, '')}.com`,
          phone: "(11) 9999-9999",
        },
        analytics: {
          totalVisits: 0,
          uniqueVisitors: 0,
          bounceRate: 0,
          avgSessionDuration: "0m 0s",
          trend: 0,
        },
        lastUpdated: new Date().toISOString(),
      };
      setSites([...sites, newSite]);
    }
    setIsModalOpen(false);
  };

  if (loading) {
    return (
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="text-center">
          <p className="text-zinc-500">Carregando sites...</p>
        </div>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="flex-1 flex items-center justify-center h-full bg-[#111111]">
        <div className="text-center">
          <Shield className="w-16 h-16 text-zinc-700 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-zinc-300 mb-2">Acesso Restrito</h2>
          <p className="text-zinc-500">Apenas administradores podem acessar a Dashboard de Análises.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
      {/* Quick Start Guide */}
      <QuickStartGuide />

      {/* Stats Overview */}
      <div className="mb-10">
        <h1 className="text-3xl font-bold tracking-tight text-zinc-50 mb-6">Visão Geral</h1>
        <div className="grid grid-cols-1 md:grid-cols-4 gap-5">
          <div className="bg-zinc-900 rounded-2xl border border-zinc-800 shadow-xl shadow-black/20 p-6 transition-all hover:border-zinc-700">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-zinc-400">Total de Sites</p>
                <p className="text-3xl font-bold text-zinc-50 mt-1">{sites.length}</p>
              </div>
              <div className="bg-emerald-500/10 p-3.5 rounded-2xl border border-emerald-500/20">
                <Eye className="w-6 h-6 text-emerald-500" />
              </div>
            </div>
          </div>

          <div className="bg-zinc-900 rounded-2xl border border-zinc-800 shadow-xl shadow-black/20 p-6 transition-all hover:border-zinc-700">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-zinc-400">Visitas Totais</p>
                <p className="text-3xl font-bold text-zinc-50 mt-1">{totalVisits.toLocaleString()}</p>
              </div>
              <div className="bg-emerald-500/10 p-3.5 rounded-2xl border border-emerald-500/20">
                <TrendingUp className="w-6 h-6 text-emerald-500" />
              </div>
            </div>
          </div>

          <div className="bg-zinc-900 rounded-2xl border border-zinc-800 shadow-xl shadow-black/20 p-6 transition-all hover:border-zinc-700">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-zinc-400">Visitantes Únicos</p>
                <p className="text-3xl font-bold text-zinc-50 mt-1">{totalUsers.toLocaleString()}</p>
              </div>
              <div className="bg-emerald-500/10 p-3.5 rounded-2xl border border-emerald-500/20">
                <Users className="w-6 h-6 text-emerald-500" />
              </div>
            </div>
          </div>

          <div className="bg-zinc-900 rounded-2xl border border-zinc-800 shadow-xl shadow-black/20 p-6 transition-all hover:border-zinc-700">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm font-medium text-zinc-400">Taxa de Rejeição Média</p>
                <p className="text-3xl font-bold text-zinc-50 mt-1">{avgBounceRate.toFixed(1)}%</p>
              </div>
              <div className="bg-emerald-500/10 p-3.5 rounded-2xl border border-emerald-500/20">
                <Clock className="w-6 h-6 text-emerald-500" />
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Sites List */}
      <div className="flex items-center justify-between mb-8 mt-12">
        <h2 className="text-2xl font-bold tracking-tight text-zinc-50">Sites dos Clientes</h2>
        <button
          onClick={() => setIsModalOpen(true)}
          className="flex items-center gap-2 bg-emerald-600 text-white px-5 py-2.5 rounded-2xl hover:bg-emerald-700 transition-colors font-medium shadow-lg shadow-emerald-900/20"
        >
          <Plus className="w-5 h-5" />
          Adicionar Site
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {sites.map((site) => (
          <SiteCard key={site.id} site={site} />
        ))}
      </div>

      <AddSiteModal
        isOpen={isModalOpen}
        onClose={() => setIsModalOpen(false)}
        onAdd={handleAddSite}
      />
    </div>
  );
}