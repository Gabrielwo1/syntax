import { useState } from "react";
import { NavLink, useLocation, useNavigate } from "react-router";
import {
  BarChart2, Users, HelpCircle, ChevronLeft, ChevronRight,
  Menu, X, Image, FileText, CheckSquare, Wallet, UserCog,
  LogOut, Crown, UserCheck, Projector
} from "lucide-react";
import { useAuth } from "../context/AuthContext";

import imgLogo from "figma:asset/315d8cb9df218a4d108c1796691e847942e27f6b.png";

export const NAV_ITEMS = [
  {
    label: "Análises",
    to: "/",
    icon: BarChart2,
    exact: true,
    adminOnly: true,
  },
  {
    label: "CRM",
    to: "/crm",
    icon: Users,
    exact: false,
    adminOnly: false,
    subItems: [
      { label: "Prospecção", to: "/crm", exact: true },
      { label: "Clientes", to: "/crm/clientes", exact: true },
      { label: "Copy Prospect", to: "/crm/copy-prospect", exact: true },
    ]
  },
  {
    label: "Financeiro",
    to: "/financeiro",
    icon: Wallet,
    exact: false,
    adminOnly: true,
  },
  {
    label: "Tarefas",
    to: "/tasks",
    icon: CheckSquare,
    exact: false,
    adminOnly: false,
  },
  {
    label: "Social Media",
    to: "/social-media",
    icon: Image,
    exact: false,
    adminOnly: false,
    subItems: [
      { label: "Gerenciar", to: "/social-media", exact: true },
      { label: "Repositório", to: "/social-media/repository", exact: true },
    ]
  },
  {
    label: "Orçamentos",
    to: "/quotes",
    icon: FileText,
    exact: false,
    adminOnly: true,
  },
  {
    label: "Usuários",
    to: "/users",
    icon: UserCog,
    exact: false,
    adminOnly: true,
  },
  {
    label: "PDF Syntax",
    to: "/pdf-syntax",
    icon: Projector,
    exact: false,
    adminOnly: false,
  },
];

export function Sidebar() {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();
  const { user, signOut, isAdmin } = useAuth();

  const isActive = (to: string, exact: boolean) => {
    if (exact) return location.pathname === to;
    return location.pathname.startsWith(to);
  };

  const handleLogout = async () => {
    await signOut();
    navigate("/login");
  };

  const visibleItems = NAV_ITEMS.filter(item => {
    if (isAdmin) return true;
    
    // Check custom permissions for members
    if (user?.permissions && Array.isArray(user.permissions)) {
      return user.permissions.includes(item.to);
    }
    
    // Default fallback if no permissions array exists (allow non-admin items)
    return !item.adminOnly;
  });

  const SidebarContent = ({ mobile = false }: { mobile?: boolean }) => (
    <div className={`flex flex-col h-full bg-zinc-900 text-zinc-50 border-r border-zinc-800 ${mobile ? "w-64" : collapsed ? "w-[88px]" : "w-64"} transition-all duration-300 ease-in-out`}>
      {/* Logo */}
      <div className={`flex items-center h-20 ${collapsed && !mobile ? "justify-center px-4" : "px-6"} border-b border-zinc-800 shrink-0`}>
        {(!collapsed || mobile) ? (
          <div className="flex items-center w-full">
            <img src={imgLogo} alt="Syntax Logo" className="h-[12rem] w-auto object-contain object-left" />
          </div>
        ) : (
          <div className="w-10 h-10 overflow-hidden relative rounded-2xl bg-zinc-800/50 border border-zinc-700 flex items-center justify-center shrink-0">
            <img src={imgLogo} alt="S" className="h-[250%] max-w-none object-left object-cover ml-[14px]" style={{ transform: 'scale(2.5)' }} />
          </div>
        )}
      </div>

      {/* Nav items */}
      <nav className="flex-1 py-6 space-y-1.5 px-4 overflow-y-auto">
        {visibleItems.map((item) => {
          const active = isActive(item.to, item.exact);
          const Icon = item.icon;
          return (
            <div key={item.to} className="space-y-1">
              <NavLink
                to={item.to}
                onClick={() => setMobileOpen(false)}
                className={`flex items-center gap-3 px-3 py-3 rounded-2xl transition-all group relative ${
                  active
                    ? "bg-emerald-500/10 text-emerald-400 font-semibold border border-emerald-500/20"
                    : "text-zinc-400 hover:bg-zinc-800/50 hover:text-zinc-50 font-medium border border-transparent"
                } ${collapsed && !mobile ? "justify-center" : ""}`}
              >
                <Icon className={`w-5 h-5 shrink-0 transition-colors ${active ? "text-emerald-500" : "text-zinc-500 group-hover:text-zinc-300"}`} />
                {(!collapsed || mobile) && (
                  <span className="text-sm">{item.label}</span>
                )}
                {/* Tooltip when collapsed */}
                {collapsed && !mobile && (
                  <div className="absolute left-full ml-4 px-3 py-2 bg-zinc-800 text-zinc-50 text-xs font-medium rounded-2xl shadow-xl opacity-0 group-hover:opacity-100 pointer-events-none whitespace-nowrap z-50 transition-all duration-200 translate-x-[-10px] group-hover:translate-x-0 border border-zinc-700">
                    {item.label}
                  </div>
                )}
              </NavLink>

              {/* Subitems */}
              {item.subItems && (!collapsed || mobile) && active && (
                <div className="pl-11 pr-2 py-1 flex flex-col gap-1">
                  {item.subItems.map(sub => {
                    const subActive = isActive(sub.to, sub.exact);
                    return (
                      <NavLink
                        key={sub.to}
                        to={sub.to}
                        onClick={() => setMobileOpen(false)}
                        end={sub.exact}
                        className={`block text-xs py-2 px-3 rounded-xl transition-all ${
                          subActive
                            ? "bg-emerald-500/10 text-emerald-400 font-medium border border-emerald-500/20"
                            : "text-zinc-500 hover:text-zinc-300 hover:bg-zinc-800/50"
                        }`}
                      >
                        {sub.label}
                      </NavLink>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </nav>

      {/* Bottom: User info + logout */}
      <div className="border-t border-zinc-800 p-4 space-y-2">
        {/* User card */}
        {(!collapsed || mobile) && user && (
          <div className="flex items-center gap-3 px-3 py-2.5 rounded-2xl bg-zinc-800/40 border border-zinc-800">
            <div className={`w-8 h-8 rounded-xl flex items-center justify-center text-xs font-bold shrink-0 ${isAdmin ? 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-400' : 'bg-zinc-700 border border-zinc-600 text-zinc-300'}`}>
              {user.name.charAt(0).toUpperCase()}
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-xs font-medium text-zinc-200 truncate">{user.name}</p>
              <div className="flex items-center gap-1">
                {isAdmin
                  ? <><Crown className="w-2.5 h-2.5 text-emerald-500" /><span className="text-[10px] text-emerald-500 font-medium">Administrador</span></>
                  : <><UserCheck className="w-2.5 h-2.5 text-zinc-500" /><span className="text-[10px] text-zinc-500">Membro</span></>
                }
              </div>
            </div>
          </div>
        )}

        {/* Collapse toggle (desktop only) */}
        {!mobile && (
          <button
            onClick={() => setCollapsed(!collapsed)}
            className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-2xl text-zinc-500 hover:bg-zinc-800/50 hover:text-zinc-50 transition-all ${collapsed ? "justify-center" : ""}`}
          >
            {collapsed ? <ChevronRight className="w-5 h-5" /> : <ChevronLeft className="w-5 h-5" />}
            {!collapsed && <span className="text-sm font-medium">Recolher</span>}
          </button>
        )}

        {/* Logout */}
        <button
          onClick={handleLogout}
          className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-2xl text-zinc-500 hover:bg-red-500/10 hover:text-red-400 transition-all group ${collapsed && !mobile ? "justify-center relative" : ""}`}
        >
          <LogOut className="w-5 h-5 shrink-0" />
          {(!collapsed || mobile) && <span className="text-sm font-medium">Sair</span>}
          {collapsed && !mobile && (
            <div className="absolute left-full ml-4 px-3 py-2 bg-zinc-800 text-zinc-50 text-xs font-medium rounded-2xl shadow-xl opacity-0 group-hover:opacity-100 pointer-events-none whitespace-nowrap z-50 border border-zinc-700">
              Sair
            </div>
          )}
        </button>
      </div>
    </div>
  );

  return (
    <>
      {/* Desktop sidebar */}
      <aside className="hidden md:flex h-screen sticky top-0 z-40 bg-zinc-900 print:hidden">
        <SidebarContent />
      </aside>

      {/* Mobile top bar */}
      <header className="md:hidden flex items-center justify-between bg-zinc-900 border-b border-zinc-800 px-4 h-16 sticky top-0 z-30 print:hidden">
        <img src={imgLogo} alt="Syntax Logo" className="h-8 w-auto object-contain" />
        <button onClick={() => setMobileOpen(true)} className="p-2 text-zinc-400 hover:bg-zinc-800/50 rounded-2xl transition-colors">
          <Menu className="w-6 h-6" />
        </button>
      </header>

      {/* Mobile drawer */}
      {mobileOpen && (
        <div className="fixed inset-0 z-50 md:hidden">
          <div className="absolute inset-0 bg-zinc-950/80 backdrop-blur-sm transition-opacity" onClick={() => setMobileOpen(false)} />
          <div className="absolute left-0 top-0 h-full w-64 bg-zinc-900 shadow-2xl transform transition-transform border-r border-zinc-800">
            <button
              onClick={() => setMobileOpen(false)}
              className="absolute top-5 right-4 p-2 text-zinc-500 hover:bg-zinc-800 rounded-2xl transition-colors z-50"
            >
              <X className="w-5 h-5" />
            </button>
            <SidebarContent mobile />
          </div>
        </div>
      )}
    </>
  );
}
