import { useEffect } from 'react';
import { Outlet, useNavigate } from 'react-router';
import { Sidebar } from './Sidebar';
import { useAuth } from '../context/AuthContext';
import { Loader2 } from 'lucide-react';

/**
 * Root — Layout protegido para rotas autenticadas.
 *
 * Comportamento:
 *   • Enquanto loading=true: exibe spinner (Supabase ainda está resolvendo a sessão).
 *   • Quando loading=false e user=null: redireciona para /login.
 *   • Quando loading=false e user≠null: renderiza Sidebar + Outlet.
 *
 * O guard `if (authLoading || !user) return` em useEffect é intencional:
 * previne re-fetch do Dashboard após signOut, quando a sessão se torna null
 * antes do redirect para /login completar.
 */
export function Root() {
  const { user, loading } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    // Só redireciona quando o Supabase terminou de resolver a sessão
    if (!loading && !user) {
      navigate('/login', { replace: true });
    }
  }, [user, loading, navigate]);

  // Supabase ainda resolvendo sessão (INITIAL_SESSION / TOKEN_REFRESHED)
  if (loading) {
    return (
      <div className="min-h-screen bg-zinc-950 flex items-center justify-center">
        <Loader2 className="w-8 h-8 text-emerald-500 animate-spin" />
      </div>
    );
  }

  // Usuário não autenticado — useEffect vai redirecionar para /login
  // Retornar null evita flash de conteúdo antes do redirect
  if (!user) return null;

  return (
    <div className="flex min-h-screen bg-zinc-950 font-sans text-zinc-100">
      <Sidebar />
      <div className="flex-1 min-w-0 overflow-auto">
        <Outlet />
      </div>
    </div>
  );
}
