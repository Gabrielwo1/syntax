import { useState, useCallback } from "react";
import {
  X, Signal, CheckCircle2, XCircle, Clock, AlertCircle,
  RefreshCw, Wifi, WifiOff, Activity, Zap, Terminal, ChevronDown, ChevronUp
} from "lucide-react";
import { fetchWithAuth } from "../utils/auth";
import { projectId } from "/utils/supabase/info";

const API_BASE = `https://${projectId}.supabase.co/functions/v1/make-server-cee56a32`;

interface TrackingVerifierModalProps {
  isOpen: boolean;
  onClose: () => void;
  siteId: string;
  siteName: string;
}

interface PingResult {
  ok: boolean;
  status: number;
  body: string;
  error?: string;
}

interface VerificationResult {
  status: "active" | "inactive" | "error";
  totalVisits: number;
  recentEvents: Array<{
    event: string;
    page: string;
    timestamp: string;
    userAgent?: string;
    screenSize?: string;
  }>;
  lastSeen?: string;
  errorMessage?: string;
  pingResult?: PingResult;
}

function timeAgo(isoString: string): string {
  const date = new Date(isoString);
  const now = new Date();
  const diffMs = now.getTime() - date.getTime();
  const diffSecs = Math.floor(diffMs / 1000);
  const diffMins = Math.floor(diffSecs / 60);
  const diffHours = Math.floor(diffMins / 60);
  const diffDays = Math.floor(diffHours / 24);

  if (diffSecs < 60) return `${diffSecs}s atrás`;
  if (diffMins < 60) return `${diffMins}min atrás`;
  if (diffHours < 24) return `${diffHours}h atrás`;
  return `${diffDays}d atrás`;
}

function getDeviceLabel(ua: string): string {
  if (!ua) return "Desconhecido";
  if (/mobile/i.test(ua)) return "📱 Mobile";
  if (/tablet|ipad/i.test(ua)) return "📟 Tablet";
  return "🖥️ Desktop";
}

function getEventLabel(event: string): { label: string; color: string } {
  switch (event) {
    case "pageview":
      return { label: "Pageview", color: "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20" };
    case "session_end":
      return { label: "Sessão encerrada", color: "bg-purple-500/10 text-purple-400 border border-purple-500/20" };
    case "external_link":
      return { label: "Link externo", color: "bg-orange-500/10 text-orange-400 border border-orange-500/20" };
    case "syntax_test_ping":
      return { label: "Teste de ping", color: "bg-teal-500/10 text-teal-400 border border-teal-500/20" };
    default:
      return { label: event, color: "bg-zinc-800 text-zinc-300 border border-zinc-700" };
  }
}

export function TrackingVerifierModal({ isOpen, onClose, siteId, siteName }: TrackingVerifierModalProps) {
  const [loading, setLoading] = useState(false);
  const [pingLoading, setPingLoading] = useState(false);
  const [result, setResult] = useState<VerificationResult | null>(null);
  const [hasChecked, setHasChecked] = useState(false);
  const [showDiag, setShowDiag] = useState(false);
  const [pingMsg, setPingMsg] = useState<{ ok: boolean; text: string } | null>(null);

  // Sends a real test event directly from the dashboard to prove the endpoint works
  const sendTestPing = useCallback(async () => {
    setPingLoading(true);
    setPingMsg(null);
    try {
      const testPayload = {
        siteId,
        event: "syntax_test_ping",
        page: "/dashboard-test",
        referrer: "",
        userAgent: navigator.userAgent,
        screenSize: `${window.screen.width}x${window.screen.height}`,
      };
      const res = await fetchWithAuth(`${API_BASE}/track`, {
        method: "POST",
        body: JSON.stringify(testPayload),
      });
      const body = await res.text();
      if (res.ok) {
        setPingMsg({ ok: true, text: `✅ Ping enviado com sucesso! (HTTP ${res.status}). Agora verifique novamente.` });
      } else {
        setPingMsg({ ok: false, text: `❌ Servidor retornou HTTP ${res.status}: ${body}` });
      }
    } catch (err: any) {
      setPingMsg({ ok: false, text: `❌ Erro de rede: ${err.message}` });
    } finally {
      setPingLoading(false);
    }
  }, [siteId]);

  const runVerification = useCallback(async () => {
    setLoading(true);
    setResult(null);
    setPingMsg(null);

    try {
      // First: test the health endpoint
      let pingResult: PingResult = { ok: false, status: 0, body: "" };

      try {
        const healthRes = await fetchWithAuth(`${API_BASE}/health`);
        pingResult = {
          ok: healthRes.ok,
          status: healthRes.status,
          body: JSON.stringify(await healthRes.json()),
        };
      } catch (err: any) {
        pingResult = { ok: false, status: 0, body: "", error: err.message };
      }

      if (!pingResult.ok) {
        setResult({
          status: "error",
          totalVisits: 0,
          recentEvents: [],
          pingResult,
          errorMessage: pingResult.error
            ? `Não foi possível conectar ao servidor: ${pingResult.error}`
            : `Servidor respondeu com HTTP ${pingResult.status}. Resposta: ${pingResult.body}`,
        });
        return;
      }

      // Fetch stats and events in parallel
      const [statsRes, eventsRes] = await Promise.all([
        fetchWithAuth(`${API_BASE}/analytics/${siteId}`),
        fetchWithAuth(`${API_BASE}/events/${siteId}?limit=5`),
      ]);

      if (!statsRes.ok) {
        const body = await statsRes.text();
        throw new Error(`Erro ao buscar analytics (HTTP ${statsRes.status}): ${body}`);
      }
      if (!eventsRes.ok) {
        const body = await eventsRes.text();
        throw new Error(`Erro ao buscar eventos (HTTP ${eventsRes.status}): ${body}`);
      }

      const statsData = await statsRes.json();
      const eventsData = await eventsRes.json();

      const recentEvents = eventsData.events || [];
      const totalVisits = statsData.totalVisits || 0;
      const lastSeen = recentEvents.length > 0 ? recentEvents[0].timestamp : undefined;

      setResult({
        status: totalVisits > 0 ? "active" : "inactive",
        totalVisits,
        recentEvents,
        lastSeen,
        pingResult,
      });
    } catch (err: any) {
      setResult({
        status: "error",
        totalVisits: 0,
        recentEvents: [],
        errorMessage: err.message || "Erro desconhecido",
      });
    } finally {
      setLoading(false);
      setHasChecked(true);
    }
  }, [siteId]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-zinc-950/80 backdrop-blur-sm flex items-center justify-center z-50 p-4 transition-all">
      <div className="bg-zinc-900 rounded-2xl shadow-2xl max-w-lg w-full max-h-[90vh] flex flex-col border border-zinc-800 animate-in fade-in zoom-in-95 duration-200">
        {/* Header */}
        <div className="flex items-center justify-between p-5 border-b border-zinc-800">
          <div className="flex items-center gap-3">
            <div className="w-9 h-9 bg-emerald-500/10 rounded-xl flex items-center justify-center border border-emerald-500/20">
              <Signal className="w-5 h-5 text-emerald-500" />
            </div>
            <div>
              <h2 className="text-lg font-bold text-zinc-50">Verificar Captação</h2>
              <p className="text-xs text-zinc-400">{siteName} · ID: <code className="bg-zinc-800 px-1 rounded">{siteId}</code></p>
            </div>
          </div>
          <button onClick={onClose} className="p-2 text-zinc-500 hover:text-zinc-300 hover:bg-zinc-800 rounded-xl transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Body */}
        <div className="p-5 overflow-auto flex-1 space-y-4">

          {/* Test Ping Button — always visible */}
          <div className="bg-zinc-800/30 rounded-2xl p-4 border border-zinc-700/50">
            <div className="flex items-start gap-3">
              <Zap className="w-5 h-5 text-amber-500 mt-0.5 shrink-0" />
              <div className="flex-1">
                <p className="text-sm font-semibold text-zinc-50 mb-0.5">Enviar evento de teste</p>
                <p className="text-xs text-zinc-400 mb-3">
                  Dispara um ping real para o servidor agora mesmo — sem precisar acessar o site do cliente. Confirma se o endpoint está funcionando.
                </p>
                <button
                  onClick={sendTestPing}
                  disabled={pingLoading}
                  className="flex items-center gap-2 px-3 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-50 text-sm rounded-xl transition-colors disabled:opacity-60 disabled:cursor-not-allowed font-medium border border-zinc-700"
                >
                  {pingLoading ? (
                    <><RefreshCw className="w-4 h-4 animate-spin text-amber-500" /> Enviando...</>
                  ) : (
                    <><Zap className="w-4 h-4 text-amber-500" /> Disparar ping de teste</>
                  )}
                </button>
                {pingMsg && (
                  <div className={`mt-3 text-xs p-2 rounded-xl ${pingMsg.ok ? "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20" : "bg-red-500/10 text-red-400 border border-red-500/20"}`}>
                    {pingMsg.text}
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Initial state */}
          {!hasChecked && !loading && (
            <div className="text-center py-6">
              <div className="w-14 h-14 bg-zinc-800/50 rounded-full flex items-center justify-center mx-auto mb-3 border border-zinc-700/50">
                <Activity className="w-7 h-7 text-zinc-500" />
              </div>
              <p className="text-zinc-300 text-sm font-medium">Clique em "Verificar agora"</p>
              <p className="text-zinc-500 text-xs mt-1">
                Consulta o servidor para checar se eventos estão sendo recebidos para este site.
              </p>
            </div>
          )}

          {/* Loading */}
          {loading && (
            <div className="text-center py-6">
              <div className="w-14 h-14 bg-emerald-500/10 rounded-full flex items-center justify-center mx-auto mb-3 animate-pulse border border-emerald-500/20">
                <RefreshCw className="w-7 h-7 text-emerald-500 animate-spin" />
              </div>
              <p className="text-zinc-300 text-sm font-medium">Consultando servidor...</p>
            </div>
          )}

          {/* Result */}
          {!loading && result && (
            <>
              {/* Status card */}
              <div
                className={`rounded-2xl p-4 border-2 flex items-start gap-3 ${
                  result.status === "active"
                    ? "bg-emerald-500/5 border-emerald-500/20"
                    : result.status === "inactive"
                    ? "bg-yellow-500/5 border-yellow-500/20"
                    : "bg-red-500/5 border-red-500/20"
                }`}
              >
                <div className="mt-0.5 shrink-0">
                  {result.status === "active" && <CheckCircle2 className="w-6 h-6 text-emerald-500" />}
                  {result.status === "inactive" && <AlertCircle className="w-6 h-6 text-yellow-500" />}
                  {result.status === "error" && <XCircle className="w-6 h-6 text-red-500" />}
                </div>
                <div className="flex-1">
                  {result.status === "active" && (
                    <>
                      <p className="font-bold text-emerald-500 flex items-center gap-2">
                        <Wifi className="w-4 h-4" /> Captação ativa!
                      </p>
                      <p className="text-emerald-400/80 text-xs mt-0.5">
                        Dados estão sendo recebidos corretamente do site do cliente.
                      </p>
                    </>
                  )}
                  {result.status === "inactive" && (
                    <>
                      <p className="font-bold text-yellow-500 flex items-center gap-2">
                        <WifiOff className="w-4 h-4" /> Nenhum dado recebido ainda
                      </p>
                      <p className="text-yellow-400/80 text-xs mt-0.5">
                        O servidor está online, mas nenhum evento chegou ainda para este site. Veja as dicas abaixo.
                      </p>
                    </>
                  )}
                  {result.status === "error" && (
                    <>
                      <p className="font-bold text-red-500">Erro ao verificar</p>
                      <p className="text-red-400/80 text-xs mt-0.5 break-all">{result.errorMessage}</p>
                    </>
                  )}
                </div>
              </div>

              {/* Stats row */}
              {result.status !== "error" && (
                <div className="grid grid-cols-2 gap-3">
                  <div className="bg-zinc-800/30 rounded-2xl p-3 border border-zinc-700/50">
                    <p className="text-xs text-zinc-500 mb-1">Total de eventos</p>
                    <p className="text-2xl font-bold text-zinc-50">{result.totalVisits.toLocaleString()}</p>
                  </div>
                  <div className="bg-zinc-800/30 rounded-2xl p-3 border border-zinc-700/50">
                    <p className="text-xs text-zinc-500 mb-1">Último evento</p>
                    {result.lastSeen ? (
                      <p className="text-sm font-semibold text-zinc-50 flex items-center gap-1.5 mt-1">
                        <Clock className="w-4 h-4 text-zinc-400" />
                        {timeAgo(result.lastSeen)}
                      </p>
                    ) : (
                      <p className="text-sm text-zinc-500 mt-1">—</p>
                    )}
                  </div>
                </div>
              )}

              {/* Recent events */}
              {result.recentEvents.length > 0 && (
                <div>
                  <h3 className="text-sm font-semibold text-zinc-300 mb-3 flex items-center gap-2">
                    <Activity className="w-4 h-4" />
                    Últimos eventos recebidos
                  </h3>
                  <div className="space-y-2">
                    {result.recentEvents.map((ev, i) => {
                      const { label, color } = getEventLabel(ev.event);
                      return (
                        <div
                          key={i}
                          className="flex items-start gap-3 p-3 bg-zinc-800/30 rounded-2xl border border-zinc-700/50"
                        >
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 flex-wrap mb-1.5">
                              <span className={`text-xs font-medium px-2 py-0.5 rounded-lg ${color}`}>
                                {label}
                              </span>
                              <span className="text-xs text-zinc-500">{timeAgo(ev.timestamp)}</span>
                            </div>
                            <p className="text-xs text-zinc-300 truncate">
                              📄 {ev.page || "/"}
                            </p>
                            {ev.userAgent && (
                              <p className="text-xs text-zinc-500 mt-1">{getDeviceLabel(ev.userAgent)}</p>
                            )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Help tip when inactive */}
              {result.status === "inactive" && (
                <div className="bg-zinc-800/50 rounded-2xl p-4 border border-zinc-700">
                  <p className="text-xs text-zinc-300 font-semibold mb-2">💡 Possíveis causas:</p>
                  <ul className="text-xs text-zinc-400 space-y-2">
                    <li>⚠️ <strong>Código desatualizado instalado</strong> — copie o código novamente (agora inclui a chave de autenticação necessária)</li>
                    <li>📋 O código não foi colado antes de <code className="bg-zinc-700 px-1 rounded text-zinc-300">&lt;/body&gt;</code></li>
                    <li>🌐 O site ainda não recebeu visitantes reais</li>
                    <li>🔌 Extensões como uBlock Origin podem estar bloqueando</li>
                    <li>🔑 ID do site no código: <strong>{siteId}</strong> — confira se bate</li>
                  </ul>
                  <p className="text-xs text-emerald-400/80 font-medium mt-3">👆 Use o "Disparar ping de teste" acima para confirmar se o endpoint recebe dados corretamente.</p>
                </div>
              )}

              {/* Diagnostics toggle */}
              {result.pingResult && (
                <button
                  onClick={() => setShowDiag(!showDiag)}
                  className="flex items-center gap-1.5 text-xs text-zinc-500 hover:text-zinc-300 transition-colors mt-2"
                >
                  <Terminal className="w-3.5 h-3.5" />
                  Detalhes técnicos
                  {showDiag ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                </button>
              )}
              {showDiag && result.pingResult && (
                <div className="bg-zinc-950 text-zinc-400 rounded-2xl p-3 text-xs font-mono space-y-1.5 border border-zinc-800 mt-2">
                  <p><span className="text-zinc-600">Endpoint:</span> {API_BASE}/health</p>
                  <p><span className="text-zinc-600">Status:</span> <span className={result.pingResult.ok ? "text-emerald-500" : "text-red-500"}>{result.pingResult.status || "sem resposta"}</span></p>
                  <p><span className="text-zinc-600">Resposta:</span> {result.pingResult.body || result.pingResult.error || "—"}</p>
                  <p><span className="text-zinc-600">SiteId buscado:</span> {siteId}</p>
                </div>
              )}
            </>
          )}
        </div>

        {/* Footer */}
        <div className="p-5 border-t border-zinc-800 flex gap-3">
          <button
            onClick={runVerification}
            disabled={loading}
            className="flex-1 flex items-center justify-center gap-2 px-4 py-2.5 bg-emerald-600 text-white rounded-2xl hover:bg-emerald-700 transition-colors disabled:opacity-60 disabled:cursor-not-allowed font-medium text-sm shadow-lg shadow-emerald-900/20"
          >
            {loading ? (
              <><RefreshCw className="w-4 h-4 animate-spin" /> Verificando...</>
            ) : hasChecked ? (
              <><RefreshCw className="w-4 h-4" /> Verificar novamente</>
            ) : (
              <><Signal className="w-4 h-4" /> Verificar agora</>
            )}
          </button>
          <button
            onClick={onClose}
            className="px-5 py-2.5 border border-zinc-700 text-zinc-300 rounded-2xl hover:bg-zinc-800 transition-colors text-sm font-medium"
          >
            Fechar
          </button>
        </div>
      </div>
    </div>
  );
}