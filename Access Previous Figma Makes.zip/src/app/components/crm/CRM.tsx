import { useState, useEffect, useMemo } from "react";
import { useLocation, useNavigate } from "react-router";
import {
  Plus, Search, Filter, Users, TrendingUp, DollarSign, Target,
  Mail, Phone, Calendar, Tag, RefreshCw, Kanban,
  List, AlertCircle, Folder, MoreVertical, Sparkles, Upload,
  Edit2, Trash2
} from "lucide-react";
import { projectId } from "/utils/supabase/info";
import { fetchWithAuth } from "../../utils/auth";
import { useAuth } from "../../context/AuthContext";
import { LeadModal, type Lead } from "./LeadModal";
import { LeadDetailModal, STAGES, PRIORITY_MAP } from "./LeadDetailModal";

const API = `https://${projectId}.supabase.co/functions/v1/make-server-cee56a32`;

function sourceColor(source: string) {
  const map: Record<string, string> = {
    Instagram: "bg-pink-500/10 text-pink-400 border border-pink-500/20",
    Google: "bg-blue-500/10 text-blue-400 border border-blue-500/20",
    Indicação: "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20",
    LinkedIn: "bg-sky-500/10 text-sky-400 border border-sky-500/20",
    WhatsApp: "bg-green-500/10 text-green-400 border border-green-500/20",
    Facebook: "bg-indigo-500/10 text-indigo-400 border border-indigo-500/20",
  };
  return map[source] || "bg-zinc-800 text-zinc-300 border border-zinc-700";
}

function formatDateShort(iso: string | null) {
  if (!iso) return null;
  try {
    const d = new Date(iso);
    return d.toLocaleDateString("pt-BR", { day: "2-digit", month: "short" });
  } catch { return null; }
}

function isOverdue(dateStr: string | null) {
  if (!dateStr) return false;
  return new Date(dateStr) < new Date(new Date().toDateString());
}

// ─── Lead Card (Kanban) ───────────────────────────────────────────────────────
function LeadKanbanCard({ lead, onClick, onConvertToClient }: { lead: Lead; onClick: () => void; onConvertToClient?: (lead: Lead) => void }) {
  const overdue = isOverdue(lead.nextFollowUp);

  return (
    <div
      onClick={onClick}
      className="bg-zinc-900 rounded-2xl border border-zinc-800 p-4 cursor-pointer shadow-xl shadow-black/20 hover:border-emerald-500/50 transition-all group relative"
    >
      <div className="flex items-start justify-between gap-2 mb-3">
        <div className="flex-1 min-w-0 pr-6">
          <p className="font-bold text-zinc-50 text-sm truncate group-hover:text-emerald-400 transition-colors">{lead.name}</p>
          {lead.company && <p className="text-xs font-medium text-zinc-500 truncate mt-0.5">{lead.company}</p>}
        </div>
      </div>

      {/* Botão de conversão que aparece no hover */}
      {onConvertToClient && !lead.isClient && (
        <button
          onClick={(e) => {
            e.stopPropagation();
            onConvertToClient(lead);
          }}
          className="absolute right-4 top-[50px] bg-emerald-600 hover:bg-emerald-500 text-white text-[10px] font-bold px-2 py-1 rounded-lg opacity-0 group-hover:opacity-100 transition-opacity shadow-lg z-10"
        >
          VIRAR CLIENTE
        </button>
      )}

      <div className="space-y-2 mb-4">
        {lead.email && (
          <div className="flex items-center gap-2 text-xs font-medium text-zinc-400">
            <div className="bg-zinc-800/50 p-1 rounded-md border border-zinc-700/50"><Mail className="w-3.5 h-3.5" /></div>
            <span className="truncate">{lead.email}</span>
          </div>
        )}
        {lead.phone && (
          <div className="flex items-center gap-2 text-xs font-medium text-zinc-400">
            <div className="bg-zinc-800/50 p-1 rounded-md border border-zinc-700/50"><Phone className="w-3.5 h-3.5" /></div>
            <span>{lead.phone}</span>
          </div>
        )}
      </div>

      <div className="flex items-center gap-1.5 flex-wrap">
        {lead.source && (
          <span className={`text-[11px] font-bold px-2 py-1 rounded-lg ${sourceColor(lead.source)}`}>
            {lead.source}
          </span>
        )}
        {lead.service && (
          <span className="text-[11px] font-bold px-2 py-1 rounded-lg bg-zinc-800 text-zinc-300 border border-zinc-700 truncate max-w-[120px]">
            {lead.service}
          </span>
        )}
      </div>

      {(lead.nextFollowUp || lead.budget) && (
        <div className="mt-3 pt-3 border-t border-zinc-800 flex items-center justify-between">
          {lead.nextFollowUp ? (
            <div className={`flex items-center gap-1.5 text-xs font-semibold ${overdue ? "text-rose-500" : "text-zinc-500"}`}>
              <Calendar className="w-3.5 h-3.5" />
              <span>{overdue ? "Atrasado: " : ""}{formatDateShort(lead.nextFollowUp)}</span>
            </div>
          ) : <div />}
          
          {lead.budget && (
            <div className="flex items-center gap-1 text-xs font-bold text-emerald-500">
              <DollarSign className="w-3.5 h-3.5 text-emerald-500" />
              <span>{lead.budget}</span>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

// ─── Lead Row (List view) ─────────────────────────────────────────────────────
function LeadListRow({ lead, onClick, onConvertToClient }: { lead: Lead; onClick: () => void; onConvertToClient?: (lead: Lead) => void }) {
  const stage = STAGES.find((s) => s.id === lead.stage);
  const overdue = isOverdue(lead.nextFollowUp);

  return (
    <tr
      onClick={onClick}
      className="border-b border-zinc-800 hover:bg-zinc-800/30 cursor-pointer transition-colors"
    >
      <td className="px-4 py-3">
        <p className="font-medium text-zinc-50 text-sm">{lead.name}</p>
        <p className="text-xs text-zinc-500">{lead.company}</p>
      </td>
      <td className="px-4 py-3 text-sm text-zinc-400 hidden md:table-cell">
        <a href={`mailto:${lead.email}`} className="hover:text-emerald-500 truncate block max-w-[180px]" onClick={(e) => e.stopPropagation()}>
          {lead.email}
        </a>
      </td>
      <td className="px-4 py-3 hidden lg:table-cell">
        <span className={`text-xs px-2 py-1 rounded-full font-medium ${stage?.color || "bg-zinc-800 text-zinc-300"}`}>
          {stage?.label || lead.stage}
        </span>
      </td>
      <td className="px-4 py-3 hidden xl:table-cell text-sm text-zinc-400">
        {lead.service || "—"}
      </td>
      <td className="px-4 py-3 hidden lg:table-cell">
        {lead.nextFollowUp ? (
          <span className={`text-xs ${overdue ? "text-red-500 font-medium" : "text-zinc-500"}`}>
            {formatDateShort(lead.nextFollowUp)}
          </span>
        ) : <span className="text-xs text-zinc-600">—</span>}
      </td>
      <td className="px-4 py-3 hidden md:table-cell">
        {lead.source && (
          <span className={`text-xs px-2 py-1 rounded-full ${sourceColor(lead.source)}`}>
            {lead.source}
          </span>
        )}
      </td>
      <td className="px-4 py-3 text-right">
        {onConvertToClient && !lead.isClient && (
          <button
            onClick={(e) => {
              e.stopPropagation();
              onConvertToClient(lead);
            }}
            className="bg-emerald-600/10 text-emerald-500 hover:bg-emerald-600 hover:text-white border border-emerald-500/20 text-xs font-semibold px-3 py-1.5 rounded-lg transition-all shadow-sm"
          >
            Virar Cliente
          </button>
        )}
      </td>
    </tr>
  );
}

// ─── Main CRM Page ────────────────────────────────────────────────────────────
export function CRM() {
  const location = useLocation();
  const navigate = useNavigate();
  const { loading: authLoading } = useAuth();
  const activeSubmenu = location.pathname.includes("/clientes") ? "clientes" : "prospeccao";

  const setActiveSubmenu = (tab: "prospeccao" | "clientes") => {
    if (tab === "clientes") navigate("/crm/clientes");
    else navigate("/crm");
  };

  const [leads, setLeads] = useState<Lead[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [view, setView] = useState<"kanban" | "list">("kanban");
  const [search, setSearch] = useState("");
  const [filterStage, setFilterStage] = useState("all");
  const [filterSource, setFilterSource] = useState("all");
  
  // Pastas
  const [folders, setFolders] = useState<{id: string, name: string}[]>([
    { id: "geral", name: "Geral" },
    { id: "b2b", name: "Leads B2B" },
    { id: "e-commerce", name: "E-commerce" },
    { id: "clinicas-sudoeste", name: "Clínicas Sudoeste" }
  ]);
  const [activeFolder, setActiveFolder] = useState<string>("geral");
  const [isFolderModalOpen, setIsFolderModalOpen] = useState(false);
  const [editingFolderId, setEditingFolderId] = useState<string | null>(null);
  const [newFolderName, setNewFolderName] = useState("");

  const [showLeadModal, setShowLeadModal] = useState(false);
  const [showAiModal, setShowAiModal] = useState(false);
  const [editingLead, setEditingLead] = useState<Lead | null>(null);
  const [detailLead, setDetailLead] = useState<Lead | null>(null);

  const loadLeads = async () => {
    setLoading(true);
    setError(null);
    try {
      const res = await fetchWithAuth(`${API}/crm/leads`);
      const data = await res.json();
      if (!res.ok) throw new Error(data.error || data.message || `Erro ao carregar leads (${res.status})`);
      setLeads(data.leads || []);
    } catch (err: any) {
      console.error("[CRM] load error:", err);
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const loadFolders = async () => {
    try {
      const res = await fetchWithAuth(`${API}/crm/folders`);
      if (!res.ok) {
        console.error("Erro do servidor ao carregar pastas:", res.status, res.statusText);
        return;
      }
      const data = await res.json();
      if (data.folders) {
        setFolders(data.folders);
      }
    } catch (err) {
      console.error("Erro ao carregar pastas:", err);
    }
  };

  useEffect(() => {
    if (authLoading) return;
    loadLeads();
    loadFolders();
  }, [authLoading]);

  const handleSaveLead = async (form: Partial<Lead>) => {
    // Ensure the lead is saved to the currently active folder
    const folderId = form.folderId || (activeFolder === "todos" ? "geral" : activeFolder);
    const dataToSave = { ...form, folderId };
    
    // Provide default email/name to prevent backend error if one is missing but the other is provided
    if (!dataToSave.name && dataToSave.email) dataToSave.name = dataToSave.email.split('@')[0];
    if (!dataToSave.email && dataToSave.name) dataToSave.email = `${dataToSave.name.toLowerCase().replace(/\s+/g, '')}@example.com`;

    // Fallback absoluto: se os dados forem enviados sem nome e email
    if (!dataToSave.name && !dataToSave.email) {
       dataToSave.name = "Lead Sem Nome";
       dataToSave.email = `sem_email_${Math.floor(Math.random() * 10000)}@exemplo.com`;
    }

    try {
      if (editingLead) {
        const res = await fetchWithAuth(`${API}/crm/leads/${encodeURIComponent(editingLead.id)}`, {
          method: "PUT",
          body: JSON.stringify(dataToSave),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "Erro ao atualizar lead");
        setLeads((prev) => prev.map((l) => l.id === editingLead.id ? data.lead : l));
        if (detailLead?.id === editingLead.id) setDetailLead(data.lead);
      } else {
        const res = await fetchWithAuth(`${API}/crm/leads`, {
          method: "POST",
          body: JSON.stringify(dataToSave),
        });
        const data = await res.json();
        if (!res.ok) throw new Error(data.error || "Erro ao criar lead");
        setLeads((prev) => [data.lead, ...prev]);
      }
      setEditingLead(null);
    } catch (err) {
      console.error("Erro ao salvar lead:", err);
      alert("Houve um erro ao salvar o lead. Verifique se os dados estão corretos.");
    }
  };

  const handleStageChange = async (lead: Lead, stage: string) => {
    const res = await fetchWithAuth(`${API}/crm/leads/${encodeURIComponent(lead.id)}`, {
      method: "PUT",
      body: JSON.stringify({ stage }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error);
    setLeads((prev) => prev.map((l) => l.id === lead.id ? data.lead : l));
    if (detailLead?.id === lead.id) setDetailLead(data.lead);
  };

  const handleAddNote = async (lead: Lead, note: string) => {
    const res = await fetchWithAuth(`${API}/crm/leads/${encodeURIComponent(lead.id)}`, {
      method: "PUT",
      body: JSON.stringify({ activityNote: note }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data.error);
    setLeads((prev) => prev.map((l) => l.id === lead.id ? data.lead : l));
    if (detailLead?.id === lead.id) setDetailLead(data.lead);
  };

  const handleDelete = async (lead: Lead) => {
    await fetchWithAuth(`${API}/crm/leads/${encodeURIComponent(lead.id)}`, {
      method: "DELETE",
    });
    setLeads((prev) => prev.filter((l) => l.id !== lead.id));
    setDetailLead(null);
  };

  const handleSaveFolder = async () => {
    if (!newFolderName.trim()) return;
    let newFolders;
    if (editingFolderId) {
      newFolders = folders.map(f => f.id === editingFolderId ? { ...f, name: newFolderName.trim() } : f);
      setFolders(newFolders);
      setEditingFolderId(null);
    } else {
      const newFolder = {
        id: `folder_${Date.now()}`,
        name: newFolderName.trim()
      };
      newFolders = [...folders, newFolder];
      setFolders(newFolders);
      setActiveFolder(newFolder.id);
    }
    
    setNewFolderName("");
    setIsFolderModalOpen(false);

    try {
      await fetchWithAuth(`${API}/crm/folders`, {
        method: "PUT",
        body: JSON.stringify({ folders: newFolders }),
      });
    } catch (err) {
      console.error("Erro ao salvar pastas:", err);
    }
  };

  const handleDeleteFolder = async (e: React.MouseEvent, folderId: string) => {
    e.stopPropagation();
    if (window.confirm("Tem certeza que deseja excluir esta pasta? Os leads não serão excluídos.")) {
      const newFolders = folders.filter(f => f.id !== folderId);
      setFolders(newFolders);
      if (activeFolder === folderId) {
        setActiveFolder("todos");
      }

      try {
        await fetchWithAuth(`${API}/crm/folders`, {
          method: "PUT",
          body: JSON.stringify({ folders: newFolders }),
        });
      } catch (err) {
        console.error("Erro ao salvar pastas:", err);
      }
    }
  };

  const handleConvertToClient = async (lead: Lead) => {
    try {
      // 1. Mark as client in CRM and change stage to "fechado"
      const resCrm = await fetchWithAuth(`${API}/crm/leads/${encodeURIComponent(lead.id)}`, {
        method: "PUT",
        body: JSON.stringify({ isClient: true, stage: "fechado" }),
      });
      if (!resCrm.ok) throw new Error("Erro ao atualizar lead");
      const dataCrm = await resCrm.json();

      setLeads((prev) => prev.map((l) => l.id === lead.id ? dataCrm.lead : l));

      // 2. Create site in Analytics
      const clientName = lead.company || lead.name;
      const autoUrl = lead.website || `https://${clientName.toLowerCase().replace(/\\s+/g, '')}.com.br`;
      
      await fetchWithAuth(`${API}/sites`, {
        method: "POST",
        body: JSON.stringify({
          name: clientName,
          url: autoUrl,
          clientName: clientName,
          clientEmail: lead.email || `contato@${clientName.toLowerCase().replace(/\\s+/g, '')}.com`,
          clientPhone: lead.phone || "(11) 9999-9999",
        }),
      });

      // 3. Switch to Clients tab
      setActiveSubmenu("clientes");
    } catch (err) {
      console.error("Erro ao converter lead para cliente", err);
      alert("Houve um erro ao converter o lead para cliente.");
    }
  };

  // Filtered leads
  const filtered = useMemo(() => {
    return leads.filter((l) => {
      // Separar por aba (Prospecção vs Clientes)
      const isLeadClient = l.isClient === true;
      if (activeSubmenu === "prospeccao" && isLeadClient) return false;
      if (activeSubmenu === "clientes" && !isLeadClient) return false;

      // Filtragem por pasta
      const leadFolder = l.folderId || "geral";
      const matchFolder = activeFolder === "todos" || leadFolder === activeFolder;

      const q = search.toLowerCase();
      const matchSearch = !q || l.name.toLowerCase().includes(q) || l.email.toLowerCase().includes(q) || (l.company || "").toLowerCase().includes(q);
      const matchStage = filterStage === "all" || l.stage === filterStage;
      const matchSource = filterSource === "all" || l.source === filterSource;
      return matchFolder && matchSearch && matchStage && matchSource;
    });
  }, [leads, search, filterStage, filterSource, activeFolder, activeSubmenu]);

  // Stats
  const stats = useMemo(() => {
    const prospecLeads = leads.filter((l) => !l.isClient);
    const clientsLeads = leads.filter((l) => l.isClient);
    
    if (activeSubmenu === "clientes") {
      return { 
        total: clientsLeads.length, 
        fechados: clientsLeads.length, 
        ativos: 0, 
        perdidos: 0, 
        convRate: 100 
      };
    }

    const total = prospecLeads.length;
    const fechados = prospecLeads.filter((l) => l.stage === "fechado").length;
    const ativos = prospecLeads.filter((l) => !["fechado", "perdido"].includes(l.stage)).length;
    const perdidos = prospecLeads.filter((l) => l.stage === "perdido").length;
    const convRate = total > 0 ? Math.round((fechados / total) * 100) : 0;
    return { total, fechados, ativos, perdidos, convRate };
  }, [leads, activeSubmenu]);

  // Kanban columns
  const kanbanCols = STAGES.map((stage) => ({
    ...stage,
    leads: filtered.filter((l) => l.stage === stage.id),
  }));

  // Sources for filter
  const sources = useMemo(() => {
    const s = new Set(leads.map((l) => l.source).filter(Boolean));
    return Array.from(s);
  }, [leads]);

  return (
    <div className="flex flex-col h-full min-h-screen bg-zinc-950">
      {/* Folder Navigation */}
      {activeSubmenu === "prospeccao" && (
        <div className="bg-zinc-900 border-b border-zinc-800 px-6 pt-3 flex items-end gap-2 overflow-x-auto no-scrollbar">
          <button
            onClick={() => setActiveFolder("todos")}
            className={`flex items-center gap-2 px-4 py-2.5 rounded-t-xl border-b-2 font-medium text-sm transition-colors whitespace-nowrap ${
              activeFolder === "todos" 
                ? "border-emerald-500 text-emerald-400 bg-zinc-800/50" 
                : "border-transparent text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/30"
            }`}
          >
            <Search className="w-4 h-4" />
            Todos os Leads
          </button>
          
          {folders.map(folder => (
            <div
              key={folder.id}
              className={`group flex items-center gap-1.5 px-4 py-2.5 rounded-t-xl border-b-2 font-medium text-sm transition-colors whitespace-nowrap cursor-pointer ${
                activeFolder === folder.id 
                  ? "border-emerald-500 text-emerald-400 bg-zinc-800/50" 
                  : "border-transparent text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/30"
              }`}
              onClick={() => setActiveFolder(folder.id)}
            >
              <Folder className="w-4 h-4" />
              <span>{folder.name}</span>
              {folder.id !== "geral" && (
                <div className={`flex items-center gap-1 ml-1 ${activeFolder === folder.id ? "opacity-100" : "opacity-0 group-hover:opacity-100"} transition-opacity`}>
                  <button 
                    onClick={(e) => { e.stopPropagation(); setEditingFolderId(folder.id); setNewFolderName(folder.name); setIsFolderModalOpen(true); }} 
                    className="p-1 text-zinc-500 hover:text-emerald-400 hover:bg-zinc-700/50 rounded"
                    title="Editar Pasta"
                  >
                    <Edit2 className="w-3 h-3" />
                  </button>
                  <button 
                    onClick={(e) => handleDeleteFolder(e, folder.id)} 
                    className="p-1 text-zinc-500 hover:text-rose-400 hover:bg-zinc-700/50 rounded"
                    title="Excluir Pasta"
                  >
                    <Trash2 className="w-3 h-3" />
                  </button>
                </div>
              )}
            </div>
          ))}
          
          <div className="ml-auto flex items-center mb-1.5 px-2">
            <button
              onClick={() => { setEditingFolderId(null); setNewFolderName(""); setIsFolderModalOpen(true); }}
              className="flex items-center gap-1.5 px-3 py-1.5 text-xs font-medium text-zinc-400 hover:text-emerald-400 hover:bg-emerald-500/10 rounded-lg transition-colors border border-dashed border-zinc-700 hover:border-emerald-500/30"
            >
              <Plus className="w-3.5 h-3.5" />
              Nova Pasta
            </button>
          </div>
        </div>
      )}

      {/* Page header */}
      <div className="bg-zinc-900 border-b border-zinc-800 px-8 py-6">
        <div className="flex items-center justify-between gap-4 flex-wrap">
          <div className="flex flex-col gap-3">
            <div className="flex items-center gap-4">
              <h1 className="text-3xl font-bold tracking-tight text-zinc-50">CRM</h1>
              <div className="flex bg-zinc-950 rounded-xl p-1 border border-zinc-800">
                <button
                  onClick={() => setActiveSubmenu("prospeccao")}
                  className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-all ${
                    activeSubmenu === "prospeccao" ? "bg-zinc-800 text-zinc-50 shadow" : "text-zinc-400 hover:text-zinc-200"
                  }`}
                >
                  Prospecção
                </button>
                <button
                  onClick={() => setActiveSubmenu("clientes")}
                  className={`px-4 py-1.5 rounded-lg text-sm font-medium transition-all ${
                    activeSubmenu === "clientes" ? "bg-emerald-600 text-white shadow" : "text-zinc-400 hover:text-zinc-200"
                  }`}
                >
                  Clientes
                </button>
              </div>
            </div>
            <p className="text-sm font-medium text-zinc-400">
              {activeSubmenu === "prospeccao" 
                ? "Gerencie seus leads e oportunidades de negócio"
                : "Acompanhe seus clientes ativos"}
            </p>
          </div>
          <div className="flex items-center gap-3">
            <button
              onClick={loadLeads}
              disabled={loading}
              className="p-2.5 text-zinc-400 hover:text-zinc-50 bg-zinc-900 border border-zinc-800 hover:bg-zinc-800 rounded-2xl transition-all shadow-sm"
              title="Atualizar"
            >
              <RefreshCw className={`w-4 h-4 ${loading ? "animate-spin" : ""}`} />
            </button>
            {activeSubmenu === "prospeccao" && (
              <div className="flex items-center gap-2">
                <button
                  onClick={() => setShowAiModal(true)}
                  className="flex items-center gap-2 px-4 py-2.5 bg-zinc-800 text-emerald-400 border border-zinc-700 hover:border-emerald-500/50 hover:bg-zinc-800/80 rounded-2xl transition-all font-medium text-sm"
                >
                  <Sparkles className="w-4 h-4" />
                  <span className="hidden sm:inline">Importar c/ IA</span>
                </button>
                <button
                  onClick={() => { setEditingLead(null); setShowLeadModal(true); }}
                  className="flex items-center gap-2 px-5 py-2.5 bg-emerald-600 text-white rounded-2xl hover:bg-emerald-700 transition-colors font-medium text-sm shadow-lg shadow-emerald-900/20"
                >
                  <Plus className="w-4 h-4" />
                  Novo Lead
                </button>
              </div>
            )}
          </div>
        </div>

        {/* Stats */}
        {activeSubmenu === "prospeccao" ? (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-6">
            <StatCard icon={<Users className="w-5 h-5 text-emerald-500" />} bg="bg-emerald-500/10" border="border-emerald-500/20" label="Total de Leads" value={stats.total} />
            <StatCard icon={<Target className="w-5 h-5 text-emerald-500" />} bg="bg-emerald-500/10" border="border-emerald-500/20" label="Fechados" value={stats.fechados} />
            <StatCard icon={<TrendingUp className="w-5 h-5 text-emerald-500" />} bg="bg-emerald-500/10" border="border-emerald-500/20" label="Em Andamento" value={stats.ativos} />
            <StatCard icon={<DollarSign className="w-5 h-5 text-emerald-500" />} bg="bg-emerald-500/10" border="border-emerald-500/20" label="Taxa de Conv." value={`${stats.convRate}%`} />
          </div>
        ) : (
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mt-6">
            <StatCard icon={<Users className="w-5 h-5 text-emerald-500" />} bg="bg-emerald-500/10" border="border-emerald-500/20" label="Total de Clientes" value={stats.total} />
            <div className="hidden sm:block" />
            <div className="hidden sm:block" />
            <div className="hidden sm:block" />
          </div>
        )}
      </div>

      {/* Toolbar */}
      <div className="bg-zinc-900 border-b border-zinc-800 px-6 py-4 flex items-center gap-4 flex-wrap">
        {/* Search */}
        <div className="relative flex-1 min-w-[200px]">
          <Search className="absolute left-3.5 top-2.5 w-4 h-4 text-zinc-500" />
          <input
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Buscar por nome, empresa ou e-mail..."
            className="w-full pl-10 pr-4 py-2 border border-zinc-800 rounded-2xl text-sm focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all bg-zinc-950 text-zinc-50 placeholder:text-zinc-600"
          />
        </div>

        {/* Filters */}
        <div className="flex items-center gap-3 flex-wrap">
          <div className="flex items-center gap-2 text-zinc-500">
            <Filter className="w-4 h-4 shrink-0" />
          </div>
          {activeSubmenu === "prospeccao" && (
            <select
              value={filterStage}
              onChange={(e) => setFilterStage(e.target.value)}
              className="text-sm border border-zinc-800 rounded-2xl px-3 py-2 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 bg-zinc-950 text-zinc-50 transition-all cursor-pointer font-medium"
            >
              <option value="all">Todos os estágios</option>
              {STAGES.map((s) => <option key={s.id} value={s.id}>{s.label}</option>)}
            </select>
          )}
          {sources.length > 0 && (
            <select
              value={filterSource}
              onChange={(e) => setFilterSource(e.target.value)}
              className="text-sm border border-zinc-800 rounded-2xl px-3 py-2 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 bg-zinc-950 text-zinc-50 transition-all cursor-pointer font-medium"
            >
              <option value="all">Todas origens</option>
              {sources.map((s) => <option key={s}>{s}</option>)}
            </select>
          )}
        </div>

        {/* View toggle */}
        {activeSubmenu === "prospeccao" && (
          <div className="flex bg-zinc-950 rounded-2xl p-1 ml-auto shrink-0 border border-zinc-800">
            <button
              onClick={() => setView("kanban")}
              className={`p-2 rounded-xl transition-all flex items-center justify-center ${view === "kanban" ? "bg-zinc-800 shadow-sm text-emerald-500 font-medium" : "text-zinc-500 hover:text-zinc-300 hover:bg-zinc-900"}`}
              title="Kanban"
            >
              <Kanban className="w-4 h-4" />
            </button>
            <button
              onClick={() => setView("list")}
              className={`p-2 rounded-xl transition-all flex items-center justify-center ${view === "list" ? "bg-zinc-800 shadow-sm text-emerald-500 font-medium" : "text-zinc-500 hover:text-zinc-300 hover:bg-zinc-900"}`}
              title="Lista"
            >
              <List className="w-4 h-4" />
            </button>
          </div>
        )}
      </div>

      {/* Content */}
      <div className="flex-1 overflow-auto p-6">
        {loading && (
          <div className="flex items-center justify-center h-48">
            <RefreshCw className="w-6 h-6 text-emerald-500 animate-spin" />
            <span className="ml-3 text-zinc-400">Carregando leads...</span>
          </div>
        )}

        {error && !loading && (
          <div className="flex items-start gap-3 bg-red-500/10 border border-red-500/20 rounded-2xl p-4 max-w-lg mx-auto mt-8">
            <AlertCircle className="w-5 h-5 text-red-500 shrink-0" />
            <div>
              <p className="font-semibold text-red-400 text-sm">Erro ao carregar</p>
              <p className="text-red-300 text-xs mt-1">{error}</p>
              <button onClick={loadLeads} className="mt-2 text-xs text-red-400 underline">Tentar novamente</button>
            </div>
          </div>
        )}

        {!loading && !error && leads.filter(l => !l.isClient).length === 0 && activeSubmenu === "prospeccao" && (
          <div className="flex flex-col items-center justify-center h-[50vh] text-center max-w-md mx-auto">
            <div className="w-20 h-20 bg-emerald-500/10 rounded-3xl flex items-center justify-center mb-6 shadow-sm border border-emerald-500/20">
              <Users className="w-10 h-10 text-emerald-500" />
            </div>
            <p className="text-xl text-zinc-50 font-bold tracking-tight">Nenhum lead ainda</p>
            <p className="text-zinc-400 text-sm mt-2 mb-8 leading-relaxed">Cadastre seu primeiro lead para começar a gerenciar suas oportunidades de negócio no funil de vendas.</p>
            <button
              onClick={() => { setEditingLead(null); setShowLeadModal(true); }}
              className="flex items-center gap-2 px-6 py-3 bg-emerald-600 text-white rounded-2xl hover:bg-emerald-700 transition-colors text-sm font-semibold shadow-lg shadow-emerald-900/20"
            >
              <Plus className="w-4 h-4" /> Cadastrar primeiro lead
            </button>
          </div>
        )}

        {/* Kanban view */}
        {!loading && !error && leads.filter(l => !l.isClient).length > 0 && activeSubmenu === "prospeccao" && view === "kanban" && (
          <div className="flex gap-5 overflow-x-auto pb-6 px-1" style={{ minHeight: "60vh" }}>
            {kanbanCols.map((col) => (
              <div key={col.id} className="flex-shrink-0 w-[300px] flex flex-col">
                {/* Column header */}
                <div className={`flex items-center justify-between px-4 py-3 rounded-2xl border mb-4 shadow-sm bg-zinc-900/80 backdrop-blur-sm ${col.color.replace('bg-', 'border-').replace('text-', 'text-').replace('100', '500/20').replace('800', '400')}`}>
                  <div className="flex items-center gap-3">
                    <span className="text-sm font-bold tracking-tight text-zinc-100">{col.label}</span>
                    <span className="text-xs font-bold bg-zinc-800 text-zinc-300 px-2 py-1 rounded-lg shadow-sm border border-zinc-700">
                      {col.leads.length}
                    </span>
                  </div>
                  {col.id === "novo" && (
                    <button
                      onClick={() => { setEditingLead(null); setShowLeadModal(true); }}
                      className="w-7 h-7 flex items-center justify-center rounded-xl bg-zinc-800 hover:bg-zinc-700 shadow-sm transition-all text-zinc-300 border border-zinc-700"
                    >
                      <Plus className="w-4 h-4" />
                    </button>
                  )}
                </div>

                {/* Cards */}
                <div className="space-y-3 flex-1">
                  {col.leads.map((lead) => (
                    <LeadKanbanCard
                      key={lead.id}
                      lead={lead}
                      onClick={() => setDetailLead(lead)}
                      onConvertToClient={handleConvertToClient}
                    />
                  ))}
                  {col.leads.length === 0 && (
                    <div className="text-center py-8 text-zinc-600 text-xs font-medium border-2 border-dashed border-zinc-800 rounded-2xl bg-zinc-900/50">
                      Nenhum lead
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>
        )}

        {/* List view */}
        {!loading && !error && leads.filter(l => !l.isClient).length > 0 && activeSubmenu === "prospeccao" && view === "list" && (
          <div className="bg-zinc-900 rounded-2xl border border-zinc-800 overflow-hidden shadow-xl shadow-black/20">
            <table className="w-full">
              <thead className="bg-zinc-950/50 border-b border-zinc-800">
                <tr>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-zinc-400">Nome</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-zinc-400 hidden md:table-cell">E-mail</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-zinc-400 hidden lg:table-cell">Estágio</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-zinc-400 hidden xl:table-cell">Serviço</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-zinc-400 hidden lg:table-cell">Follow-up</th>
                  <th className="px-4 py-3 text-left text-xs font-semibold text-zinc-400 hidden md:table-cell">Origem</th>
                  <th className="px-4 py-3 text-right text-xs font-semibold text-zinc-400">Ações</th>
                </tr>
              </thead>
              <tbody>
                {filtered.map((lead) => (
                  <LeadListRow key={lead.id} lead={lead} onClick={() => setDetailLead(lead)} onConvertToClient={handleConvertToClient} />
                ))}
                {filtered.length === 0 && (
                  <tr>
                    <td colSpan={8} className="px-4 py-10 text-center text-sm text-zinc-500">
                      Nenhum lead encontrado com os filtros selecionados
                    </td>
                  </tr>
                )}
              </tbody>
            </table>
            {filtered.length > 0 && (
              <div className="px-4 py-3 border-t border-zinc-800 text-xs text-zinc-500">
                {filtered.length} lead{filtered.length !== 1 ? "s" : ""} encontrado{filtered.length !== 1 ? "s" : ""}
              </div>
            )}
          </div>
        )}

        {/* Clientes Grid View */}
        {!loading && !error && activeSubmenu === "clientes" && (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-4 gap-4">
            {filtered.map((lead) => (
              <div
                key={lead.id}
                onClick={() => setDetailLead(lead)}
                className="bg-emerald-900/10 rounded-2xl border border-emerald-500/20 p-5 cursor-pointer shadow-xl shadow-black/20 hover:border-emerald-500/50 transition-all group"
              >
                <div className="flex items-start justify-between gap-2 mb-3">
                  <div className="flex-1 min-w-0">
                    <p className="font-bold text-zinc-50 text-base truncate group-hover:text-emerald-400 transition-colors">{lead.name}</p>
                    {lead.company && <p className="text-sm font-medium text-emerald-500/80 truncate mt-0.5">{lead.company}</p>}
                  </div>
                </div>
                <div className="space-y-2 mt-4">
                  {lead.email && (
                    <div className="flex items-center gap-2 text-xs font-medium text-zinc-400">
                      <Mail className="w-3.5 h-3.5" />
                      <span className="truncate">{lead.email}</span>
                    </div>
                  )}
                  {lead.phone && (
                    <div className="flex items-center gap-2 text-xs font-medium text-zinc-400">
                      <Phone className="w-3.5 h-3.5" />
                      <span>{lead.phone}</span>
                    </div>
                  )}
                </div>
              </div>
            ))}
            {filtered.length === 0 && (
              <div className="col-span-full flex flex-col items-center justify-center py-20 text-center">
                <div className="w-16 h-16 bg-zinc-900 rounded-full flex items-center justify-center mb-4 border border-zinc-800">
                  <Users className="w-8 h-8 text-zinc-600" />
                </div>
                <p className="text-zinc-300 font-medium">Nenhum cliente encontrado</p>
                <p className="text-zinc-500 text-sm mt-1">Converta leads em clientes para vê-los aqui.</p>
              </div>
            )}
          </div>
        )}
      </div>

      {/* Lead modal (add/edit) */}
      <LeadModal
        isOpen={showLeadModal}
        onClose={() => { setShowLeadModal(false); setEditingLead(null); }}
        onSave={handleSaveLead}
        lead={editingLead}
      />

      {/* Lead detail modal */}
      {detailLead && (
        <LeadDetailModal
          isOpen={!!detailLead}
          onClose={() => setDetailLead(null)}
          lead={leads.find((l) => l.id === detailLead.id) || detailLead}
          onEdit={() => { setEditingLead(detailLead); setShowLeadModal(true); setDetailLead(null); }}
          onDelete={() => handleDelete(detailLead)}
          onStageChange={(stage) => handleStageChange(detailLead, stage)}
          onAddNote={(note) => handleAddNote(detailLead, note)}
          onConvertToClient={(lead) => {
            setDetailLead(null);
            handleConvertToClient(lead);
          }}
        />
      )}

      {/* New/Edit Folder Modal */}
      {isFolderModalOpen && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-zinc-950/80 backdrop-blur-sm p-4">
          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl shadow-2xl w-full max-w-sm flex flex-col overflow-hidden ring-1 ring-white/5">
            <div className="px-6 py-4 border-b border-zinc-800 bg-zinc-900/50">
              <h2 className="text-lg font-semibold text-zinc-50">{editingFolderId ? "Editar Pasta" : "Criar Nova Pasta"}</h2>
            </div>
            <div className="p-6">
              <label className="block text-sm font-medium text-zinc-300 mb-1.5">Nome da Pasta</label>
              <input
                autoFocus
                value={newFolderName}
                onChange={e => setNewFolderName(e.target.value)}
                onKeyDown={e => e.key === 'Enter' && handleSaveFolder()}
                placeholder="Ex: Lançamentos 2024"
                className="w-full px-3 py-2 bg-zinc-950/50 border border-zinc-800 rounded-xl text-sm text-zinc-50 placeholder-zinc-600 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500 transition-all"
              />
            </div>
            <div className="border-t border-zinc-800 bg-zinc-900/50 px-6 py-4 flex gap-3">
              <button
                onClick={handleSaveFolder}
                disabled={!newFolderName.trim()}
                className="flex-1 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-medium text-sm transition-colors shadow-[0_0_15px_rgba(16,185,129,0.2)] disabled:opacity-50"
              >
                {editingFolderId ? "Salvar" : "Criar Pasta"}
              </button>
              <button
                onClick={() => { setIsFolderModalOpen(false); setNewFolderName(""); setEditingFolderId(null); }}
                className="px-4 py-2 border border-zinc-700 bg-zinc-800 text-zinc-300 rounded-xl text-sm hover:bg-zinc-700 hover:text-white transition-colors"
              >
                Cancelar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* AI Import Modal */}
      {showAiModal && (
        <AiImportModal
          existingLeads={leads}
          onClose={() => setShowAiModal(false)}
          onImport={async (importedLeads) => {
            // Use o endpoint bulk para evitar race condition no crm:leads:list
            const folderId = activeFolder === "todos" ? "geral" : activeFolder;
            try {
              const res = await fetchWithAuth(`${API}/crm/leads/bulk`, {
                method: "POST",
                body: JSON.stringify({ leads: importedLeads, folderId }),
              });
              const data = await res.json();
              if (!res.ok) throw new Error(data.error || "Erro ao importar leads em lote");
              // Adiciona todos os leads criados ao estado de uma vez
              setLeads(prev => [...(data.leads || []), ...prev]);
            } catch (err: any) {
              console.error("[CRM] Bulk import error:", err);
              alert(`Houve um erro ao importar os leads: ${err.message}`);
            }
            setShowAiModal(false);
          }}
        />
      )}
    </div>
  );
}

// ─── Duplicate detection helpers ─────────────────────────────────────────────
function normalizePhone(phone: string): string {
  return phone.replace(/\D/g, "").slice(-8); // compara pelos últimos 8 dígitos
}

function isAutoEmail(email: string): boolean {
  return !email || email.endsWith("@exemplo.com") || email.includes("desconhecido_");
}

type DuplicateReason = "phone" | "email" | "name";

function findDuplicate(lead: Partial<Lead>, existingLeads: Lead[]): { match: Lead; reason: DuplicateReason } | null {
  const phone = lead.phone ? normalizePhone(lead.phone) : "";
  const email = (lead.email || "").toLowerCase().trim();
  const name = (lead.name || "").toLowerCase().trim();

  for (const ex of existingLeads) {
    // Phone match (strongest signal — only if both have real phones)
    if (phone && phone.length >= 8 && ex.phone) {
      if (normalizePhone(ex.phone) === phone) return { match: ex, reason: "phone" };
    }
    // Email match (only if not auto-generated)
    if (email && !isAutoEmail(email) && ex.email && !isAutoEmail(ex.email)) {
      if (ex.email.toLowerCase().trim() === email) return { match: ex, reason: "email" };
    }
    // Name match (weakest — only if name is substantial)
    if (name.length > 3 && ex.name) {
      if (ex.name.toLowerCase().trim() === name) return { match: ex, reason: "name" };
    }
  }
  return null;
}

const DUPLICATE_REASON_LABEL: Record<DuplicateReason, string> = {
  phone: "Telefone já cadastrado",
  email: "E-mail já cadastrado",
  name: "Nome já cadastrado",
};

// ─── AI Import Modal ─────────────────────────────────────────────────────────
function AiImportModal({ onClose, onImport, existingLeads = [] }: {
  onClose: () => void;
  onImport: (leads: Partial<Lead>[]) => void;
  existingLeads?: Lead[];
}) {
  const [text, setText] = useState("");
  const [isProcessing, setIsProcessing] = useState(false);
  const [step, setStep] = useState<"input" | "preview">("input");
  const [previewLeads, setPreviewLeads] = useState<Partial<Lead>[]>([]);
  // Track which leads the user wants to skip (duplicates auto-deselected)
  const [skipped, setSkipped] = useState<Set<number>>(new Set());

  // Simulação de processamento de IA
  const handleProcess = () => {
    if (!text.trim()) return;
    setIsProcessing(true);
    setSkipped(new Set());
    
    // Simula tempo de resposta da IA
    setTimeout(() => {
      const extractedLeads: Partial<Lead>[] = [];
      // Tenta separar em blocos (um lead por bloco, separados por linhas em branco)
      const blocks = text.split(/\n\s*\n/).filter(b => b.trim().length > 0);

      const parseBlock = (block: string) => {
        const lead: Partial<Lead> = { stage: "novo", priority: "media", source: "WhatsApp" };
        
        // Regex para extrair email
        const emailMatch = block.match(/[a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9_-]+/);
        if (emailMatch) lead.email = emailMatch[0];
        
        // Regex para extrair telefone (brasileiro ou internacional genérico)
        const phoneMatch = block.match(/(?:\+?55\s?)?(?:\(?\d{2}\)?\s?)?(?:9\s?)?\d{4}[-\s]?\d{4}/);
        if (phoneMatch) lead.phone = phoneMatch[0].trim();
        
        const lines = block.split('\n').map(l => l.trim()).filter(l => l.length > 0);
        lines.forEach(line => {
          const lower = line.toLowerCase();
          if (lower.startsWith('nome:') || lower.startsWith('lead:') || lower.startsWith('cliente:')) {
            lead.name = line.substring(line.indexOf(':') + 1).trim();
          } else if (lower.startsWith('empresa:') || lower.startsWith('company:')) {
            lead.company = line.substring(line.indexOf(':') + 1).trim();
          } else if (!lead.name && !line.includes('@') && !line.match(/\d{8}/) && line.length < 50) {
            // Se ainda não temos nome e a linha não é email nem telefone, assumimos que é o nome
            lead.name = line;
          }
        });

        // Fallback para nome
        if (!lead.name && lead.email) {
           lead.name = lead.email.split('@')[0];
        } else if (!lead.name && !lead.email) {
           lead.name = "Lead Desconhecido";
        }
        
        return lead;
      };

      if (blocks.length > 1 && !text.includes('|')) {
        // Múltiplos blocos detectados (e não parece ser tabela), processar cada um como um lead independente
        blocks.forEach(b => extractedLeads.push(parseBlock(b)));
      } else {
        // Apenas um bloco grande de texto ou lista tabular
        const lines = text.split('\n').filter(l => l.trim().length > 0);
        
        // Verifica se é uma lista tabular (onde a maioria das linhas tem pipe ou um telefone)
        const tabularLines = lines.filter(line => line.includes('|') || line.match(/(?:\(?\d{2}\)?\s?)?(?:9\s?)?\d{4}[-\s]?\d{4}/));
        const isTabularList = tabularLines.length >= lines.length / 2 && lines.length > 0;

        if (isTabularList) {
          lines.forEach(line => {
            const lead: Partial<Lead> = { stage: "novo", priority: "media", source: "WhatsApp" };
            
            // Tenta extrair telefone
            const phoneMatch = line.match(/(?:\+?55\s?)?(?:\(?\d{2}\)?\s?)?(?:9\s?)?\d{4}[-\s]?\d{4}/);
            if (phoneMatch) {
              lead.phone = phoneMatch[0].trim();
            }

            // Isolar a primeira parte da string para pegar a empresa e a cidade
            let namePart = line;
            if (namePart.includes(' | ')) {
              namePart = namePart.split(' | ')[0];
            } else if (namePart.includes('|')) {
              namePart = namePart.split('|')[0];
            }
            
            // Extrai a cidade se houver o padrão " - Cidade"
            if (namePart.includes(' - ')) {
              const parts = namePart.split(' - ');
              lead.name = parts[0].trim();
              const possibleCity = parts[1].trim();
              // Se a cidade for válida (não for um sim/não), adicionamos como uma nota
              if (possibleCity.toLowerCase() !== "sim" && possibleCity.toLowerCase() !== "não") {
                lead.notes = `Cidade: ${possibleCity}`;
              }
            } else {
              lead.name = namePart.trim();
            }

            lead.company = lead.name; // Coloca a empresa também

            // Extrair email se tiver perdido no meio da linha
            const emailMatch = line.match(/[a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9_-]+/);
            if (emailMatch) lead.email = emailMatch[0];

            if (lead.name || lead.phone) {
              extractedLeads.push(lead);
            }
          });
        } else {
          // Processamento padrão linha a linha
          let currentLead: Partial<Lead> | null = null;
          lines.forEach(line => {
            const lowerLine = line.toLowerCase();
            
            if (lowerLine.startsWith('nome:') || lowerLine.startsWith('lead:') || lowerLine.startsWith('cliente:')) {
              if (currentLead && (currentLead.name || currentLead.email)) extractedLeads.push(currentLead);
              currentLead = { stage: "novo", priority: "media", source: "WhatsApp", name: line.substring(line.indexOf(':') + 1).trim() };
            } else {
              if (!currentLead) {
                 currentLead = { stage: "novo", priority: "media", source: "WhatsApp" };
                 if (!line.includes('@') && !line.match(/\d{8}/) && line.length < 50) {
                   currentLead.name = line.trim();
                 }
              }
              
              if (lowerLine.includes('@') && !currentLead.email) {
                currentLead.email = line.match(/[a-zA-Z0-9._-]+@[a-zA-Z0-9._-]+\.[a-zA-Z0-9_-]+/)?.[0];
              } else if ((lowerLine.includes('tel') || line.match(/(?:\(?\d{2}\)?\s?)?(?:9\s?)?\d{4}[-\s]?\d{4}/)) && !currentLead.phone) {
                currentLead.phone = (line.match(/(?:\(?\d{2}\)?\s?)?(?:9\s?)?\d{4}[-\s]?\d{4}/)?.[0] || line).trim();
              } else if (lowerLine.startsWith('empresa:')) {
                currentLead.company = line.substring(line.indexOf(':') + 1).trim();
              } else if (!currentLead.name && !line.includes('@') && !line.match(/\d{8}/) && line.length < 50) {
                currentLead.name = line.trim();
              }
            }
          });
          if (currentLead && (currentLead.name || currentLead.email)) extractedLeads.push(currentLead);
        }
        
        // Se ainda estiver vazio, fallback pro texto bruto
        if (extractedLeads.length === 0) {
           extractedLeads.push(parseBlock(text));
        }
      }

      // Garante que todo lead tenha pelo menos nome ou email para não quebrar a API
      extractedLeads.forEach(lead => {
          if (!lead.name && lead.email) {
            lead.name = lead.email.split('@')[0];
          } else if (!lead.name && !lead.email) {
            lead.name = "Lead Desconhecido";
            lead.email = `desconhecido_${Math.floor(Math.random()*10000)}@exemplo.com`;
          } else if (lead.name && !lead.email) {
            lead.email = `${lead.name.toLowerCase().replace(/\s+/g, '')}@exemplo.com`;
          }
        });

      setPreviewLeads(extractedLeads);
      // Auto-mark duplicates as skipped
      const autoSkipped = new Set<number>();
      extractedLeads.forEach((lead, idx) => {
        if (findDuplicate(lead, existingLeads)) autoSkipped.add(idx);
      });
      setSkipped(autoSkipped);
      setIsProcessing(false);
      setStep("preview");
    }, 1500);
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    if (e.dataTransfer.files && e.dataTransfer.files.length > 0) {
      // Simular leitura do print (OCR simulado)
      setIsProcessing(true);
      setTimeout(() => {
        setPreviewLeads([
          { name: "João da Silva (Print)", email: "joao@exemplo.com", phone: "(11) 98888-7777", stage: "novo", priority: "alta", source: "Instagram" },
          { name: "Maria Oliveira (Print)", email: "maria@empresaxpto.com", company: "Empresa XPTO", phone: "(11) 99999-5555", stage: "novo", priority: "media", source: "Instagram" }
        ]);
        setIsProcessing(false);
        setStep("preview");
      }, 2000);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-zinc-950/80 backdrop-blur-sm p-4">
      <div className="bg-zinc-900 border border-zinc-800 rounded-2xl w-full max-w-2xl overflow-hidden shadow-2xl flex flex-col max-h-[90vh]">
        <div className="px-6 py-4 border-b border-zinc-800 flex items-center justify-between">
          <div className="flex items-center gap-2 text-emerald-400">
            <Sparkles className="w-5 h-5" />
            <h3 className="font-bold text-zinc-50">Assistente de Cadastro via IA</h3>
          </div>
          <button onClick={onClose} className="text-zinc-500 hover:text-zinc-300">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round"><line x1="18" y1="6" x2="6" y2="18"></line><line x1="6" y1="6" x2="18" y2="18"></line></svg>
          </button>
        </div>

        <div className="p-6 overflow-y-auto">
          {step === "input" ? (
            <div className="space-y-6">
              <p className="text-sm text-zinc-400">
                Cole uma lista de dados, e-mails, ou informações de contato. A nossa Inteligência Artificial vai identificar os padrões e organizar tudo em leads separados para você.
              </p>
              
              <div className="space-y-3">
                <label className="text-xs font-semibold text-zinc-300 uppercase tracking-wider">Texto bruto</label>
                <textarea
                  value={text}
                  onChange={(e) => setText(e.target.value)}
                  placeholder="Ex:\nNome: Carlos Costa\nEmpresa: Tech Soluções\nEmail: carlos@techsolucoes.com\nTelefone: (11) 99999-1111\n\nNome: Ana Silva\n..."
                  className="w-full h-40 bg-zinc-950 border border-zinc-800 rounded-xl p-4 text-sm text-zinc-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 resize-none"
                />
              </div>

              <div className="relative">
                <div className="absolute inset-0 flex items-center">
                  <span className="w-full border-t border-zinc-800" />
                </div>
                <div className="relative flex justify-center text-xs uppercase">
                  <span className="bg-zinc-900 px-2 text-zinc-500 font-medium">Ou via Imagem/Print</span>
                </div>
              </div>

              <div 
                onDragOver={handleDragOver}
                onDrop={handleDrop}
                className="border-2 border-dashed border-zinc-700 hover:border-emerald-500/50 bg-zinc-950/50 rounded-xl h-24 flex items-center justify-center transition-colors group cursor-pointer"
                onClick={() => {
                   setIsProcessing(true);
                   setTimeout(() => {
                     setPreviewLeads([
                       { name: "Lead Capturado 1", company: "Empresa 1", phone: "(11) 91111-2222", stage: "novo", priority: "alta" },
                       { name: "Lead Capturado 2", email: "contato@empresa2.com", stage: "novo", priority: "media" }
                     ]);
                     setIsProcessing(false);
                     setStep("preview");
                   }, 1500);
                }}
              >
                <div className="flex flex-col items-center gap-1">
                  <Upload className="w-5 h-5 text-zinc-500 group-hover:text-emerald-500 transition-colors" />
                  <span className="text-sm font-medium text-zinc-400">Arraste um print (ou clique para simular OCR)</span>
                </div>
              </div>
            </div>
          ) : (() => {
            const duplicateCount = previewLeads.filter((l, i) => findDuplicate(l, existingLeads) && skipped.has(i)).length;
            const newCount = previewLeads.filter((_, i) => !skipped.has(i)).length;
            return (
              <div className="space-y-4">
                {/* Summary banner */}
                <div className="flex flex-col gap-2">
                  <div className="bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 px-4 py-3 rounded-xl flex items-center gap-3 text-sm">
                    <Sparkles className="w-5 h-5 shrink-0" />
                    <span>
                      <strong className="font-bold">{previewLeads.length}</strong> leads identificados —{" "}
                      <strong className="font-bold text-emerald-300">{newCount} novo{newCount !== 1 ? "s" : ""}</strong>
                      {duplicateCount > 0 && (
                        <span className="text-amber-400">, <strong>{duplicateCount} duplicado{duplicateCount !== 1 ? "s" : ""}</strong> desmarcado{duplicateCount !== 1 ? "s" : ""}</span>
                      )}
                    </span>
                  </div>
                  {duplicateCount > 0 && (
                    <div className="flex gap-2">
                      <button
                        onClick={() => {
                          const allDupeIdx = new Set(previewLeads.map((l, i) => findDuplicate(l, existingLeads) ? i : -1).filter(i => i !== -1));
                          setSkipped(allDupeIdx);
                        }}
                        className="text-xs px-3 py-1.5 rounded-lg bg-amber-500/10 border border-amber-500/20 text-amber-400 hover:bg-amber-500/20 transition-colors font-medium"
                      >
                        Desmarcar todos os duplicados
                      </button>
                      <button
                        onClick={() => setSkipped(new Set())}
                        className="text-xs px-3 py-1.5 rounded-lg bg-zinc-800 border border-zinc-700 text-zinc-300 hover:bg-zinc-700 transition-colors font-medium"
                      >
                        Selecionar todos
                      </button>
                    </div>
                  )}
                </div>

                <div className="space-y-3 max-h-[340px] overflow-y-auto pr-1">
                  {previewLeads.map((lead, idx) => {
                    const dup = findDuplicate(lead, existingLeads);
                    const isSkipped = skipped.has(idx);
                    const toggleSkip = () => setSkipped(prev => {
                      const next = new Set(prev);
                      if (next.has(idx)) next.delete(idx); else next.add(idx);
                      return next;
                    });

                    return (
                      <div
                        key={idx}
                        className={`border rounded-xl p-4 relative transition-all ${
                          isSkipped
                            ? "bg-zinc-900/30 border-zinc-800 opacity-50"
                            : dup
                            ? "bg-amber-500/5 border-amber-500/30"
                            : "bg-zinc-950 border-zinc-800"
                        }`}
                      >
                        {/* Checkbox + duplicate badge row */}
                        <div className="flex items-center justify-between mb-3">
                          <label className="flex items-center gap-2 cursor-pointer select-none" onClick={toggleSkip}>
                            <div className={`w-4 h-4 rounded border flex items-center justify-center transition-colors ${!isSkipped ? "bg-emerald-600 border-emerald-500" : "border-zinc-600 bg-zinc-800"}`}>
                              {!isSkipped && (
                                <svg width="10" height="10" viewBox="0 0 12 12" fill="none" stroke="white" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><polyline points="2,6 5,9 10,3"/></svg>
                              )}
                            </div>
                            <span className={`text-xs font-semibold ${isSkipped ? "text-zinc-500 line-through" : "text-zinc-200"}`}>
                              {lead.name || "—"}
                            </span>
                          </label>
                          <div className="flex items-center gap-2">
                            {dup && (
                              <span className="text-[10px] font-bold px-2 py-0.5 rounded-full bg-amber-500/15 border border-amber-500/30 text-amber-400 flex items-center gap-1">
                                <svg width="10" height="10" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5"><path d="M10.29 3.86L1.82 18a2 2 0 001.71 3h16.94a2 2 0 001.71-3L13.71 3.86a2 2 0 00-3.42 0z"/><line x1="12" y1="9" x2="12" y2="13"/><line x1="12" y1="17" x2="12.01" y2="17"/></svg>
                                {DUPLICATE_REASON_LABEL[dup.reason]}
                              </span>
                            )}
                          </div>
                        </div>

                        {/* Duplicate match info */}
                        {dup && (
                          <div className="mb-3 text-[10px] text-amber-400/80 bg-amber-500/5 border border-amber-500/15 rounded-lg px-3 py-1.5">
                            Coincide com: <span className="font-bold">{dup.match.name}</span>
                            {dup.match.company ? ` · ${dup.match.company}` : ""}
                            {dup.reason === "phone" && dup.match.phone ? ` · ${dup.match.phone}` : ""}
                            {dup.reason === "email" && dup.match.email ? ` · ${dup.match.email}` : ""}
                          </div>
                        )}

                        <div className="grid grid-cols-2 gap-y-2 gap-x-4">
                          <div>
                            <label className="text-[10px] uppercase text-zinc-500 font-bold block mb-1">Nome</label>
                            <input
                              value={lead.name || ""}
                              onChange={(e) => {
                                const newLeads = [...previewLeads];
                                newLeads[idx] = { ...newLeads[idx], name: e.target.value };
                                setPreviewLeads(newLeads);
                              }}
                              className="w-full bg-zinc-900 border-b border-zinc-800 text-sm text-zinc-100 py-1 focus:outline-none focus:border-emerald-500 transition-colors"
                            />
                          </div>
                          <div>
                            <label className="text-[10px] uppercase text-zinc-500 font-bold block mb-1">Empresa</label>
                            <input
                              value={lead.company || ""}
                              onChange={(e) => {
                                const newLeads = [...previewLeads];
                                newLeads[idx] = { ...newLeads[idx], company: e.target.value };
                                setPreviewLeads(newLeads);
                              }}
                              className="w-full bg-zinc-900 border-b border-zinc-800 text-sm text-zinc-100 py-1 focus:outline-none focus:border-emerald-500 transition-colors"
                            />
                          </div>
                          <div>
                            <label className="text-[10px] uppercase text-zinc-500 font-bold block mb-1">E-mail</label>
                            <input
                              value={lead.email || ""}
                              onChange={(e) => {
                                const newLeads = [...previewLeads];
                                newLeads[idx] = { ...newLeads[idx], email: e.target.value };
                                setPreviewLeads(newLeads);
                              }}
                              className="w-full bg-zinc-900 border-b border-zinc-800 text-sm text-zinc-100 py-1 focus:outline-none focus:border-emerald-500 transition-colors"
                            />
                          </div>
                          <div>
                            <label className="text-[10px] uppercase text-zinc-500 font-bold block mb-1">Telefone</label>
                            <input
                              value={lead.phone || ""}
                              onChange={(e) => {
                                const newLeads = [...previewLeads];
                                newLeads[idx] = { ...newLeads[idx], phone: e.target.value };
                                setPreviewLeads(newLeads);
                              }}
                              className="w-full bg-zinc-900 border-b border-zinc-800 text-sm text-zinc-100 py-1 focus:outline-none focus:border-emerald-500 transition-colors"
                            />
                          </div>
                        </div>
                      </div>
                    );
                  })}
                </div>
              </div>
            );
          })()}
        </div>

        <div className="px-6 py-4 border-t border-zinc-800 bg-zinc-900/50 flex justify-end gap-3">
          <button
            onClick={onClose}
            className="px-4 py-2 border border-zinc-700 bg-zinc-800 text-zinc-300 rounded-xl text-sm font-medium hover:bg-zinc-700 hover:text-white transition-colors"
          >
            Cancelar
          </button>
          {step === "input" ? (
            <button
              onClick={handleProcess}
              disabled={isProcessing || !text.trim()}
              className="flex items-center gap-2 px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-sm font-medium transition-colors shadow-lg disabled:opacity-50"
            >
              {isProcessing ? (
                <>
                  <div className="w-4 h-4 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                  Analisando...
                </>
              ) : (
                <>
                  <Sparkles className="w-4 h-4" />
                  Processar Dados
                </>
              )}
            </button>
          ) : (() => {
            const toImport = previewLeads.filter((_, i) => !skipped.has(i));
            return (
              <button
                onClick={() => onImport(toImport)}
                disabled={toImport.length === 0}
                className="flex items-center gap-2 px-5 py-2 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl text-sm font-medium transition-colors shadow-lg disabled:opacity-40 disabled:cursor-not-allowed"
              >
                <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round"><path d="M21 15v4a2 2 0 01-2 2H5a2 2 0 01-2-2v-4"/><polyline points="17 8 12 3 7 8"/><line x1="12" y1="3" x2="12" y2="15"/></svg>
                Importar {toImport.length} Lead{toImport.length !== 1 ? "s" : ""}
              </button>
            );
          })()}
        </div>
      </div>
    </div>
  );
}

function StatCard({ icon, bg, border, label, value }: { icon: React.ReactNode; bg: string; border?: string; label: string; value: string | number }) {
  return (
    <div className={`bg-zinc-900 rounded-2xl border ${border || 'border-zinc-800'} shadow-xl shadow-black/20 p-4 flex items-center gap-4 transition-all hover:border-zinc-700`}>
      <div className={`w-12 h-12 ${bg} rounded-xl flex items-center justify-center shrink-0 border ${border || 'border-transparent'}`}>
        {icon}
      </div>
      <div>
        <p className="text-sm font-medium text-zinc-400">{label}</p>
        <p className="text-2xl font-bold text-zinc-50 leading-tight mt-0.5">{value}</p>
      </div>
    </div>
  );
}
