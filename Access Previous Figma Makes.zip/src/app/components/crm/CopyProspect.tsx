import { useState, useEffect } from "react";
import { Plus, Trash2, Edit2, Copy, Check, MessageCircle, X } from "lucide-react";
import { toast } from "sonner";
import { fetchWithAuth } from "../../utils/auth";
import { projectId } from "/utils/supabase/info";

const API = `https://${projectId}.supabase.co/functions/v1/make-server-cee56a32`;

interface Template {
  id: string;
  title: string;
  content: string;
}

interface Group {
  id: string;
  name: string;
  templates: Template[];
}

export function CopyProspect() {
  const [groups, setGroups] = useState<Group[]>([]);
  const [loading, setLoading] = useState(true);

  // Group Editing State
  const [isEditingGroup, setIsEditingGroup] = useState<string | null>(null);
  const [editGroupName, setEditGroupName] = useState("");

  // Template Editing State
  const [isEditingTemplate, setIsEditingTemplate] = useState<{ groupId: string, templateId: string | null } | null>(null);
  const [editTemplateTitle, setEditTemplateTitle] = useState("");
  const [editTemplateContent, setEditTemplateContent] = useState("");

  // Copy State
  const [copiedId, setCopiedId] = useState<string | null>(null);

  useEffect(() => {
    fetchGroups();
  }, []);

  const fetchGroups = async () => {
    try {
      const res = await fetchWithAuth(`${API}/crm/copy-prospect`);
      if (!res.ok) throw new Error("Failed to fetch copy groups");
      const data = await res.json();
      setGroups(data.groups || []);
    } catch (error) {
      console.error(error);
      toast.error("Erro ao carregar os grupos");
    } finally {
      setLoading(false);
    }
  };

  const saveGroups = async (updatedGroups: Group[]) => {
    try {
      const res = await fetchWithAuth(`${API}/crm/copy-prospect`, {
        method: "POST",
        body: JSON.stringify({ groups: updatedGroups }),
      });
      if (!res.ok) throw new Error("Failed to save copy groups");
      setGroups(updatedGroups);
    } catch (error) {
      console.error(error);
      toast.error("Erro ao salvar os grupos");
    }
  };

  const handleAddGroup = () => {
    const newGroup: Group = {
      id: `group_${Date.now()}`,
      name: "Novo Grupo",
      templates: [],
    };
    saveGroups([...groups, newGroup]);
    setIsEditingGroup(newGroup.id);
    setEditGroupName(newGroup.name);
  };

  const handleDeleteGroup = (groupId: string) => {
    if (confirm("Tem certeza que deseja excluir este grupo e todos os seus textos?")) {
      saveGroups(groups.filter((g) => g.id !== groupId));
    }
  };

  const handleSaveGroupName = (groupId: string) => {
    if (!editGroupName.trim()) {
      toast.error("O nome do grupo não pode ser vazio");
      return;
    }
    const updated = groups.map((g) =>
      g.id === groupId ? { ...g, name: editGroupName } : g
    );
    saveGroups(updated);
    setIsEditingGroup(null);
  };

  const handleOpenTemplateModal = (groupId: string, template?: Template) => {
    setIsEditingTemplate({ groupId, templateId: template ? template.id : null });
    setEditTemplateTitle(template ? template.title : "");
    setEditTemplateContent(template ? template.content : "");
  };

  const handleSaveTemplate = () => {
    if (!isEditingTemplate) return;
    if (!editTemplateTitle.trim() || !editTemplateContent.trim()) {
      toast.error("Título e conteúdo são obrigatórios");
      return;
    }

    const { groupId, templateId } = isEditingTemplate;
    const updatedGroups = groups.map((g) => {
      if (g.id !== groupId) return g;
      
      let newTemplates = [...g.templates];
      if (templateId) {
        newTemplates = newTemplates.map((t) =>
          t.id === templateId
            ? { ...t, title: editTemplateTitle, content: editTemplateContent }
            : t
        );
      } else {
        newTemplates.push({
          id: `tpl_${Date.now()}`,
          title: editTemplateTitle,
          content: editTemplateContent,
        });
      }
      return { ...g, templates: newTemplates };
    });

    saveGroups(updatedGroups);
    setIsEditingTemplate(null);
  };

  const handleDeleteTemplate = (groupId: string, templateId: string) => {
    if (confirm("Tem certeza que deseja excluir este texto?")) {
      const updatedGroups = groups.map((g) => {
        if (g.id !== groupId) return g;
        return { ...g, templates: g.templates.filter((t) => t.id !== templateId) };
      });
      saveGroups(updatedGroups);
    }
  };

  const handleCopy = (content: string, id: string) => {
    navigator.clipboard.writeText(content).then(() => {
      setCopiedId(id);
      toast.success("Texto copiado para a área de transferência!");
      setTimeout(() => setCopiedId(null), 2000);
    }).catch(() => {
      toast.error("Erro ao copiar o texto");
    });
  };

  if (loading) {
    return (
      <div className="flex-1 flex items-center justify-center bg-zinc-950 p-8">
        <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-emerald-500"></div>
      </div>
    );
  }

  return (
    <div className="flex-1 overflow-auto bg-zinc-950 text-zinc-50 flex flex-col h-full">
      {/* Header */}
      <div className="p-8 pb-4 border-b border-zinc-900 sticky top-0 bg-zinc-950/80 backdrop-blur-xl z-10 flex flex-col sm:flex-row gap-4 items-start sm:items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-white flex items-center gap-3">
            <MessageCircle className="w-8 h-8 text-emerald-500" />
            Copy Prospect
          </h1>
          <p className="text-zinc-400 mt-2 text-sm max-w-2xl">
            Crie, organize e copie textos de abordagem para WhatsApp de forma rápida e eficiente.
          </p>
        </div>
        <button
          onClick={handleAddGroup}
          className="flex items-center gap-2 px-5 py-2.5 bg-emerald-500 hover:bg-emerald-600 text-white font-medium rounded-xl transition-all shadow-lg shadow-emerald-500/20"
        >
          <Plus className="w-5 h-5" />
          Novo Grupo
        </button>
      </div>

      <div className="p-8 flex-1">
        {groups.length === 0 ? (
          <div className="text-center py-20 border-2 border-dashed border-zinc-800 rounded-3xl">
            <MessageCircle className="w-16 h-16 text-zinc-600 mx-auto mb-4 opacity-50" />
            <h3 className="text-xl font-medium text-zinc-300 mb-2">Nenhum grupo criado</h3>
            <p className="text-zinc-500 mb-6">
              Comece criando seu primeiro grupo de mensagens.
            </p>
            <button
              onClick={handleAddGroup}
              className="inline-flex items-center gap-2 px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-white rounded-lg transition-colors"
            >
              <Plus className="w-4 h-4" />
              Adicionar Grupo
            </button>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-2 xl:grid-cols-3 gap-6 items-start">
            {groups.map((group) => (
              <div
                key={group.id}
                className="bg-zinc-900/50 border border-zinc-800 rounded-3xl overflow-hidden flex flex-col shadow-xl backdrop-blur-sm"
              >
                {/* Group Header */}
                <div className="p-5 border-b border-zinc-800 bg-zinc-900/80 flex items-center justify-between group/header transition-colors">
                  {isEditingGroup === group.id ? (
                    <div className="flex items-center gap-2 w-full">
                      <input
                        type="text"
                        value={editGroupName}
                        onChange={(e) => setEditGroupName(e.target.value)}
                        className="flex-1 bg-zinc-950 border border-zinc-700 rounded-lg px-3 py-1.5 text-zinc-100 text-lg font-semibold focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all"
                        placeholder="Nome do grupo..."
                        autoFocus
                        onKeyDown={(e) => {
                          if (e.key === "Enter") handleSaveGroupName(group.id);
                          if (e.key === "Escape") setIsEditingGroup(null);
                        }}
                      />
                      <button
                        onClick={() => handleSaveGroupName(group.id)}
                        className="p-1.5 bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30 rounded-lg transition-colors shrink-0"
                      >
                        <Check className="w-5 h-5" />
                      </button>
                    </div>
                  ) : (
                    <>
                      <h2 className="text-lg font-semibold text-zinc-100 flex-1 truncate pr-4">
                        {group.name}
                      </h2>
                      <div className="flex items-center gap-1 opacity-0 group-hover/header:opacity-100 transition-opacity shrink-0">
                        <button
                          onClick={() => {
                            setEditGroupName(group.name);
                            setIsEditingGroup(group.id);
                          }}
                          className="p-1.5 text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800 rounded-lg transition-colors"
                          title="Renomear Grupo"
                        >
                          <Edit2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleDeleteGroup(group.id)}
                          className="p-1.5 text-zinc-500 hover:text-red-400 hover:bg-red-400/10 rounded-lg transition-colors"
                          title="Excluir Grupo"
                        >
                          <Trash2 className="w-4 h-4" />
                        </button>
                      </div>
                    </>
                  )}
                </div>

                {/* Templates List */}
                <div className="p-5 flex flex-col gap-4 bg-zinc-950/30">
                  {group.templates.length === 0 ? (
                    <div className="text-center py-6">
                      <p className="text-sm text-zinc-500 mb-4">Sem textos neste grupo.</p>
                    </div>
                  ) : (
                    group.templates.map((template) => (
                      <div
                        key={template.id}
                        className="bg-zinc-900 border border-zinc-800 rounded-xl p-4 group/template hover:border-zinc-700 transition-all relative"
                      >
                        <div className="flex items-start justify-between mb-3 gap-2">
                          <h4 className="font-medium text-zinc-200 pr-12 line-clamp-1">{template.title}</h4>
                          
                          <div className="flex items-center gap-1 opacity-0 group-hover/template:opacity-100 transition-opacity absolute right-3 top-3 bg-zinc-900/90 pl-2 backdrop-blur-sm rounded-l-lg">
                            <button
                              onClick={() => handleOpenTemplateModal(group.id, template)}
                              className="p-1.5 text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800 rounded-lg transition-colors"
                              title="Editar"
                            >
                              <Edit2 className="w-3.5 h-3.5" />
                            </button>
                            <button
                              onClick={() => handleDeleteTemplate(group.id, template.id)}
                              className="p-1.5 text-zinc-500 hover:text-red-400 hover:bg-red-400/10 rounded-lg transition-colors"
                              title="Excluir"
                            >
                              <Trash2 className="w-3.5 h-3.5" />
                            </button>
                          </div>
                        </div>
                        
                        <div className="bg-zinc-950 rounded-lg p-3 text-sm text-zinc-400 whitespace-pre-wrap max-h-32 overflow-y-auto font-mono scrollbar-thin scrollbar-thumb-zinc-800">
                          {template.content}
                        </div>
                        
                        <button
                          onClick={() => handleCopy(template.content, template.id)}
                          className={`mt-3 w-full flex items-center justify-center gap-2 py-2 px-4 rounded-lg text-sm font-medium transition-all ${
                            copiedId === template.id
                              ? "bg-emerald-500/20 text-emerald-400 border border-emerald-500/30"
                              : "bg-zinc-800 hover:bg-zinc-700 text-zinc-200 border border-transparent"
                          }`}
                        >
                          {copiedId === template.id ? (
                            <>
                              <Check className="w-4 h-4" /> Copiado!
                            </>
                          ) : (
                            <>
                              <Copy className="w-4 h-4" /> Copiar Texto
                            </>
                          )}
                        </button>
                      </div>
                    ))
                  )}

                  <button
                    onClick={() => handleOpenTemplateModal(group.id)}
                    className="flex items-center justify-center gap-2 py-3 border-2 border-dashed border-zinc-800 hover:border-zinc-600 rounded-xl text-zinc-400 hover:text-zinc-200 transition-colors text-sm font-medium"
                  >
                    <Plus className="w-4 h-4" />
                    Adicionar Texto
                  </button>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Template Modal */}
      {isEditingTemplate && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
          <div className="bg-zinc-900 border border-zinc-800 rounded-3xl shadow-2xl w-full max-w-lg overflow-hidden flex flex-col max-h-[90vh]">
            <div className="p-6 border-b border-zinc-800 flex items-center justify-between bg-zinc-900/50 shrink-0">
              <h3 className="text-xl font-semibold text-white">
                {isEditingTemplate.templateId ? "Editar Texto" : "Novo Texto"}
              </h3>
              <button
                onClick={() => setIsEditingTemplate(null)}
                className="p-2 text-zinc-400 hover:text-white hover:bg-zinc-800 rounded-xl transition-colors"
              >
                <X className="w-5 h-5" />
              </button>
            </div>
            
            <div className="p-6 space-y-5 overflow-y-auto">
              <div>
                <label className="block text-sm font-medium text-zinc-300 mb-1.5">
                  Título de Identificação
                </label>
                <input
                  type="text"
                  value={editTemplateTitle}
                  onChange={(e) => setEditTemplateTitle(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-zinc-100 focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all placeholder:text-zinc-600"
                  placeholder="Ex: Primeira Abordagem B2B"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-zinc-300 mb-1.5">
                  Conteúdo da Mensagem (WhatsApp)
                </label>
                <textarea
                  value={editTemplateContent}
                  onChange={(e) => setEditTemplateContent(e.target.value)}
                  className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-3 text-zinc-100 h-48 resize-none focus:outline-none focus:border-emerald-500 focus:ring-1 focus:ring-emerald-500 transition-all placeholder:text-zinc-600 font-mono text-sm"
                  placeholder="Olá [Nome], tudo bem?&#10;&#10;Sou da Syntax e gostaria de..."
                />
              </div>
            </div>
            
            <div className="p-6 border-t border-zinc-800 bg-zinc-900/50 flex justify-end gap-3 shrink-0">
              <button
                onClick={() => setIsEditingTemplate(null)}
                className="px-5 py-2.5 text-sm font-medium text-zinc-300 hover:text-white bg-zinc-800 hover:bg-zinc-700 rounded-xl transition-colors"
              >
                Cancelar
              </button>
              <button
                onClick={handleSaveTemplate}
                className="px-5 py-2.5 text-sm font-medium text-white bg-emerald-500 hover:bg-emerald-600 rounded-xl transition-colors shadow-lg shadow-emerald-500/20 flex items-center gap-2"
              >
                <Check className="w-4 h-4" />
                Salvar Texto
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}