import { useState } from "react";
import {
  X, Mail, Phone, Globe, Briefcase, Tag, DollarSign, Calendar,
  UserCheck, Edit2, Trash2, MessageSquare, ArrowRight, Clock,
  ChevronDown,
} from "lucide-react";
import type { Lead, Activity } from "./LeadModal";

interface LeadDetailModalProps {
  isOpen: boolean;
  onClose: () => void;
  lead: Lead;
  onEdit: () => void;
  onDelete: () => void;
  onStageChange: (stage: string) => Promise<void>;
  onAddNote: (note: string) => Promise<void>;
  onConvertToClient?: (lead: Lead) => void;
}

export const STAGES = [
  { id: "novo", label: "Novo Lead", color: "bg-blue-500/10 text-blue-400 border-blue-500/20" },
  { id: "contato", label: "Contato Feito", color: "bg-purple-500/10 text-purple-400 border-purple-500/20" },
  { id: "proposta", label: "Proposta Enviada", color: "bg-amber-500/10 text-amber-400 border-amber-500/20" },
  { id: "negociacao", label: "Em Negociação", color: "bg-orange-500/10 text-orange-400 border-orange-500/20" },
  { id: "fechado", label: "Fechado", color: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20" },
  { id: "perdido", label: "Perdido", color: "bg-red-500/10 text-red-400 border-red-500/20" },
];

export const PRIORITY_MAP: Record<string, { label: string; color: string }> = {
  alta: { label: "Alta", color: "bg-red-500/10 text-red-400 border border-red-500/20 shadow-[0_0_10px_rgba(239,68,68,0.1)]" },
  media: { label: "Média", color: "bg-amber-500/10 text-amber-400 border border-amber-500/20 shadow-[0_0_10px_rgba(245,158,11,0.1)]" },
  baixa: { label: "Baixa", color: "bg-emerald-500/10 text-emerald-400 border border-emerald-500/20 shadow-[0_0_10px_rgba(16,185,129,0.1)]" },
};

function formatDate(iso: string) {
  if (!iso) return "";
  try {
    return new Date(iso).toLocaleDateString("pt-BR", { day: "2-digit", month: "short", year: "numeric" });
  } catch { return iso; }
}

function formatDateTime(iso: string) {
  if (!iso) return "";
  try {
    return new Date(iso).toLocaleString("pt-BR", { day: "2-digit", month: "short", hour: "2-digit", minute: "2-digit" });
  } catch { return iso; }
}

function stageLabel(id: string) {
  return STAGES.find((s) => s.id === id)?.label || id;
}

export function LeadDetailModal({ isOpen, onClose, lead, onEdit, onDelete, onStageChange, onAddNote, onConvertToClient }: LeadDetailModalProps) {
  const [changingStage, setChangingStage] = useState(false);
  const [noteText, setNoteText] = useState("");
  const [savingNote, setSavingNote] = useState(false);
  const [showStageDropdown, setShowStageDropdown] = useState(false);
  const [confirmDelete, setConfirmDelete] = useState(false);

  if (!isOpen) return null;

  const currentStage = STAGES.find((s) => s.id === lead.stage) || STAGES[0];
  const priority = PRIORITY_MAP[lead.priority] || PRIORITY_MAP.media;

  const handleStageChange = async (stageId: string) => {
    setChangingStage(true);
    setShowStageDropdown(false);
    try {
      await onStageChange(stageId);
    } finally {
      setChangingStage(false);
    }
  };

  const handleAddNote = async () => {
    if (!noteText.trim()) return;
    setSavingNote(true);
    try {
      await onAddNote(noteText.trim());
      setNoteText("");
    } finally {
      setSavingNote(false);
    }
  };

  const activities: Activity[] = [...(lead.activities || [])].reverse();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-zinc-950/80 backdrop-blur-sm p-4">
      <div className="bg-zinc-900 border border-zinc-800 rounded-2xl shadow-2xl w-full max-w-2xl max-h-[92vh] flex flex-col overflow-hidden ring-1 ring-white/5">

        {/* Header */}
        <div className="flex items-start justify-between px-6 py-4 border-b border-zinc-800 bg-zinc-900/50">
          <div className="flex-1 min-w-0">
            <div className="flex items-center gap-2 flex-wrap">
              <h2 className="text-lg font-bold text-zinc-50 truncate">{lead.name}</h2>
            </div>
            {lead.company && <p className="text-sm text-zinc-400 mt-0.5">{lead.company}</p>}
          </div>
          <div className="flex items-center gap-2 ml-4 shrink-0">
            <button
              onClick={onEdit}
              className="p-2 text-zinc-400 hover:text-emerald-500 hover:bg-emerald-500/10 rounded-xl transition-colors"
              title="Editar"
            >
              <Edit2 className="w-4 h-4" />
            </button>
            <button
              onClick={() => setConfirmDelete(true)}
              className="p-2 text-zinc-400 hover:text-red-500 hover:bg-red-500/10 rounded-xl transition-colors"
              title="Excluir"
            >
              <Trash2 className="w-4 h-4" />
            </button>
            <button onClick={onClose} className="p-2 text-zinc-400 hover:text-zinc-50 hover:bg-zinc-800 rounded-xl transition-colors">
              <X className="w-4 h-4" />
            </button>
          </div>
        </div>

        <div className="overflow-y-auto flex-1 px-6 py-5 space-y-6">

          {/* Stage selector */}
          {!lead.isClient && (
            <div>
              <p className="text-xs text-zinc-500 font-semibold uppercase tracking-wider mb-3">Estágio do Funil</p>
              <div className="flex items-center gap-2 flex-wrap">
                {STAGES.filter(s => s.id !== "perdido" && s.id !== "fechado").map((s, i) => (
                  <div key={s.id} className="flex items-center gap-2">
                    <button
                      onClick={() => handleStageChange(s.id)}
                      disabled={changingStage}
                      className={`text-xs px-3 py-1.5 rounded-xl border font-medium transition-all duration-200 ${
                        lead.stage === s.id 
                          ? s.color + " shadow-[0_0_15px_rgba(255,255,255,0.05)] scale-105" 
                          : "border-zinc-800 bg-zinc-900/50 text-zinc-400 hover:border-zinc-700 hover:text-zinc-300"
                      }`}
                    >
                      {s.label}
                    </button>
                    {i < STAGES.filter(s => s.id !== "perdido" && s.id !== "fechado").length - 1 && (
                      <ArrowRight className={`w-3 h-3 shrink-0 ${lead.stage === s.id ? 'text-zinc-500' : 'text-zinc-700'}`} />
                    )}
                  </div>
                ))}

                <div className="relative ml-1">
                  <button
                    onClick={() => setShowStageDropdown(!showStageDropdown)}
                    className={`flex items-center gap-1 text-xs px-3 py-1.5 rounded-xl border font-medium transition-all duration-200 ${
                      lead.stage === "fechado" || lead.stage === "perdido"
                        ? (STAGES.find(s => s.id === lead.stage)?.color || "") + " shadow-[0_0_15px_rgba(255,255,255,0.05)] scale-105"
                        : "border-zinc-800 bg-zinc-900/50 text-zinc-400 hover:border-zinc-700 hover:text-zinc-300"
                    }`}
                  >
                    {lead.stage === "fechado" ? "Fechado" : lead.stage === "perdido" ? "Perdido" : "Concluir"}
                    <ChevronDown className="w-3 h-3" />
                  </button>
                  {showStageDropdown && (
                    <div className="absolute top-full mt-2 right-0 bg-zinc-900 border border-zinc-800 rounded-xl shadow-2xl z-10 overflow-hidden min-w-[140px] ring-1 ring-white/5">
                      <button onClick={() => handleStageChange("fechado")} className="w-full text-left px-4 py-2.5 text-sm text-emerald-400 hover:bg-emerald-500/10 font-medium transition-colors">✓ Fechado</button>
                      <button onClick={() => handleStageChange("perdido")} className="w-full text-left px-4 py-2.5 text-sm text-red-400 hover:bg-red-500/10 font-medium transition-colors">✗ Perdido</button>
                    </div>
                  )}
                </div>
              </div>
            </div>
          )}

          {/* Info grid */}
          <div className="grid grid-cols-2 gap-3">
            <InfoRow icon={<Mail className="w-4 h-4" />} label="E-mail">
              <a href={`mailto:${lead.email}`} className="text-emerald-500 hover:text-emerald-400 hover:underline text-sm truncate transition-colors">{lead.email}</a>
            </InfoRow>
            {lead.phone && (
              <InfoRow icon={<Phone className="w-4 h-4" />} label="Telefone">
                <a href={`tel:${lead.phone}`} className="text-sm text-zinc-300 hover:text-zinc-100 transition-colors">{lead.phone}</a>
              </InfoRow>
            )}
            {lead.website && (
              <InfoRow icon={<Globe className="w-4 h-4" />} label="Site">
                <a href={lead.website} target="_blank" rel="noopener noreferrer" className="text-emerald-500 hover:text-emerald-400 hover:underline text-sm truncate transition-colors">{lead.website}</a>
              </InfoRow>
            )}
            {lead.service && (
              <InfoRow icon={<Briefcase className="w-4 h-4" />} label="Serviço">
                <span className="text-sm text-zinc-300">{lead.service}</span>
              </InfoRow>
            )}
            {lead.budget && (
              <InfoRow icon={<DollarSign className="w-4 h-4" />} label="Orçamento">
                <span className="text-sm text-zinc-300">{lead.budget}</span>
              </InfoRow>
            )}
            {lead.source && (
              <InfoRow icon={<Tag className="w-4 h-4" />} label="Origem">
                <span className="text-sm text-zinc-300">{lead.source}</span>
              </InfoRow>
            )}
            {lead.responsible && (
              <InfoRow icon={<UserCheck className="w-4 h-4" />} label="Responsável">
                <span className="text-sm text-zinc-300">{lead.responsible}</span>
              </InfoRow>
            )}
            {lead.nextFollowUp && (
              <InfoRow icon={<Calendar className="w-4 h-4" />} label="Follow-up">
                <span className="text-sm text-zinc-300">{formatDate(lead.nextFollowUp)}</span>
              </InfoRow>
            )}
            <InfoRow icon={<Clock className="w-4 h-4" />} label="Cadastrado em">
              <span className="text-sm text-zinc-300">{formatDate(lead.createdAt)}</span>
            </InfoRow>
          </div>

          {/* Notes */}
          {lead.notes && (
            <div className="bg-amber-500/5 border border-amber-500/20 rounded-xl p-4">
              <p className="text-xs text-amber-500 font-semibold mb-1.5 flex items-center gap-1.5">
                <MessageSquare className="w-3.5 h-3.5" />
                Observações Iniciais
              </p>
              <p className="text-sm text-zinc-300 whitespace-pre-wrap leading-relaxed">{lead.notes}</p>
            </div>
          )}

          {/* Add note */}
          <div>
            <p className="text-xs text-zinc-500 font-semibold uppercase tracking-wider mb-3">Adicionar Nota</p>
            <div className="flex gap-2">
              <div className="relative flex-1">
                <MessageSquare className="absolute left-3 top-2.5 w-4 h-4 text-zinc-500" />
                <input
                  value={noteText}
                  onChange={(e) => setNoteText(e.target.value)}
                  onKeyDown={(e) => e.key === "Enter" && !e.shiftKey && handleAddNote()}
                  placeholder="Escreva uma nota sobre este lead..."
                  className="w-full pl-9 pr-3 py-2.5 bg-zinc-950/50 border border-zinc-800 rounded-xl text-sm text-zinc-50 placeholder-zinc-600 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500 transition-all"
                />
              </div>
              <button
                onClick={handleAddNote}
                disabled={!noteText.trim() || savingNote}
                className="px-5 py-2.5 bg-zinc-800 border border-zinc-700 text-zinc-50 rounded-xl text-sm font-medium hover:bg-zinc-700 hover:border-zinc-600 disabled:opacity-50 transition-all"
              >
                {savingNote ? "..." : "Salvar"}
              </button>
            </div>
          </div>

          {/* Timeline */}
          {activities.length > 0 && (
            <div>
              <p className="text-xs text-zinc-500 font-semibold uppercase tracking-wider mb-4">Histórico</p>
              <div className="space-y-4 relative before:absolute before:inset-0 before:ml-[11px] before:-translate-x-px md:before:mx-auto md:before:translate-x-0 before:h-full before:w-0.5 before:bg-gradient-to-b before:from-transparent before:via-zinc-800 before:to-transparent">
                {activities.map((act, i) => (
                  <div key={i} className="relative flex items-center justify-between md:justify-normal md:odd:flex-row-reverse group is-active">
                    <div className="flex items-center justify-center w-6 h-6 rounded-full border border-zinc-800 bg-zinc-900 text-zinc-500 shadow shrink-0 md:order-1 md:group-odd:-translate-x-1/2 md:group-even:translate-x-1/2">
                      {act.type === "stage_change"
                        ? <ArrowRight className="w-3 h-3 text-emerald-500" />
                        : <MessageSquare className="w-3 h-3 text-amber-500" />}
                    </div>
                    <div className="w-[calc(100%-2.5rem)] md:w-[calc(50%-1.5rem)] p-3 rounded-xl border border-zinc-800 bg-zinc-900/50 shadow-[0_0_10px_rgba(0,0,0,0.2)]">
                      {act.type === "stage_change" ? (
                        <p className="text-sm text-zinc-300">
                          Movido de <span className="font-medium text-zinc-100">{stageLabel(act.from!)}</span> para{" "}
                          <span className="font-medium text-emerald-400">{stageLabel(act.to!)}</span>
                          {act.note && <span className="text-zinc-500 block mt-1 text-xs">Nota: {act.note}</span>}
                        </p>
                      ) : (
                        <p className="text-sm text-zinc-300">{act.text}</p>
                      )}
                      <p className="text-xs text-zinc-500 mt-2 font-medium">{formatDateTime(act.at)}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>

        {/* Footer */}
        <div className="border-t border-zinc-800 bg-zinc-900/50 px-6 py-4 flex gap-3">
          {onConvertToClient && !lead.isClient && (
            <button
              onClick={() => onConvertToClient(lead)}
              className="flex-1 flex items-center justify-center gap-2 py-2.5 border border-emerald-500 text-white bg-emerald-600 rounded-xl hover:bg-emerald-500 transition-all duration-200 text-sm font-semibold shadow-[0_0_15px_rgba(16,185,129,0.2)]"
            >
              Virar Cliente
            </button>
          )}
          <a
            href={`mailto:${lead.email}`}
            className="flex-1 flex items-center justify-center gap-2 py-2.5 border border-emerald-500/20 text-emerald-400 bg-emerald-500/10 rounded-xl hover:bg-emerald-500/20 transition-all duration-200 text-sm font-medium"
          >
            <Mail className="w-4 h-4" /> E-mail
          </a>
          {lead.phone && (
            <a
              href={`https://wa.me/${lead.phone.replace(/\D/g, "")}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex-1 flex items-center justify-center gap-2 py-2.5 border border-emerald-500/20 text-emerald-400 bg-emerald-500/10 rounded-xl hover:bg-emerald-500/20 transition-all duration-200 text-sm font-medium"
            >
              <Phone className="w-4 h-4" /> WhatsApp
            </a>
          )}
          <button
            onClick={onClose}
            className="px-5 py-2.5 border border-zinc-700 bg-zinc-800 text-zinc-300 rounded-xl hover:bg-zinc-700 hover:text-white transition-colors text-sm font-medium"
          >
            Fechar
          </button>
        </div>
      </div>

      {/* Confirm delete */}
      {confirmDelete && (
        <div className="fixed inset-0 z-60 flex items-center justify-center bg-zinc-950/90 backdrop-blur-sm">
          <div className="bg-zinc-900 border border-zinc-800 rounded-2xl shadow-2xl p-6 max-w-sm w-full mx-4 ring-1 ring-white/5">
            <h3 className="text-lg font-semibold text-zinc-50 mb-2">Excluir {lead.isClient ? "cliente" : "lead"}?</h3>
            <p className="text-sm text-zinc-400 mb-6">
              Tem certeza que deseja excluir <span className="font-semibold text-zinc-200">{lead.name}</span>? Esta ação não pode ser desfeita.
            </p>
            <div className="flex gap-3">
              <button
                onClick={() => { onDelete(); setConfirmDelete(false); }}
                className="flex-1 py-2.5 bg-red-600/10 border border-red-500/20 text-red-500 rounded-xl font-medium text-sm hover:bg-red-600/20 hover:border-red-500/30 transition-colors"
              >
                Excluir Definitivamente
              </button>
              <button
                onClick={() => setConfirmDelete(false)}
                className="flex-1 py-2.5 border border-zinc-700 bg-zinc-800 text-zinc-300 rounded-xl text-sm font-medium hover:bg-zinc-700 hover:text-white transition-colors"
              >
                Cancelar
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function InfoRow({ icon, label, children }: { icon: React.ReactNode; label: string; children: React.ReactNode }) {
  return (
    <div className="bg-zinc-950/50 rounded-xl p-3 border border-zinc-800/50 hover:border-zinc-700 transition-colors">
      <div className="flex items-center gap-1.5 text-zinc-500 mb-1.5">
        {icon}
        <span className="text-xs font-medium uppercase tracking-wider">{label}</span>
      </div>
      <div className="truncate">{children}</div>
    </div>
  );
}
