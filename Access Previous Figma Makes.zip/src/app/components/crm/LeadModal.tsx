import { useState, useEffect } from "react";
import { X, User, Mail, Phone, Globe, Briefcase, DollarSign, Tag, MessageSquare, Calendar, UserCheck } from "lucide-react";

export interface Lead {
  id: string;
  folderId?: string;
  name: string;
  company: string;
  email: string;
  phone: string;
  website: string;
  service: string;
  budget: string;
  source: string;
  priority: "alta" | "media" | "baixa";
  notes: string;
  responsible: string;
  nextFollowUp: string | null;
  stage: string;
  createdAt: string;
  updatedAt: string;
  activities: Activity[];
  isClient?: boolean;
}

export interface Activity {
  type: "stage_change" | "note";
  from?: string;
  to?: string;
  text?: string;
  note?: string;
  at: string;
}

interface LeadModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSave: (data: Partial<Lead>) => Promise<void>;
  lead?: Lead | null; // if editing
}

const SERVICE_OPTIONS = [
  "Site Institucional", "E-commerce", "Landing Page", "Sistema Web",
  "Redesign de Site", "Blog", "Portfólio", "Aplicativo Web", "Outro",
];

const BUDGET_OPTIONS = [
  "Até R$ 2.000", "R$ 2.000 – R$ 5.000", "R$ 5.000 – R$ 10.000",
  "R$ 10.000 – R$ 20.000", "R$ 20.000 – R$ 50.000", "Acima de R$ 50.000", "A definir",
];

const SOURCE_OPTIONS = [
  "Instagram", "Google", "Indicação", "LinkedIn", "WhatsApp", "Facebook",
  "Site da Agência", "Email Marketing", "Evento", "Outro",
];

const PRIORITY_OPTIONS = [
  { value: "alta", label: "Alta", color: "text-red-500" },
  { value: "media", label: "Média", color: "text-amber-500" },
  { value: "baixa", label: "Baixa", color: "text-emerald-500" },
];

const INITIAL: Partial<Lead> = {
  name: "", company: "", email: "", phone: "", website: "", service: "",
  budget: "", source: "Indicação", priority: "media", notes: "", responsible: "", nextFollowUp: "", folderId: "geral"
};

export function LeadModal({ isOpen, onClose, onSave, lead }: LeadModalProps) {
  const [form, setForm] = useState<Partial<Lead>>(INITIAL);
  const [saving, setSaving] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  useEffect(() => {
    if (lead) setForm({ ...lead });
    else setForm(INITIAL);
    setErrors({});
  }, [lead, isOpen]);

  if (!isOpen) return null;

  const set = (field: keyof Lead, value: any) => {
    setForm((p) => ({ ...p, [field]: value }));
    setErrors((p) => { const n = { ...p }; delete n[field]; return n; });
  };

  const validate = () => {
    const e: Record<string, string> = {};
    if (!form.name?.trim()) e.name = "Nome obrigatório";
    return e;
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const errs = validate();
    if (Object.keys(errs).length) { setErrors(errs); return; }
    setSaving(true);
    try { await onSave(form); onClose(); }
    catch (err) { console.error("Erro ao salvar lead:", err); }
    finally { setSaving(false); }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-zinc-950/80 backdrop-blur-sm p-4">
      <div className="bg-zinc-900 border border-zinc-800 rounded-2xl shadow-2xl w-full max-w-2xl max-h-[92vh] flex flex-col overflow-hidden ring-1 ring-white/5">
        <div className="flex items-center justify-between px-6 py-4 border-b border-zinc-800 bg-zinc-900/50">
          <div>
            <h2 className="text-lg font-semibold text-zinc-50">{lead ? "Editar Lead" : "Novo Lead"}</h2>
            <p className="text-sm text-zinc-400 mt-0.5">{lead ? "Atualize as informações do contato" : "Cadastre um novo potencial cliente"}</p>
          </div>
          <button onClick={onClose} className="p-2 text-zinc-400 hover:text-zinc-50 hover:bg-zinc-800 rounded-xl transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="flex flex-col flex-1 overflow-hidden">
          <div className="overflow-y-auto flex-1 px-6 py-5 space-y-6">
            <div>
              <h3 className="text-xs font-semibold text-zinc-500 uppercase tracking-wider mb-4">Dados do Contato</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-zinc-300 mb-1.5">Nome <span className="text-emerald-500">*</span></label>
                  <div className="relative">
                    <User className="absolute left-3 top-2.5 w-4 h-4 text-zinc-500" />
                    <input value={form.name || ""} onChange={(e) => set("name", e.target.value)} placeholder="João Silva" className={`w-full pl-9 pr-3 py-2 bg-zinc-950/50 border rounded-xl text-sm text-zinc-50 placeholder-zinc-600 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 transition-all ${errors.name ? "border-red-500/50 focus:border-red-500" : "border-zinc-800 focus:border-emerald-500"}`} />
                  </div>
                  {errors.name && <p className="text-xs text-red-400 mt-1">{errors.name}</p>}
                </div>

                <div>
                  <label className="block text-sm font-medium text-zinc-300 mb-1.5">Empresa</label>
                  <div className="relative">
                    <Briefcase className="absolute left-3 top-2.5 w-4 h-4 text-zinc-500" />
                    <input value={form.company || ""} onChange={(e) => set("company", e.target.value)} placeholder="Nome da empresa" className="w-full pl-9 pr-3 py-2 bg-zinc-950/50 border border-zinc-800 rounded-xl text-sm text-zinc-50 placeholder-zinc-600 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500 transition-all" />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-zinc-300 mb-1.5">E-mail</label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-2.5 w-4 h-4 text-zinc-500" />
                    <input type="email" value={form.email || ""} onChange={(e) => set("email", e.target.value)} placeholder="joao@empresa.com" className={`w-full pl-9 pr-3 py-2 bg-zinc-950/50 border rounded-xl text-sm text-zinc-50 placeholder-zinc-600 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 transition-all ${errors.email ? "border-red-500/50 focus:border-red-500" : "border-zinc-800 focus:border-emerald-500"}`} />
                  </div>
                  {errors.email && <p className="text-xs text-red-400 mt-1">{errors.email}</p>}
                </div>

                <div>
                  <label className="block text-sm font-medium text-zinc-300 mb-1.5">Telefone / WhatsApp</label>
                  <div className="relative">
                    <Phone className="absolute left-3 top-2.5 w-4 h-4 text-zinc-500" />
                    <input value={form.phone || ""} onChange={(e) => set("phone", e.target.value)} placeholder="(11) 99999-9999" className="w-full pl-9 pr-3 py-2 bg-zinc-950/50 border border-zinc-800 rounded-xl text-sm text-zinc-50 placeholder-zinc-600 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500 transition-all" />
                  </div>
                </div>

                <div className="sm:col-span-2">
                  <label className="block text-sm font-medium text-zinc-300 mb-1.5">Site atual (se tiver)</label>
                  <div className="relative">
                    <Globe className="absolute left-3 top-2.5 w-4 h-4 text-zinc-500" />
                    <input value={form.website || ""} onChange={(e) => set("website", e.target.value)} placeholder="https://empresa.com.br" className="w-full pl-9 pr-3 py-2 bg-zinc-950/50 border border-zinc-800 rounded-xl text-sm text-zinc-50 placeholder-zinc-600 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500 transition-all" />
                  </div>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-xs font-semibold text-zinc-500 uppercase tracking-wider mb-4">Projeto & Interesse</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-zinc-300 mb-1.5">Serviço de Interesse</label>
                  <select value={form.service || ""} onChange={(e) => set("service", e.target.value)} className="w-full px-3 py-2 bg-zinc-950/50 border border-zinc-800 rounded-xl text-sm text-zinc-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500 transition-all">
                    <option value="" className="bg-zinc-900">Selecione...</option>
                    {SERVICE_OPTIONS.map((s) => <option key={s} className="bg-zinc-900">{s}</option>)}
                  </select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-zinc-300 mb-1.5">Orçamento Estimado</label>
                  <div className="relative">
                    <DollarSign className="absolute left-3 top-2.5 w-4 h-4 text-zinc-500" />
                    <select value={form.budget || ""} onChange={(e) => set("budget", e.target.value)} className="w-full pl-9 pr-3 py-2 bg-zinc-950/50 border border-zinc-800 rounded-xl text-sm text-zinc-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500 transition-all">
                      <option value="" className="bg-zinc-900">Selecione...</option>
                      {BUDGET_OPTIONS.map((b) => <option key={b} className="bg-zinc-900">{b}</option>)}
                    </select>
                  </div>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-xs font-semibold text-zinc-500 uppercase tracking-wider mb-4">Qualificação</h3>
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-zinc-300 mb-1.5">Origem</label>
                  <div className="relative">
                    <Tag className="absolute left-3 top-2.5 w-4 h-4 text-zinc-500" />
                    <select value={form.source || ""} onChange={(e) => set("source", e.target.value)} className="w-full pl-9 pr-3 py-2 bg-zinc-950/50 border border-zinc-800 rounded-xl text-sm text-zinc-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500 transition-all">
                      {SOURCE_OPTIONS.map((s) => <option key={s} className="bg-zinc-900">{s}</option>)}
                    </select>
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-zinc-300 mb-1.5">Responsável</label>
                  <div className="relative">
                    <UserCheck className="absolute left-3 top-2.5 w-4 h-4 text-zinc-500" />
                    <input value={form.responsible || ""} onChange={(e) => set("responsible", e.target.value)} placeholder="Responsável" className="w-full pl-9 pr-3 py-2 bg-zinc-950/50 border border-zinc-800 rounded-xl text-sm text-zinc-50 placeholder-zinc-600 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500 transition-all" />
                  </div>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-xs font-semibold text-zinc-500 uppercase tracking-wider mb-4">Acompanhamento</h3>
              <div className="grid grid-cols-1 gap-4">
                <div>
                  <label className="block text-sm font-medium text-zinc-300 mb-1.5">Próximo Follow-up</label>
                  <div className="relative">
                    <Calendar className="absolute left-3 top-2.5 w-4 h-4 text-zinc-500" />
                    <input type="date" value={form.nextFollowUp || ""} onChange={(e) => set("nextFollowUp", e.target.value)} className="w-full pl-9 pr-3 py-2 bg-zinc-950/50 border border-zinc-800 rounded-xl text-sm text-zinc-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500 transition-all [color-scheme:dark]" />
                  </div>
                </div>
                <div>
                  <label className="block text-sm font-medium text-zinc-300 mb-1.5">Observações</label>
                  <div className="relative">
                    <MessageSquare className="absolute left-3 top-2.5 w-4 h-4 text-zinc-500" />
                    <textarea value={form.notes || ""} onChange={(e) => set("notes", e.target.value)} placeholder="Detalhes sobre o cliente, necessidades..." rows={3} className="w-full pl-9 pr-3 py-2 bg-zinc-950/50 border border-zinc-800 rounded-xl text-sm text-zinc-50 placeholder-zinc-600 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500 resize-none transition-all" />
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="border-t border-zinc-800 bg-zinc-900/50 px-6 py-4 flex gap-3">
            <button type="submit" disabled={saving} className="flex-1 py-2.5 bg-emerald-600 hover:bg-emerald-500 text-white rounded-xl font-medium text-sm transition-colors shadow-[0_0_15px_rgba(5,150,105,0.2)] disabled:opacity-60">
              {saving ? "Salvando..." : lead ? "Salvar alterações" : "Cadastrar Lead"}
            </button>
            <button type="button" onClick={onClose} className="px-5 py-2.5 border border-zinc-700 bg-zinc-800 text-zinc-300 rounded-xl text-sm hover:bg-zinc-700 hover:text-white transition-colors">
              Cancelar
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
