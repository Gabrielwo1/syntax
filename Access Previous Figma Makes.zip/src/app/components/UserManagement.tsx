import { useState, useEffect } from 'react';
import {
  Users, UserPlus, Trash2, Shield, UserCog, Loader2, AlertCircle,
  CheckCircle, X, User, Mail, Lock, EyeOff, Eye, UserCheck, Crown,
  Save, Settings2
} from 'lucide-react';
import { useAuth } from '../context/AuthContext';
import { supabase } from '../context/AuthContext';
import { projectId } from '/utils/supabase/info';
import { NAV_ITEMS } from './Sidebar';
import { fetchWithAuth } from '../utils/auth';

const BASE_URL = `https://${projectId}.supabase.co/functions/v1/make-server-cee56a32`;

interface SystemUser {
  id: string;
  email: string;
  user_metadata: { name?: string; role?: string; permissions?: string[] };
  created_at: string;
  last_sign_in_at?: string;
}

export function UserManagement() {
  const { user: currentUser, isAdmin, loading: authLoading } = useAuth();
  const [users, setUsers] = useState<SystemUser[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [successMsg, setSuccessMsg] = useState('');

  // Create user form
  const [showForm, setShowForm] = useState(false);
  const [formName, setFormName] = useState('');
  const [formEmail, setFormEmail] = useState('');
  const [formPassword, setFormPassword] = useState('');
  const [formRole, setFormRole] = useState<'member' | 'admin'>('member');
  const [formPermissions, setFormPermissions] = useState<string[]>(NAV_ITEMS.map(i => i.to));
  const [showPassword, setShowPassword] = useState(false);
  const [formLoading, setFormLoading] = useState(false);
  const [formError, setFormError] = useState('');

  const [deletingId, setDeletingId] = useState<string | null>(null);

  // Edit access modal state
  const [editingUser, setEditingUser] = useState<SystemUser | null>(null);
  const [editPermissions, setEditPermissions] = useState<string[]>([]);
  const [editRole, setEditRole] = useState<'member' | 'admin'>('member');
  const [editName, setEditName] = useState('');
  const [editPassword, setEditPassword] = useState('');
  const [showEditPassword, setShowEditPassword] = useState(false);
  const [editLoading, setEditLoading] = useState(false);
  const [editError, setEditError] = useState('');

  // Parses an error response body regardless of which field Supabase / Hono uses
  const parseResponseError = (data: any, status: number, context: string) => {
    return (
      data?.error ||
      data?.message ||
      data?.msg ||
      data?.details ||
      data?.error_description ||
      `Erro HTTP ${status} ao ${context}`
    );
  };

  const showSuccess = (msg: string) => {
    setSuccessMsg(msg);
    setTimeout(() => setSuccessMsg(''), 3500);
  };

  const fetchUsers = async () => {
    setLoading(true);
    setError('');
    try {
      const res = await fetchWithAuth(`${BASE_URL}/auth/users`);
      const data = await res.json();
      if (!res.ok) throw new Error(parseResponseError(data, res.status, 'carregar usuários'));
      // Sort: admins first, then by name
      const sorted = (data.users || []).sort((a: SystemUser, b: SystemUser) => {
        const ra = a.user_metadata?.role === 'admin' ? 0 : 1;
        const rb = b.user_metadata?.role === 'admin' ? 0 : 1;
        if (ra !== rb) return ra - rb;
        return (a.user_metadata?.name || a.email).localeCompare(b.user_metadata?.name || b.email);
      });
      setUsers(sorted);
    } catch (err: any) {
      setError(err.message || 'Erro de conexão');
    }
    setLoading(false);
  };

  useEffect(() => {
    if (authLoading) return;
    fetchUsers();
  }, [authLoading]);

  const handleCreate = async (e: React.FormEvent) => {
    e.preventDefault();
    setFormError('');
    if (formPassword.length < 6) {
      setFormError('A senha deve ter pelo menos 6 caracteres.');
      return;
    }
    setFormLoading(true);
    try {
      const payload = {
        email: formEmail.trim(),
        password: formPassword,
        name: formName.trim(),
        role: formRole,
        // Only send permissions for member role; admin gets full access
        permissions: formRole === 'member' ? formPermissions : [],
      };
      console.log('[UserManagement] Creating user:', { ...payload, password: '***' });

      const res = await fetchWithAuth(`${BASE_URL}/auth/signup`, {
        method: 'POST',
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      console.log('[UserManagement] Signup response:', res.status, data);

      if (!res.ok) {
        // Show the real error message, falling back through possible fields
        const errorMsg = parseResponseError(data, res.status, 'criar usuário');
        throw new Error(errorMsg);
      }

      showSuccess(`Usuário "${formName.trim() || formEmail.trim()}" criado com sucesso!`);
      setShowForm(false);
      setFormName('');
      setFormEmail('');
      setFormPassword('');
      setFormRole('member');
      setFormPermissions(NAV_ITEMS.map(i => i.to));
      fetchUsers();
    } catch (err: any) {
      console.error('[UserManagement] Error creating user:', err);
      setFormError(err.message || 'Erro inesperado ao criar usuário');
    }
    setFormLoading(false);
  };

  const handleDelete = async (userId: string, userName: string) => {
    if (!confirm(`Tem certeza que deseja excluir o usuário "${userName}"? Esta ação não pode ser desfeita.`)) return;
    setDeletingId(userId);
    try {
      const res = await fetchWithAuth(`${BASE_URL}/auth/users/${userId}`, {
        method: 'DELETE',
      });
      const data = await res.json();
      if (!res.ok) throw new Error(parseResponseError(data, res.status, 'excluir usuário'));
      showSuccess(`Usuário "${userName}" excluído.`);
      fetchUsers();
    } catch (err: any) {
      setError(err.message);
    }
    setDeletingId(null);
  };

  const handleToggleRole = async (userId: string, currentRole: string, userName: string) => {
    const newRole = currentRole === 'admin' ? 'member' : 'admin';
    try {
      const res = await fetchWithAuth(`${BASE_URL}/auth/users/${userId}`, {
        method: 'PUT',
        body: JSON.stringify({ role: newRole }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(parseResponseError(data, res.status, 'atualizar role'));
      showSuccess(`"${userName}" agora é ${newRole === 'admin' ? 'Administrador' : 'Membro'}.`);
      fetchUsers();
    } catch (err: any) {
      setError(err.message);
    }
  };

  const togglePermission = (path: string) => {
    setFormPermissions(prev =>
      prev.includes(path)
        ? prev.filter(p => p !== path)
        : [...prev, path]
    );
  };

  const toggleEditPermission = (path: string) => {
    setEditPermissions(prev =>
      prev.includes(path)
        ? prev.filter(p => p !== path)
        : [...prev, path]
    );
  };

  const openEditModal = (u: SystemUser) => {
    setEditingUser(u);
    setEditPermissions(u.user_metadata?.permissions || []);
    setEditRole((u.user_metadata?.role as 'member' | 'admin') || 'member');
    setEditName(u.user_metadata?.name || u.email.split('@')[0]);
    setEditPassword('');
    setShowEditPassword(false);
    setEditError('');
  };

  const handleSaveAccess = async () => {
    if (!editingUser) return;
    setEditLoading(true);
    setEditError('');
    try {
      const payload: any = {
        name: editName.trim(),
        role: editRole,
        permissions: editRole === 'member' ? editPermissions : [],
      };
      if (editPassword.trim()) {
        if (editPassword.length < 6) {
          setEditError('A senha deve ter pelo menos 6 caracteres.');
          setEditLoading(false);
          return;
        }
        payload.password = editPassword;
      }
      console.log('[UserManagement] Saving access for:', editingUser.id, payload);

      const res = await fetchWithAuth(`${BASE_URL}/auth/users/${editingUser.id}`, {
        method: 'PUT',
        body: JSON.stringify(payload),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(parseResponseError(data, res.status, 'salvar acesso'));

      showSuccess(`Acesso de "${editName.trim()}" salvo com sucesso!`);
      setEditingUser(null);
      fetchUsers();
    } catch (err: any) {
      console.error('[UserManagement] Error saving access:', err);
      setEditError(err.message || 'Erro inesperado ao salvar acesso');
    }
    setEditLoading(false);
  };

  if (!isAdmin) {
    return (
      <div className="flex-1 flex items-center justify-center min-h-screen bg-zinc-950">
        <div className="text-center">
          <Shield className="w-16 h-16 text-zinc-700 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-zinc-300 mb-2">Acesso Restrito</h2>
          <p className="text-zinc-500">Apenas administradores podem gerenciar usuários.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 min-h-screen bg-zinc-950 p-6 md:p-8">
      <div className="max-w-4xl mx-auto">

        {/* Header */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <div className="flex items-center gap-3 mb-1">
              <div className="w-9 h-9 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center">
                <UserCog className="w-5 h-5 text-emerald-400" />
              </div>
              <h1 className="text-2xl font-bold text-zinc-50">Usuários</h1>
            </div>
            <p className="text-zinc-500 text-sm pl-12">Gerencie quem tem acesso ao sistema</p>
          </div>
          <button
            onClick={() => { setShowForm(true); setFormError(''); }}
            className="flex items-center gap-2 bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-semibold px-4 py-2.5 rounded-xl transition-all text-sm"
          >
            <UserPlus className="w-4 h-4" />
            Novo Usuário
          </button>
        </div>

        {/* Success toast */}
        {successMsg && (
          <div className="mb-5 flex items-center gap-3 bg-emerald-500/10 border border-emerald-500/20 rounded-2xl px-4 py-3">
            <CheckCircle className="w-4 h-4 text-emerald-400 shrink-0" />
            <p className="text-sm text-emerald-400">{successMsg}</p>
          </div>
        )}

        {/* Error */}
        {error && (
          <div className="mb-5 flex items-start gap-3 bg-red-500/10 border border-red-500/20 rounded-2xl px-4 py-3">
            <AlertCircle className="w-4 h-4 text-red-400 mt-0.5 shrink-0" />
            <p className="text-sm text-red-400">{error}</p>
          </div>
        )}

        {/* Create User Modal */}
        {showForm && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-zinc-950/80 backdrop-blur-sm">
            <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-7 w-full max-w-md shadow-2xl">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-emerald-500/10 border border-emerald-500/20 flex items-center justify-center">
                    <UserPlus className="w-5 h-5 text-emerald-400" />
                  </div>
                  <h2 className="text-lg font-bold text-zinc-50">Novo Usuário</h2>
                </div>
                <button onClick={() => setShowForm(false)} className="p-2 text-zinc-500 hover:text-zinc-300 hover:bg-zinc-800 rounded-xl transition-all">
                  <X className="w-4 h-4" />
                </button>
              </div>

              {formError && (
                <div className="mb-4 flex items-start gap-2 bg-red-500/10 border border-red-500/20 rounded-xl px-3 py-2.5">
                  <AlertCircle className="w-4 h-4 text-red-400 mt-0.5 shrink-0" />
                  <p className="text-xs text-red-400 break-all">{formError}</p>
                </div>
              )}

              <form onSubmit={handleCreate} className="space-y-4">
                <div>
                  <label className="block text-xs font-medium text-zinc-400 mb-1.5">Nome</label>
                  <div className="relative">
                    <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
                    <input type="text" value={formName} onChange={e => setFormName(e.target.value)} required placeholder="Nome completo"
                      className="w-full bg-zinc-800/60 border border-zinc-700 rounded-xl pl-10 pr-4 py-2.5 text-sm text-zinc-100 placeholder-zinc-600 focus:outline-none focus:border-emerald-500/50 transition-all" />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-medium text-zinc-400 mb-1.5">E-mail</label>
                  <div className="relative">
                    <Mail className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
                    <input type="email" value={formEmail} onChange={e => setFormEmail(e.target.value)} required placeholder="usuario@email.com"
                      className="w-full bg-zinc-800/60 border border-zinc-700 rounded-xl pl-10 pr-4 py-2.5 text-sm text-zinc-100 placeholder-zinc-600 focus:outline-none focus:border-emerald-500/50 transition-all" />
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-medium text-zinc-400 mb-1.5">Senha</label>
                  <div className="relative">
                    <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
                    <input type={showPassword ? 'text' : 'password'} value={formPassword} onChange={e => setFormPassword(e.target.value)} required placeholder="Mínimo 6 caracteres"
                      className="w-full bg-zinc-800/60 border border-zinc-700 rounded-xl pl-10 pr-10 py-2.5 text-sm text-zinc-100 placeholder-zinc-600 focus:outline-none focus:border-emerald-500/50 transition-all" />
                    <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute right-3.5 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-zinc-300">
                      {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>
                <div>
                  <label className="block text-xs font-medium text-zinc-400 mb-1.5">Função</label>
                  <div className="grid grid-cols-2 gap-3">
                    <button type="button" onClick={() => setFormRole('member')}
                      className={`flex items-center gap-2 px-4 py-2.5 rounded-xl border transition-all text-sm font-medium ${formRole === 'member' ? 'bg-zinc-700/50 border-zinc-500 text-zinc-100' : 'border-zinc-700 text-zinc-500 hover:border-zinc-600'}`}>
                      <UserCheck className="w-4 h-4" /> Membro
                    </button>
                    <button type="button" onClick={() => setFormRole('admin')}
                      className={`flex items-center gap-2 px-4 py-2.5 rounded-xl border transition-all text-sm font-medium ${formRole === 'admin' ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' : 'border-zinc-700 text-zinc-500 hover:border-zinc-600'}`}>
                      <Crown className="w-4 h-4" /> Admin
                    </button>
                  </div>
                </div>

                {formRole === 'member' && (
                  <div className="pt-2 border-t border-zinc-800">
                    <div className="flex items-center justify-between mb-2">
                      <label className="text-xs font-medium text-zinc-400">Acesso aos Menus</label>
                      <div className="flex gap-2">
                        <button type="button" onClick={() => setFormPermissions(NAV_ITEMS.map(i => i.to))}
                          className="text-[10px] text-emerald-500 hover:text-emerald-400 transition-colors">Todos</button>
                        <span className="text-zinc-700 text-[10px]">·</span>
                        <button type="button" onClick={() => setFormPermissions([])}
                          className="text-[10px] text-zinc-500 hover:text-zinc-400 transition-colors">Nenhum</button>
                      </div>
                    </div>
                    <div className="space-y-2 max-h-[200px] overflow-y-auto pr-1 custom-scrollbar">
                      {NAV_ITEMS.map(item => (
                        <label key={item.to} className="flex items-center gap-3 p-2.5 rounded-xl border border-zinc-800 hover:bg-zinc-800/50 cursor-pointer transition-all">
                          <input type="checkbox" className="hidden" checked={formPermissions.includes(item.to)} onChange={() => togglePermission(item.to)} />
                          <div className={`w-5 h-5 rounded-md border flex items-center justify-center shrink-0 transition-all ${formPermissions.includes(item.to) ? 'bg-emerald-500 border-emerald-500' : 'border-zinc-600 bg-zinc-900'}`}>
                            {formPermissions.includes(item.to) && <CheckCircle className="w-3 h-3 text-zinc-950" />}
                          </div>
                          <div className="flex items-center gap-2 flex-1 min-w-0">
                            <item.icon className="w-4 h-4 text-zinc-500 shrink-0" />
                            <span className="text-sm font-medium text-zinc-300 truncate">{item.label}</span>
                            {item.adminOnly && (
                              <span className="text-[10px] text-amber-500/70 border border-amber-500/20 rounded px-1 shrink-0">admin</span>
                            )}
                          </div>
                        </label>
                      ))}
                    </div>
                    <p className="mt-2 text-[10px] text-zinc-600">
                      {formPermissions.length} de {NAV_ITEMS.length} menus selecionados
                    </p>
                  </div>
                )}

                <div className="flex gap-3 pt-2">
                  <button type="button" onClick={() => setShowForm(false)}
                    className="flex-1 py-2.5 rounded-xl border border-zinc-700 text-zinc-400 hover:bg-zinc-800 transition-all text-sm font-medium">
                    Cancelar
                  </button>
                  <button type="submit" disabled={formLoading}
                    className="flex-1 bg-emerald-500 hover:bg-emerald-400 disabled:opacity-50 text-zinc-950 font-semibold py-2.5 rounded-xl transition-all flex items-center justify-center gap-2 text-sm">
                    {formLoading ? <><Loader2 className="w-4 h-4 animate-spin" /> Criando...</> : 'Criar Usuário'}
                  </button>
                </div>
              </form>
            </div>
          </div>
        )}

        {/* Edit Access Modal */}
        {editingUser && (
          <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-zinc-950/80 backdrop-blur-sm">
            <div className="bg-zinc-900 border border-zinc-800 rounded-3xl p-7 w-full max-w-md shadow-2xl">
              <div className="flex items-center justify-between mb-6">
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-xl bg-blue-500/10 border border-blue-500/20 flex items-center justify-center">
                    <Settings2 className="w-5 h-5 text-blue-400" />
                  </div>
                  <div>
                    <h2 className="text-lg font-bold text-zinc-50">Editar Acesso</h2>
                    <p className="text-xs text-zinc-500">{editingUser.email}</p>
                  </div>
                </div>
                <button onClick={() => setEditingUser(null)} className="p-2 text-zinc-500 hover:text-zinc-300 hover:bg-zinc-800 rounded-xl transition-all">
                  <X className="w-4 h-4" />
                </button>
              </div>

              {editError && (
                <div className="mb-4 flex items-start gap-2 bg-red-500/10 border border-red-500/20 rounded-xl px-3 py-2.5">
                  <AlertCircle className="w-4 h-4 text-red-400 mt-0.5 shrink-0" />
                  <p className="text-xs text-red-400 break-all">{editError}</p>
                </div>
              )}

              <div className="space-y-4">
                {/* Name */}
                <div>
                  <label className="block text-xs font-medium text-zinc-400 mb-1.5">Nome</label>
                  <div className="relative">
                    <User className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
                    <input type="text" value={editName} onChange={e => setEditName(e.target.value)}
                      className="w-full bg-zinc-800/60 border border-zinc-700 rounded-xl pl-10 pr-4 py-2.5 text-sm text-zinc-100 placeholder-zinc-600 focus:outline-none focus:border-blue-500/50 transition-all" />
                  </div>
                </div>

                {/* New password (optional) */}
                <div>
                  <label className="block text-xs font-medium text-zinc-400 mb-1.5">Nova Senha <span className="text-zinc-600">(opcional)</span></label>
                  <div className="relative">
                    <Lock className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-zinc-500" />
                    <input type={showEditPassword ? 'text' : 'password'} value={editPassword} onChange={e => setEditPassword(e.target.value)} placeholder="Deixe vazio para manter"
                      className="w-full bg-zinc-800/60 border border-zinc-700 rounded-xl pl-10 pr-10 py-2.5 text-sm text-zinc-100 placeholder-zinc-600 focus:outline-none focus:border-blue-500/50 transition-all" />
                    <button type="button" onClick={() => setShowEditPassword(!showEditPassword)} className="absolute right-3.5 top-1/2 -translate-y-1/2 text-zinc-500 hover:text-zinc-300">
                      {showEditPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                    </button>
                  </div>
                </div>

                {/* Role */}
                <div>
                  <label className="block text-xs font-medium text-zinc-400 mb-1.5">Função</label>
                  <div className="grid grid-cols-2 gap-3">
                    <button type="button" onClick={() => setEditRole('member')}
                      className={`flex items-center gap-2 px-4 py-2.5 rounded-xl border transition-all text-sm font-medium ${editRole === 'member' ? 'bg-zinc-700/50 border-zinc-500 text-zinc-100' : 'border-zinc-700 text-zinc-500 hover:border-zinc-600'}`}>
                      <UserCheck className="w-4 h-4" /> Membro
                    </button>
                    <button type="button" onClick={() => setEditRole('admin')}
                      className={`flex items-center gap-2 px-4 py-2.5 rounded-xl border transition-all text-sm font-medium ${editRole === 'admin' ? 'bg-emerald-500/10 border-emerald-500/30 text-emerald-400' : 'border-zinc-700 text-zinc-500 hover:border-zinc-600'}`}>
                      <Crown className="w-4 h-4" /> Admin
                    </button>
                  </div>
                </div>

                {/* Permissions (only for member) */}
                {editRole === 'member' && (
                  <div className="pt-2 border-t border-zinc-800">
                    <div className="flex items-center justify-between mb-2">
                      <label className="text-xs font-medium text-zinc-400">Acesso aos Menus</label>
                      <div className="flex gap-2">
                        <button type="button" onClick={() => setEditPermissions(NAV_ITEMS.map(i => i.to))}
                          className="text-[10px] text-blue-500 hover:text-blue-400 transition-colors">Todos</button>
                        <span className="text-zinc-700 text-[10px]">·</span>
                        <button type="button" onClick={() => setEditPermissions([])}
                          className="text-[10px] text-zinc-500 hover:text-zinc-400 transition-colors">Nenhum</button>
                      </div>
                    </div>
                    <div className="space-y-2 max-h-[200px] overflow-y-auto pr-1 custom-scrollbar">
                      {NAV_ITEMS.map(item => (
                        <label key={item.to} className="flex items-center gap-3 p-2.5 rounded-xl border border-zinc-800 hover:bg-zinc-800/50 cursor-pointer transition-all">
                          <input type="checkbox" className="hidden" checked={editPermissions.includes(item.to)} onChange={() => toggleEditPermission(item.to)} />
                          <div className={`w-5 h-5 rounded-md border flex items-center justify-center shrink-0 transition-all ${editPermissions.includes(item.to) ? 'bg-blue-500 border-blue-500' : 'border-zinc-600 bg-zinc-900'}`}>
                            {editPermissions.includes(item.to) && <CheckCircle className="w-3 h-3 text-zinc-950" />}
                          </div>
                          <div className="flex items-center gap-2 flex-1 min-w-0">
                            <item.icon className="w-4 h-4 text-zinc-500 shrink-0" />
                            <span className="text-sm font-medium text-zinc-300 truncate">{item.label}</span>
                            {item.adminOnly && (
                              <span className="text-[10px] text-amber-500/70 border border-amber-500/20 rounded px-1 shrink-0">admin</span>
                            )}
                          </div>
                        </label>
                      ))}
                    </div>
                    <p className="mt-2 text-[10px] text-zinc-600">
                      {editPermissions.length} de {NAV_ITEMS.length} menus selecionados
                    </p>
                  </div>
                )}

                {/* Actions */}
                <div className="flex gap-3 pt-2">
                  <button type="button" onClick={() => setEditingUser(null)}
                    className="flex-1 py-2.5 rounded-xl border border-zinc-700 text-zinc-400 hover:bg-zinc-800 transition-all text-sm font-medium">
                    Cancelar
                  </button>
                  <button type="button" onClick={handleSaveAccess} disabled={editLoading}
                    className="flex-1 bg-blue-500 hover:bg-blue-400 disabled:opacity-50 text-white font-semibold py-2.5 rounded-xl transition-all flex items-center justify-center gap-2 text-sm">
                    {editLoading ? <><Loader2 className="w-4 h-4 animate-spin" /> Salvando...</> : <><Save className="w-4 h-4" /> Salvar Acesso</>}
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* Users list */}
        <div className="bg-zinc-900/60 border border-zinc-800 rounded-3xl overflow-hidden">
          {/* Table header */}
          <div className="px-6 py-4 border-b border-zinc-800 flex items-center gap-3">
            <Users className="w-4 h-4 text-zinc-500" />
            <span className="text-sm font-medium text-zinc-400">
              {loading ? 'Carregando...' : `${users.length} usuário${users.length !== 1 ? 's' : ''}`}
            </span>
          </div>

          {loading ? (
            <div className="flex items-center justify-center py-16">
              <Loader2 className="w-7 h-7 text-emerald-500 animate-spin" />
            </div>
          ) : users.length === 0 ? (
            <div className="flex flex-col items-center justify-center py-16 text-zinc-600">
              <Users className="w-12 h-12 mb-3" />
              <p className="text-sm">Nenhum usuário encontrado</p>
            </div>
          ) : (
            <div className="divide-y divide-zinc-800/70">
              {users.map(u => {
                const name = u.user_metadata?.name || u.email.split('@')[0];
                const role = u.user_metadata?.role || 'member';
                const permissions = u.user_metadata?.permissions || [];
                const isMe = u.id === currentUser?.id;
                const joinDate = new Date(u.created_at).toLocaleDateString('pt-BR', { day: '2-digit', month: 'short', year: 'numeric' });
                const lastLogin = u.last_sign_in_at
                  ? new Date(u.last_sign_in_at).toLocaleDateString('pt-BR', { day: '2-digit', month: 'short', year: 'numeric' })
                  : 'Nunca';

                return (
                  <div key={u.id} className="flex items-center gap-4 px-6 py-4 hover:bg-zinc-800/20 transition-colors group">
                    {/* Avatar */}
                    <div className={`w-10 h-10 rounded-2xl flex items-center justify-center font-bold text-sm shrink-0 ${role === 'admin' ? 'bg-emerald-500/10 border border-emerald-500/30 text-emerald-400' : 'bg-zinc-800 border border-zinc-700 text-zinc-400'}`}>
                      {name.charAt(0).toUpperCase()}
                    </div>

                    {/* Info */}
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 mb-0.5 flex-wrap">
                        <span className="font-medium text-zinc-100 text-sm truncate">{name}</span>
                        {isMe && <span className="text-xs bg-zinc-800 text-zinc-400 px-2 py-0.5 rounded-full border border-zinc-700">Você</span>}
                        {role === 'admin'
                          ? <span className="text-xs bg-emerald-500/10 text-emerald-400 px-2 py-0.5 rounded-full border border-emerald-500/20 flex items-center gap-1"><Crown className="w-3 h-3" />Admin</span>
                          : <span className="text-xs bg-zinc-800/80 text-zinc-500 px-2 py-0.5 rounded-full border border-zinc-700/50 flex items-center gap-1"><UserCheck className="w-3 h-3" />Membro · {permissions.length} menus</span>
                        }
                      </div>
                      <p className="text-xs text-zinc-500 truncate">{u.email}</p>
                    </div>

                    {/* Dates */}
                    <div className="hidden lg:block text-right">
                      <p className="text-xs text-zinc-500">Entrou: {joinDate}</p>
                      <p className="text-xs text-zinc-600">Login: {lastLogin}</p>
                    </div>

                    {/* Actions */}
                    {!isMe && (
                      <div className="flex items-center gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                        <button
                          onClick={() => openEditModal(u)}
                          title="Editar acesso"
                          className="p-2 rounded-xl border border-blue-500/20 text-blue-500 hover:bg-blue-500/10 transition-all"
                        >
                          <Settings2 className="w-4 h-4" />
                        </button>
                        <button
                          onClick={() => handleToggleRole(u.id, role, name)}
                          title={role === 'admin' ? 'Rebaixar para Membro' : 'Promover para Admin'}
                          className={`p-2 rounded-xl border transition-all text-xs ${role === 'admin' ? 'border-zinc-700 text-zinc-400 hover:bg-zinc-800 hover:text-zinc-200' : 'border-emerald-500/20 text-emerald-500 hover:bg-emerald-500/10'}`}
                        >
                          {role === 'admin' ? <UserCheck className="w-4 h-4" /> : <Crown className="w-4 h-4" />}
                        </button>
                        <button
                          onClick={() => handleDelete(u.id, name)}
                          disabled={deletingId === u.id}
                          className="p-2 rounded-xl border border-red-500/20 text-red-500 hover:bg-red-500/10 transition-all disabled:opacity-50"
                        >
                          {deletingId === u.id ? <Loader2 className="w-4 h-4 animate-spin" /> : <Trash2 className="w-4 h-4" />}
                        </button>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {/* Info */}
        <div className="mt-4 flex items-start gap-3 bg-zinc-900/40 border border-zinc-800 rounded-2xl px-4 py-3">
          <Shield className="w-4 h-4 text-zinc-600 mt-0.5 shrink-0" />
          <p className="text-xs text-zinc-600">
            Administradores têm acesso total ao sistema incluindo gerenciamento de usuários. Membros têm acesso somente aos menus liberados pelo administrador.
          </p>
        </div>
      </div>
    </div>
  );
}