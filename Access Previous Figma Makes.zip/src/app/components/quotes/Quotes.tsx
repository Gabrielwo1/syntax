import { useState } from "react";
import { FileText, Printer, Building, Clock, DollarSign, Download, CheckCircle2 } from "lucide-react";

import imgLogo from "figma:asset/315d8cb9df218a4d108c1796691e847942e27f6b.png";

import { useAuth } from '../../context/AuthContext';
import { Shield } from 'lucide-react';

export function Quotes() {
  const { isAdmin } = useAuth();
  const [client, setClient] = useState("");
  const [description, setDescription] = useState("");
  const [deliveryTime, setDeliveryTime] = useState("");
  const [value, setValue] = useState("");

  const handlePrint = () => {
    window.print();
  };

  if (!isAdmin) {
    return (
      <div className="flex-1 flex items-center justify-center h-full bg-[#111111]">
        <div className="text-center">
          <Shield className="w-16 h-16 text-zinc-700 mx-auto mb-4" />
          <h2 className="text-xl font-bold text-zinc-300 mb-2">Acesso Restrito</h2>
          <p className="text-zinc-500">Apenas administradores podem acessar os Orçamentos.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="flex-1 flex flex-col h-full bg-zinc-950 text-zinc-50 overflow-hidden">
      {/* Header */}
      <div className="flex-none p-6 md:p-8 border-b border-zinc-800 bg-zinc-900/50 flex flex-col sm:flex-row sm:items-center justify-between gap-4 print:hidden">
        <div>
          <h1 className="text-2xl font-bold text-zinc-50 tracking-tight">Gerador de Orçamentos</h1>
          <p className="text-zinc-400 text-sm mt-1">Crie propostas comerciais estilizadas e profissionais</p>
        </div>
        
        <button
          onClick={handlePrint}
          className="flex items-center gap-2 bg-emerald-600 hover:bg-emerald-500 text-zinc-50 px-5 py-2.5 rounded-xl text-sm font-medium transition-all shadow-lg"
        >
          <Download className="w-4 h-4" />
          <span>Baixar PDF</span>
        </button>
      </div>

      {/* Main Content Split */}
      <div className="flex-1 flex flex-col lg:flex-row overflow-hidden print:overflow-visible">
        
        {/* Formulário (Left Side) */}
        <div className="w-full lg:w-1/3 xl:w-96 flex-none bg-zinc-900 border-r border-zinc-800 p-6 overflow-y-auto print:hidden">
          <h2 className="text-lg font-semibold text-zinc-50 mb-6 flex items-center gap-2">
            <FileText className="w-5 h-5 text-emerald-500" />
            Dados da Proposta
          </h2>

          <div className="space-y-5">
            <div>
              <label className="block text-sm font-medium text-zinc-300 mb-1.5">Nome do Cliente / Empresa</label>
              <div className="relative">
                <Building className="absolute left-3 top-2.5 w-4 h-4 text-zinc-500" />
                <input
                  type="text"
                  value={client}
                  onChange={(e) => setClient(e.target.value)}
                  placeholder="Ex: Acme Corp"
                  className="w-full pl-9 pr-3 py-2 bg-zinc-950/50 border border-zinc-800 rounded-xl text-sm text-zinc-50 placeholder-zinc-600 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500 transition-all"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-zinc-300 mb-1.5">Descrição do Serviço</label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Ex: Desenvolvimento de Landing Page de alta conversão..."
                rows={5}
                className="w-full px-3 py-2 bg-zinc-950/50 border border-zinc-800 rounded-xl text-sm text-zinc-50 placeholder-zinc-600 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500 resize-none transition-all"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-zinc-300 mb-1.5">Tempo de Entrega</label>
              <div className="relative">
                <Clock className="absolute left-3 top-2.5 w-4 h-4 text-zinc-500" />
                <input
                  type="text"
                  value={deliveryTime}
                  onChange={(e) => setDeliveryTime(e.target.value)}
                  placeholder="Ex: 15 dias úteis"
                  className="w-full pl-9 pr-3 py-2 bg-zinc-950/50 border border-zinc-800 rounded-xl text-sm text-zinc-50 placeholder-zinc-600 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500 transition-all"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-zinc-300 mb-1.5">Valor do Investimento</label>
              <div className="relative">
                <DollarSign className="absolute left-3 top-2.5 w-4 h-4 text-zinc-500" />
                <input
                  type="text"
                  value={value}
                  onChange={(e) => setValue(e.target.value)}
                  placeholder="Ex: R$ 3.500,00"
                  className="w-full pl-9 pr-3 py-2 bg-zinc-950/50 border border-zinc-800 rounded-xl text-sm text-zinc-50 placeholder-zinc-600 focus:outline-none focus:ring-2 focus:ring-emerald-500/50 focus:border-emerald-500 transition-all"
                />
              </div>
            </div>
          </div>
          
          <div className="mt-8 p-4 bg-emerald-500/10 border border-emerald-500/20 rounded-2xl flex items-start gap-3">
            <CheckCircle2 className="w-5 h-5 text-emerald-500 shrink-0 mt-0.5" />
            <p className="text-xs text-emerald-400/90 leading-relaxed">
              O preview ao lado é atualizado em tempo real. Use o botão <strong>Imprimir / PDF</strong> no topo para gerar o arquivo final.
            </p>
          </div>
        </div>

        {/* Preview (Right Side) */}
        <div className="flex-1 bg-zinc-950 p-4 sm:p-8 overflow-y-auto print:p-0 print:m-0 print:bg-white print:overflow-visible">
          
          {/* Paper Sheet container */}
          <div className="max-w-4xl mx-auto bg-zinc-900 border border-zinc-800/50 shadow-2xl rounded-3xl overflow-hidden min-h-[842px] print:min-h-0 print:shadow-none print:border-none print:rounded-none print:bg-white relative">
            
            {/* Background elements (Not printed) */}
            <div className="absolute top-0 right-0 w-[500px] h-[500px] bg-emerald-600/10 rounded-full blur-[100px] -translate-y-1/2 translate-x-1/2 pointer-events-none print:hidden"></div>
            <div className="absolute bottom-0 left-0 w-[400px] h-[400px] bg-emerald-600/5 rounded-full blur-[80px] translate-y-1/2 -translate-x-1/2 pointer-events-none print:hidden"></div>

            {/* Document Content */}
            <div className="relative p-10 sm:p-16 h-full flex flex-col print:text-black">
              
              {/* Doc Header */}
              <div className="flex justify-between items-start mb-16 pb-8 border-b border-zinc-800 print:border-zinc-300">
                <div>
                  <div className="relative h-10 w-32 flex items-center overflow-hidden mb-2">
                    <img 
                      src={imgLogo} 
                      alt="Syntax Logo" 
                      className="absolute h-[250%] max-w-none left-[-5px] top-[-50%] print:filter print:brightness-0" 
                    />
                  </div>
                  <p className="text-sm font-medium text-zinc-500 print:text-zinc-600 mt-2">Agência Digital & Desenvolvimento</p>
                </div>
                <div className="text-right">
                  <p className="text-sm font-bold text-zinc-50 print:text-black tracking-widest uppercase mb-1">PROPOSTA COMERCIAL</p>
                  <p className="text-xs text-zinc-500 print:text-zinc-600">Data: {new Date().toLocaleDateString('pt-BR')}</p>
                </div>
              </div>

              {/* Client Info */}
              <div className="mb-12">
                <p className="text-xs font-semibold text-zinc-500 print:text-zinc-500 uppercase tracking-wider mb-2">Preparado para</p>
                <h3 className="text-2xl font-bold text-emerald-400 print:text-emerald-700">{client || "Nome do Cliente"}</h3>
              </div>

              {/* Service Description */}
              <div className="mb-12 flex-1">
                <p className="text-xs font-semibold text-zinc-500 print:text-zinc-500 uppercase tracking-wider mb-4">Escopo do Projeto</p>
                <div className="prose prose-invert print:prose-p:text-black max-w-none">
                  {description ? (
                    <div className="text-zinc-300 print:text-zinc-800 text-sm md:text-base leading-relaxed whitespace-pre-wrap">
                      {description}
                    </div>
                  ) : (
                    <div className="text-zinc-700 print:text-zinc-300 text-sm italic border-l-2 border-zinc-800 pl-4 py-1">
                      A descrição do serviço será exibida aqui...
                    </div>
                  )}
                </div>
              </div>

              {/* Terms Grid */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-16">
                <div className="bg-zinc-950/50 print:bg-zinc-50 border border-zinc-800 print:border-zinc-200 rounded-2xl p-6 relative overflow-hidden group">
                  <div className="absolute top-0 right-0 p-4 opacity-10 print:opacity-5 group-hover:opacity-20 transition-opacity">
                    <Clock className="w-16 h-16 text-emerald-500" />
                  </div>
                  <p className="text-xs font-semibold text-zinc-500 print:text-zinc-500 uppercase tracking-wider mb-2 relative z-10">Prazo Estimado</p>
                  <p className="text-xl font-bold text-zinc-100 print:text-black relative z-10">{deliveryTime || "—"}</p>
                </div>

                <div className="bg-emerald-900/20 print:bg-emerald-50 border border-emerald-500/20 print:border-emerald-200 rounded-2xl p-6 relative overflow-hidden group">
                  <div className="absolute top-0 right-0 p-4 opacity-10 print:opacity-5 group-hover:opacity-20 transition-opacity">
                    <DollarSign className="w-16 h-16 text-emerald-500" />
                  </div>
                  <p className="text-xs font-semibold text-emerald-600/80 print:text-emerald-700/80 uppercase tracking-wider mb-2 relative z-10">Investimento Total</p>
                  <p className="text-2xl font-bold text-emerald-400 print:text-emerald-700 relative z-10">{value || "—"}</p>
                </div>
              </div>

              {/* Footer / Signatures */}
              <div className="mt-auto pt-8 border-t border-zinc-800 print:border-zinc-300">
                <p className="text-xs text-zinc-500 print:text-zinc-500 text-center mb-6">
                  Validade desta proposta: 15 dias corridos a partir da data de emissão.
                </p>
                <div className="flex items-end justify-center pt-8">
                  
                </div>
              </div>

            </div>
          </div>
        </div>

      </div>

      <style dangerouslySetInnerHTML={{__html: `
        @media print {
          @page { margin: 1cm; size: A4; }
          body { background-color: white !important; }
          
          /* Esconder elementos da UI principal da aplicação que não sejam o orcamento */
          aside, nav, .print\\:hidden { display: none !important; }
          
          /* Forçar cores de fundo para imprimir fielmente (caso suportado pelo browser) */
          * {
            -webkit-print-color-adjust: exact !important;
            print-color-adjust: exact !important;
          }
        }
      `}} />
    </div>
  );
}