import React, { useState, useEffect, useRef } from "react";
import { X, Mic, MicOff, Sparkles, Wand2, Loader2, Paperclip, XCircle, FileIcon } from "lucide-react";
import type { Task, Attachment } from "./TaskModal";
import { projectId } from "/utils/supabase/info";
import { fetchWithAuth } from "../utils/auth";

const BASE_URL = `https://${projectId}.supabase.co/functions/v1/make-server-cee56a32`;

interface AITaskModalProps {
  onClose: () => void;
  onGenerate: (tasks: Partial<Task>[]) => void;
}

export function AITaskModal({ onClose, onGenerate }: AITaskModalProps) {
  const [text, setText] = useState("");
  const [isRecording, setIsRecording] = useState(false);
  const [isProcessing, setIsProcessing] = useState(false);
  const [micError, setMicError] = useState("");
  const [attachments, setAttachments] = useState<Attachment[]>([]);
  const [isUploading, setIsUploading] = useState(false);
  const recognitionRef = useRef<any>(null);

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setIsUploading(true);
    try {
      const data = new FormData();
      data.append("file", file);

      const res = await fetchWithAuth(`${BASE_URL}/upload`, {
        method: "POST",
        body: data,
      });

      if (!res.ok) throw new Error("Falha no upload");
      const result = await res.json();
      
      setAttachments((prev) => [...prev, { name: result.name, path: result.path }]);
    } catch (err) {
      console.error(err);
      setMicError("Erro ao enviar anexo. Verifique sua conexão e tente novamente.");
    } finally {
      setIsUploading(false);
    }
  };

  const handleRemoveAttachment = (index: number) => {
    setAttachments((prev) => prev.filter((_, i) => i !== index));
  };

  useEffect(() => {
    // Initialize Speech Recognition
    if (typeof window !== "undefined") {
      const SpeechRecognition =
        (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;
      if (SpeechRecognition) {
        const recognition = new SpeechRecognition();
        recognition.continuous = true;
        recognition.interimResults = true;
        recognition.lang = "pt-BR";

        recognition.onresult = (event: any) => {
          let currentTranscript = "";
          for (let i = event.resultIndex; i < event.results.length; i++) {
            currentTranscript += event.results[i][0].transcript;
          }
          setText((prev) => {
            // Only append the new final/interim string smoothly. 
            // A simpler approach for continuous is just to replace the latter part or just use interim.
            // For simplicity, we just take the whole transcript if we reset it, or we append.
            return currentTranscript; 
          });
        };

        recognition.onerror = (event: any) => {
          // console.error("Speech recognition error", event.error); // Removing console.error to avoid overlay in preview
          setIsRecording(false);
          if (event.error === 'not-allowed') {
            setMicError("Permissão de microfone negada. Por favor, digite sua tarefa ou permita o acesso ao microfone no navegador.");
          } else {
            setMicError(`Erro no reconhecimento de voz: ${event.error}`);
          }
        };

        recognition.onend = () => {
          setIsRecording(false);
        };

        recognitionRef.current = recognition;
      }
    }
  }, []);

  const toggleRecording = () => {
    setMicError("");
    if (!recognitionRef.current) {
      setMicError("Reconhecimento de voz não suportado neste navegador. Por favor, digite sua tarefa.");
      return;
    }

    if (isRecording) {
      recognitionRef.current.stop();
      setIsRecording(false);
    } else {
      setText(""); // Reset text on new recording
      try {
        recognitionRef.current.start();
        setIsRecording(true);
      } catch (err) {
        console.error("Failed to start recording:", err);
        setMicError("Não foi possível iniciar a gravação. Por favor, digite sua tarefa.");
      }
    }
  };

  const processText = async () => {
    if (!text.trim()) return;
    setIsProcessing(true);
    setMicError("");

    try {
      const res = await fetchWithAuth(`${BASE_URL}/tasks/ai-generate`, {
        method: "POST",
        body: JSON.stringify({ text }),
      });

      if (!res.ok) {
        const err = await res.json().catch(() => ({}));
        console.error("[AITaskModal] Backend error:", err);
        throw new Error(err.error || `Erro ${res.status}`);
      }

      const data = await res.json();
      let generatedTasks: Partial<Task>[] = data.tasks || [];
      if (!Array.isArray(generatedTasks) || generatedTasks.length === 0) {
        throw new Error("A IA não retornou tarefas válidas.");
      }

      // Attach any uploaded files to all generated tasks
      generatedTasks = generatedTasks.map((t: any) => ({
        ...t,
        attachments: attachments,
      }));

      onGenerate(generatedTasks);
    } catch (error: any) {
      console.error("[AITaskModal] Error:", error);
      setMicError(
        error?.message?.includes("GEMINI_API_KEY")
          ? "Chave do Gemini não configurada no servidor. Adicione GEMINI_API_KEY nas variáveis de ambiente."
          : `Erro ao processar com a IA: ${error?.message || "tente novamente"}.`
      );
    } finally {
      setIsProcessing(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4 bg-black/60 backdrop-blur-sm transition-all duration-200">
      <div className="bg-[#111111] border border-zinc-800 rounded-2xl shadow-2xl w-full max-w-lg overflow-hidden flex flex-col relative scale-100">
        {/* Glow effects */}
        <div className="absolute top-0 inset-x-0 h-px bg-gradient-to-r from-transparent via-indigo-500/50 to-transparent"></div>
        <div className="absolute top-[-50px] left-1/2 -translate-x-1/2 w-48 h-24 bg-indigo-500/20 blur-[50px] rounded-full pointer-events-none"></div>

        <div className="px-6 py-5 border-b border-zinc-800/50 flex items-center justify-between relative z-10">
          <div className="flex items-center gap-3">
            <div className="w-8 h-8 rounded-lg bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h2 className="text-lg font-semibold text-zinc-100">Syntax AI</h2>
              <p className="text-xs text-zinc-500 font-medium">Crie tarefas usando voz ou texto natural</p>
            </div>
          </div>
          <button
            onClick={onClose}
            className="p-2 text-zinc-500 hover:text-zinc-300 hover:bg-zinc-800/50 rounded-lg transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 relative z-10">
          <div className="relative">
            <textarea
              value={text}
              onChange={(e) => setText(e.target.value)}
              placeholder="Ex: Criar tarefa para revisar o design no projeto Website para amanhã..."
              className="w-full h-32 bg-zinc-900 border border-zinc-800 rounded-xl p-4 text-zinc-100 placeholder:text-zinc-600 focus:outline-none focus:border-indigo-500/50 focus:ring-1 focus:ring-indigo-500/50 resize-none transition-all"
            />
            
            <div className="absolute bottom-4 right-4 flex items-center gap-2">
              <label 
                className={`p-3 rounded-full flex items-center justify-center transition-all cursor-pointer ${
                  isUploading 
                    ? "bg-zinc-800 text-zinc-500 border border-zinc-700" 
                    : "bg-zinc-800 text-zinc-400 border border-zinc-700 hover:bg-zinc-700 hover:text-zinc-200"
                }`}
                title="Anexar arquivo"
              >
                <input type="file" className="hidden" onChange={handleUpload} disabled={isUploading || isProcessing} />
                {isUploading ? <Loader2 className="w-4 h-4 animate-spin" /> : <Paperclip className="w-4 h-4" />}
              </label>
              <button
                onClick={toggleRecording}
                className={`p-3 rounded-full flex items-center justify-center transition-all ${
                  isRecording 
                    ? "bg-red-500/20 text-red-500 border border-red-500/30 animate-pulse" 
                    : "bg-zinc-800 text-zinc-400 border border-zinc-700 hover:bg-zinc-700 hover:text-zinc-200"
                }`}
                title={isRecording ? "Parar gravação" : "Gravar áudio"}
              >
                {isRecording ? <MicOff className="w-4 h-4" /> : <Mic className="w-4 h-4" />}
              </button>
            </div>
          </div>

          {attachments.length > 0 && (
            <div className="mt-4 flex flex-wrap gap-2">
              {attachments.map((att, idx) => (
                <div key={idx} className="flex items-center gap-2 px-3 py-1.5 bg-zinc-800 rounded-lg text-sm border border-zinc-700 animate-in fade-in slide-in-from-bottom-2">
                  <FileIcon className="w-3.5 h-3.5 text-indigo-400" />
                  <span className="text-zinc-300 truncate max-w-[150px]">{att.name}</span>
                  <button
                    onClick={() => handleRemoveAttachment(idx)}
                    className="text-zinc-500 hover:text-red-400 transition-colors ml-1"
                    title="Remover anexo"
                  >
                    <XCircle className="w-3.5 h-3.5" />
                  </button>
                </div>
              ))}
            </div>
          )}

          {micError && (
            <div className="mt-4 p-3 rounded-lg bg-red-500/10 border border-red-500/20 text-red-400 text-sm">
              {micError}
            </div>
          )}

          <div className="mt-6 flex justify-end">
            <button
              onClick={processText}
              disabled={!text.trim() || isProcessing}
              className="flex items-center gap-2 bg-indigo-600 hover:bg-indigo-700 text-white px-5 py-2.5 rounded-lg text-sm font-medium transition-all shadow-sm shadow-indigo-900/20 disabled:opacity-50 disabled:cursor-not-allowed"
            >
              {isProcessing ? (
                <>
                  <Loader2 className="w-4 h-4 animate-spin" />
                  Processando...
                </>
              ) : (
                <>
                  <Wand2 className="w-4 h-4" />
                  Gerar Tarefa
                </>
              )}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}