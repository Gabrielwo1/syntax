import React, { useState, useEffect } from "react";
import { Plus, Search, Calendar, ChevronDown, CheckSquare, MessageSquare, MoreHorizontal, FileText, CheckCircle2, Clock, Circle } from "lucide-react";
import { projectId } from "/utils/supabase/info";
import { fetchWithAuth } from "../../utils/auth";
import { TaskModal, type Task, type TaskStatus } from "./TaskModal";

const API = `https://${projectId}.supabase.co/functions/v1/make-server-cee56a32/tasks`;

const STATUS_CONFIG = {
  not_started: {
    label: "Não iniciada",
    icon: Circle,
    colors: "bg-zinc-800 text-zinc-300 border-zinc-700",
  },
  in_progress: {
    label: "Em andamento",
    icon: Clock,
    colors: "bg-blue-500/20 text-blue-400 border-blue-500/30",
  },
  done: {
    label: "Concluída",
    icon: CheckCircle2,
    colors: "bg-emerald-500/20 text-emerald-400 border-emerald-500/30",
  },
};

export function Tasks() {
  const [tasks, setTasks] = useState<Task[]>([]);
  const [loading, setLoading] = useState(true);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingTask, setEditingTask] = useState<Task | null>(null);

  const fetchTasks = async () => {
    try {
      const res = await fetchWithAuth(API);
      if (res.ok) {
        const data = await res.json();
        setTasks(data.tasks || []);
      }
    } catch (error) {
      console.error("Failed to fetch tasks", error);
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchTasks();
  }, []);

  const handleSaveTask = async (task: Task) => {
    try {
      const method = task.id ? "PUT" : "POST";
      const url = task.id ? `${API}/${task.id}` : API;
      
      const res = await fetchWithAuth(url, {
        method,
        body: JSON.stringify(task),
      });

      if (res.ok) {
        await fetchTasks();
        setIsModalOpen(false);
        setEditingTask(null);
      }
    } catch (error) {
      console.error("Failed to save task", error);
    }
  };

  const openNewTask = () => {
    setEditingTask(null);
    setIsModalOpen(true);
  };

  const openEditTask = (task: Task) => {
    setEditingTask(task);
    setIsModalOpen(true);
  };

  const formatDate = (dateStr: string) => {
    if (!dateStr) return "—";
    const date = new Date(dateStr);
    return new Intl.DateTimeFormat('pt-BR', { 
      day: 'numeric', 
      month: 'long', 
      year: 'numeric' 
    }).format(date);
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-[#111111] overflow-hidden">
      {/* Header */}
      <header className="flex-shrink-0 px-8 py-6 border-b border-zinc-800/50">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-8 h-8 rounded-lg bg-zinc-800 border border-zinc-700 flex items-center justify-center">
            <CheckSquare className="w-5 h-5 text-zinc-300" />
          </div>
          <h1 className="text-2xl font-semibold text-zinc-50 tracking-tight">Tarefas</h1>
        </div>

        <div className="flex flex-col sm:flex-row items-start sm:items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <div className="flex items-center gap-2 px-3 py-1.5 bg-zinc-800/50 border border-zinc-700/50 rounded-lg cursor-pointer hover:bg-zinc-800 transition-colors">
              <span className="text-sm font-medium text-zinc-300">Todas as Tarefas</span>
              <ChevronDown className="w-4 h-4 text-zinc-500" />
            </div>
            
            <div className="h-4 w-px bg-zinc-800 mx-2" />
            
            <div className="relative">
              <Search className="w-4 h-4 text-zinc-500 absolute left-3 top-1/2 -translate-y-1/2" />
              <input
                type="text"
                placeholder="Buscar tarefa..."
                className="pl-9 pr-4 py-1.5 bg-zinc-900 border border-zinc-800 rounded-lg text-sm text-zinc-300 focus:outline-none focus:border-zinc-700 w-64 placeholder:text-zinc-600"
              />
            </div>
          </div>
          <button
            onClick={openNewTask}
            className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg text-sm font-medium transition-all shadow-sm"
          >
            <Plus className="w-4 h-4" />
            Nova Tarefa
          </button>
        </div>
      </header>

      {/* Main Content - Table */}
      <div className="flex-1 overflow-auto p-8">
        <div className="bg-zinc-900/50 border border-zinc-800/50 rounded-xl overflow-hidden">
          <table className="w-full text-left border-collapse">
            <thead>
              <tr className="border-b border-zinc-800/50 text-xs font-medium text-zinc-500">
                <th className="py-3 px-4 w-12 text-center">
                  <div className="w-4 h-4 border border-zinc-700 rounded bg-zinc-900 mx-auto"></div>
                </th>
                <th className="py-3 px-4 w-48 flex items-center gap-2">
                  <Circle className="w-3.5 h-3.5" /> Projeto
                </th>
                <th className="py-3 px-4 flex items-center gap-2">
                  <FileText className="w-3.5 h-3.5" /> Nome da Tarefa
                </th>
                <th className="py-3 px-4 w-48 flex items-center gap-2">
                  <Clock className="w-3.5 h-3.5" /> Status
                </th>
                <th className="py-3 px-4 w-48 flex items-center gap-2">
                  <Calendar className="w-3.5 h-3.5" /> Prazo
                </th>
                <th className="py-3 px-4 w-48 flex items-center gap-2">
                  <MoreHorizontal className="w-3.5 h-3.5" /> Responsável
                </th>
                <th className="py-3 px-4 w-12"></th>
              </tr>
            </thead>
            <tbody className="text-sm">
              {loading ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-zinc-500">
                    Carregando tarefas...
                  </td>
                </tr>
              ) : tasks.length === 0 ? (
                <tr>
                  <td colSpan={7} className="py-12 text-center text-zinc-500">
                    Nenhuma tarefa cadastrada.
                  </td>
                </tr>
              ) : (
                tasks.map((task) => {
                  const statusConf = STATUS_CONFIG[task.status] || STATUS_CONFIG.not_started;
                  const StatusIcon = statusConf.icon;

                  return (
                    <tr 
                      key={task.id} 
                      onClick={() => openEditTask(task)}
                      className="border-b border-zinc-800/50 hover:bg-zinc-800/30 transition-colors cursor-pointer group"
                    >
                      <td className="py-3 px-4 text-center">
                        <div className="w-4 h-4 border border-zinc-700 rounded bg-zinc-900 mx-auto group-hover:border-zinc-500 transition-colors"></div>
                      </td>
                      <td className="py-3 px-4 font-medium text-zinc-300">
                        {task.project}
                      </td>
                      <td className="py-3 px-4 text-zinc-100 font-medium flex items-center gap-3">
                        <FileText className="w-4 h-4 text-zinc-600" />
                        {task.name}
                        {task.attachments?.length > 0 && (
                          <div className="flex items-center gap-1 text-zinc-500 ml-2 px-1.5 py-0.5 rounded bg-zinc-800/50">
                            <MessageSquare className="w-3 h-3" />
                            <span className="text-[10px]">{task.attachments.length}</span>
                          </div>
                        )}
                      </td>
                      <td className="py-3 px-4">
                        <span className={`inline-flex items-center gap-1.5 px-2.5 py-1 rounded-md border text-xs font-medium ${statusConf.colors}`}>
                          <StatusIcon className="w-3.5 h-3.5" />
                          {statusConf.label}
                        </span>
                      </td>
                      <td className="py-3 px-4 text-zinc-400">
                        {formatDate(task.due)}
                      </td>
                      <td className="py-3 px-4">
                        <div className="flex items-center gap-2">
                          {task.assignee && (
                            <>
                              <div className="w-6 h-6 rounded-full bg-zinc-700 flex items-center justify-center text-[10px] font-bold text-zinc-300 uppercase overflow-hidden">
                                {task.assignee.substring(0, 2)}
                              </div>
                              <span className="text-zinc-300">{task.assignee}</span>
                            </>
                          )}
                        </div>
                      </td>
                      <td className="py-3 px-4 text-zinc-500 opacity-0 group-hover:opacity-100 transition-opacity">
                        <MoreHorizontal className="w-4 h-4" />
                      </td>
                    </tr>
                  );
                })
              )}
            </tbody>
          </table>
        </div>
      </div>

      {isModalOpen && (
        <TaskModal
          task={editingTask}
          onClose={() => setIsModalOpen(false)}
          onSave={handleSaveTask}
        />
      )}
    </div>
  );
}