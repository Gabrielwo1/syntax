import React, { useState, useEffect } from "react";
import { X, Upload, File as FileIcon, XCircle, Loader2 } from "lucide-react";
import { projectId } from "/utils/supabase/info";
import { fetchWithAuth } from "../../utils/auth";

const API = `https://${projectId}.supabase.co/functions/v1/make-server-cee56a32/tasks`;

export type TaskStatus = "not_started" | "in_progress" | "done";

export interface Attachment {
  name: string;
  path: string;
}

export interface Task {
  id?: string;
  project: string;
  name: string;
  status: TaskStatus;
  due: string;
  assignee: string;
  attachments: Attachment[];
  createdAt?: string;
}

interface TaskModalProps {
  task?: Task | null;
  onClose: () => void;
  onSave: (task: Task) => Promise<void>;
}

export function TaskModal({ task, onClose, onSave }: TaskModalProps) {
  const [formData, setFormData] = useState<Task>(
    task || {
      project: "",
      name: "",
      status: "not_started",
      due: "",
      assignee: "",
      attachments: [],
    }
  );

  const [saving, setSaving] = useState(false);
  const [uploading, setUploading] = useState(false);

  const handleUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    setUploading(true);
    try {
      const data = new FormData();
      data.append("file", file);

      const res = await fetchWithAuth(`${API}/upload`, {
        method: "POST",
        body: data,
      });

      if (!res.ok) throw new Error("Falha no upload");
      const result = await res.json();
      
      setFormData((prev) => ({
        ...prev,
        attachments: [...prev.attachments, { name: result.name, path: result.path }],
      }));
    } catch (err) {
      console.error(err);
      alert("Erro ao enviar anexo");
    } finally {
      setUploading(false);
    }
  };

  const handleRemoveAttachment = (index: number) => {
    setFormData((prev) => ({
      ...prev,
      attachments: prev.attachments.filter((_, i) => i !== index),
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setSaving(true);
    try {
      await onSave(formData);
    } catch (err) {
      console.error(err);
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4">
      <div className="w-full max-w-lg bg-zinc-900 border border-zinc-800 rounded-2xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        <div className="flex items-center justify-between p-5 border-b border-zinc-800">
          <h2 className="text-xl font-semibold text-zinc-50">
            {task ? "Editar Tarefa" : "Nova Tarefa"}
          </h2>
          <button
            onClick={onClose}
            className="text-zinc-400 hover:text-zinc-50 transition-colors p-1"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="flex-1 overflow-y-auto p-5 space-y-4">
          <div>
            <label className="block text-sm font-medium text-zinc-400 mb-1.5">
              Projeto
            </label>
            <input
              type="text"
              required
              value={formData.project}
              onChange={(e) => setFormData({ ...formData, project: e.target.value })}
              placeholder="Ex: Onnix, Syntax..."
              className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-2.5 text-sm text-zinc-50 focus:outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/50 transition-all"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-zinc-400 mb-1.5">
              Nome da Tarefa
            </label>
            <input
              type="text"
              required
              value={formData.name}
              onChange={(e) => setFormData({ ...formData, name: e.target.value })}
              placeholder="Ex: Inserir vídeo no site"
              className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-2.5 text-sm text-zinc-50 focus:outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/50 transition-all"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-zinc-400 mb-1.5">
                Status
              </label>
              <select
                value={formData.status}
                onChange={(e) => setFormData({ ...formData, status: e.target.value as TaskStatus })}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-2.5 text-sm text-zinc-50 focus:outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/50 transition-all appearance-none"
              >
                <option value="not_started">Não iniciada</option>
                <option value="in_progress">Em andamento</option>
                <option value="done">Concluída</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-zinc-400 mb-1.5">
                Prazo (Due)
              </label>
              <input
                type="date"
                value={formData.due}
                onChange={(e) => setFormData({ ...formData, due: e.target.value })}
                className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-2.5 text-sm text-zinc-50 focus:outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/50 transition-all"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-zinc-400 mb-1.5">
              Responsável (Assignee)
            </label>
            <input
              type="text"
              value={formData.assignee}
              onChange={(e) => setFormData({ ...formData, assignee: e.target.value })}
              placeholder="Nome do funcionário"
              className="w-full bg-zinc-950 border border-zinc-800 rounded-xl px-4 py-2.5 text-sm text-zinc-50 focus:outline-none focus:border-emerald-500/50 focus:ring-1 focus:ring-emerald-500/50 transition-all"
            />
          </div>

          <div className="pt-2">
            <label className="block text-sm font-medium text-zinc-400 mb-2">
              Anexos
            </label>
            <div className="space-y-3">
              {formData.attachments.map((att, idx) => (
                <div key={idx} className="flex items-center justify-between p-3 bg-zinc-950 border border-zinc-800 rounded-xl">
                  <div className="flex items-center gap-3 truncate">
                    <FileIcon className="w-4 h-4 text-emerald-500 shrink-0" />
                    <span className="text-sm text-zinc-300 truncate">{att.name}</span>
                  </div>
                  <button
                    type="button"
                    onClick={() => handleRemoveAttachment(idx)}
                    className="text-zinc-500 hover:text-red-400 transition-colors p-1"
                  >
                    <XCircle className="w-4 h-4" />
                  </button>
                </div>
              ))}
              
              <label className="flex items-center justify-center w-full p-4 border-2 border-dashed border-zinc-800 rounded-xl hover:border-emerald-500/50 hover:bg-emerald-500/5 transition-all cursor-pointer group">
                <input
                  type="file"
                  className="hidden"
                  onChange={handleUpload}
                  disabled={uploading}
                />
                <div className="flex items-center gap-2 text-sm text-zinc-400 group-hover:text-emerald-400">
                  {uploading ? (
                    <Loader2 className="w-4 h-4 animate-spin" />
                  ) : (
                    <Upload className="w-4 h-4" />
                  )}
                  <span>{uploading ? "Enviando..." : "Adicionar anexo"}</span>
                </div>
              </label>
            </div>
          </div>
        </div>

        <div className="p-5 border-t border-zinc-800 flex justify-end gap-3 shrink-0 bg-zinc-900">
          <button
            onClick={onClose}
            type="button"
            className="px-4 py-2 text-sm font-medium text-zinc-400 hover:text-zinc-50 transition-colors"
          >
            Cancelar
          </button>
          <button
            onClick={handleSubmit}
            disabled={saving || !formData.name || !formData.project}
            className="flex items-center gap-2 px-5 py-2 bg-emerald-500 hover:bg-emerald-600 text-white text-sm font-medium rounded-xl transition-all shadow-lg shadow-emerald-500/20 disabled:opacity-50 disabled:cursor-not-allowed"
          >
            {saving ? <Loader2 className="w-4 h-4 animate-spin" /> : null}
            {task ? "Salvar Alterações" : "Criar Tarefa"}
          </button>
        </div>
      </div>
    </div>
  );
}