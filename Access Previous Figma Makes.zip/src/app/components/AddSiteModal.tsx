import { useState } from "react";
import { X } from "lucide-react";

interface AddSiteModalProps {
  isOpen: boolean;
  onClose: () => void;
  onAdd: (url: string, clientName: string) => void;
}

export function AddSiteModal({ isOpen, onClose, onAdd }: AddSiteModalProps) {
  const [url, setUrl] = useState("");
  const [clientName, setClientName] = useState("");

  if (!isOpen) return null;

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (url && clientName) {
      onAdd(url, clientName);
      setUrl("");
      setClientName("");
    }
  };

  return (
    <div className="fixed inset-0 bg-zinc-950/80 backdrop-blur-sm flex items-center justify-center z-50 p-4 transition-all">
      <div className="bg-zinc-900 rounded-2xl shadow-2xl max-w-md w-full mx-auto overflow-hidden animate-in fade-in zoom-in-95 duration-200 border border-zinc-800">
        <div className="flex items-center justify-between p-6 border-b border-zinc-800 bg-zinc-900">
          <h2 className="text-xl font-bold tracking-tight text-zinc-50">Adicionar Novo Site</h2>
          <button
            onClick={onClose}
            className="p-2 text-zinc-500 hover:text-zinc-300 hover:bg-zinc-800 rounded-2xl transition-colors"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="p-6">
          <div className="space-y-5">
            <div>
              <label htmlFor="clientName" className="block text-sm font-semibold text-zinc-300 mb-2">
                Nome do Cliente
              </label>
              <input
                type="text"
                id="clientName"
                value={clientName}
                onChange={(e) => setClientName(e.target.value)}
                className="w-full px-4 py-2.5 border border-zinc-700 bg-zinc-950/50 rounded-2xl text-zinc-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all placeholder:text-zinc-600"
                placeholder="Ex: Empresa XYZ"
                required
              />
            </div>

            <div>
              <label htmlFor="url" className="block text-sm font-semibold text-zinc-300 mb-2">
                URL do Site
              </label>
              <input
                type="url"
                id="url"
                value={url}
                onChange={(e) => setUrl(e.target.value)}
                className="w-full px-4 py-2.5 border border-zinc-700 bg-zinc-950/50 rounded-2xl text-zinc-50 focus:outline-none focus:ring-2 focus:ring-emerald-500/20 focus:border-emerald-500 transition-all placeholder:text-zinc-600"
                placeholder="https://exemplo.com.br"
                required
              />
            </div>
          </div>

          <div className="flex gap-3 mt-8 pt-6 border-t border-zinc-800">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 px-4 py-2.5 border border-zinc-700 text-zinc-300 font-medium rounded-2xl hover:bg-zinc-800 hover:text-zinc-50 transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="flex-1 px-4 py-2.5 bg-emerald-600 text-white font-medium rounded-2xl hover:bg-emerald-700 transition-colors shadow-lg shadow-emerald-900/20"
            >
              Adicionar Site
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
