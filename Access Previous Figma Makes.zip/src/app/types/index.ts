export interface Site {
  id: string;
  name: string;
  url: string;
  status: "active" | "maintenance";
  client: {
    name: string;
    email: string;
    phone: string;
  };
  analytics: {
    totalVisits: number;
    uniqueVisitors: number;
    bounceRate: number;
    avgSessionDuration: string;
    trend: number;
  };
  lastUpdated: string;
}
