/**
 * routes.tsx — Configuração do React Router v7 (Data Mode).
 *
 * ARQUITETURA DE AUTH:
 * ─────────────────────────────────────────────────────────────────────────────
 * O AuthProvider é montado DENTRO da árvore do React Router como o componente
 * do route raiz (RootLayout). Isso garante que:
 *
 *   ✅ Todas as rotas filhas — incluindo /login — recebem o contexto de auth
 *      via herança React normal.
 *
 *   ✅ O React Router não cria um React root separado (como fazia em versões
 *      anteriores com BrowserRouter); o RouterProvider renderiza dentro do
 *      mesmo root React, portanto context providers externos FUNCIONAM.
 *      Porém, colocar o AuthProvider aqui é mais explícito e resiliente
 *      contra hot-reloads em desenvolvimento.
 *
 *   ✅ Sem o erro "useAuth must be used within AuthProvider", pois o provider
 *      sempre renderiza antes de qualquer rota filha.
 * ─────────────────────────────────────────────────────────────────────────────
 */

import { createBrowserRouter, Outlet } from 'react-router';
import { AuthProvider } from './context/AuthContext';
import { Dashboard } from './components/Dashboard';
import { SiteDetails } from './components/SiteDetails';
import { Instructions } from './components/Instructions';
import { Root } from './components/Root';
import { CRM } from './components/crm/CRM';
import { SocialMedia } from './components/social-media/SocialMedia';
import { SocialMediaRepository } from './components/social-media/SocialMediaRepository';
import { Quotes } from './components/quotes/Quotes';
import { Tasks } from './components/Tasks';
import { Financeiro } from './components/financeiro/Financeiro';
import { PdfSyntax } from './components/pdf-syntax/PdfSyntax';
import { CopyProspect } from './components/crm/CopyProspect';
import { Login } from './components/Login';
import { UserManagement } from './components/UserManagement';

/**
 * Layout raiz: monta o AuthProvider DENTRO da árvore do React Router.
 *
 * Hierarquia de renderização:
 *   RouterProvider
 *   └─ RootLayout  ← AuthProvider vive aqui
 *      ├─ /login   → <Login />
 *      └─ /        → <Root />   (guard de autenticação)
 *         ├─ index → <Dashboard />
 *         ├─ /site/:id → <SiteDetails />
 *         └─ ... demais rotas protegidas
 */
function RootLayout() {
  return (
    <AuthProvider>
      <Outlet />
    </AuthProvider>
  );
}

export const router = createBrowserRouter([
  {
    // Rota raiz: funciona como layout que envolve TUDO com AuthProvider
    path: '/',
    Component: RootLayout,
    children: [
      // Rota pública — acessível sem autenticação
      { path: 'login', Component: Login },

      // Rota protegida — Root.tsx verifica autenticação e redireciona para /login se necessário
      {
        path: '/',
        Component: Root,
        children: [
          { index: true,                    Component: Dashboard },
          { path: 'site/:id',               Component: SiteDetails },
          { path: 'instructions',           Component: Instructions },
          { path: 'crm',                    Component: CRM },
          { path: 'crm/clientes',           Component: CRM },
          { path: 'crm/copy-prospect',      Component: CopyProspect },
          { path: 'social-media',           Component: SocialMedia },
          { path: 'social-media/repository',Component: SocialMediaRepository },
          { path: 'quotes',                 Component: Quotes },
          { path: 'tasks',                  Component: Tasks },
          { path: 'financeiro',             Component: Financeiro },
          { path: 'pdf-syntax',             Component: PdfSyntax },
          { path: 'users',                  Component: UserManagement },
        ],
      },
    ],
  },
]);
