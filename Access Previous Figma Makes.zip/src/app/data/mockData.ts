import type { Site } from "../types";

export const mockSites: Site[] = [
  {
    id: "1",
    name: "TechCorp",
    url: "https://techcorp.com.br",
    status: "active",
    client: {
      name: "TechCorp Soluções",
      email: "contato@techcorp.com.br",
      phone: "(11) 98765-4321",
    },
    analytics: {
      totalVisits: 45230,
      uniqueVisitors: 12450,
      bounceRate: 42.3,
      avgSessionDuration: "3m 24s",
      trend: 12.5,
    },
    lastUpdated: "2026-03-10T14:30:00Z",
  },
  {
    id: "2",
    name: "StyleHub",
    url: "https://stylehub.com.br",
    status: "active",
    client: {
      name: "StyleHub Fashion",
      email: "info@stylehub.com.br",
      phone: "(21) 97654-3210",
    },
    analytics: {
      totalVisits: 32150,
      uniqueVisitors: 8920,
      bounceRate: 38.7,
      avgSessionDuration: "4m 12s",
      trend: 8.3,
    },
    lastUpdated: "2026-03-11T09:15:00Z",
  },
  {
    id: "3",
    name: "FoodLab",
    url: "https://foodlab.com.br",
    status: "maintenance",
    client: {
      name: "FoodLab Restaurante",
      email: "contato@foodlab.com.br",
      phone: "(11) 96543-2109",
    },
    analytics: {
      totalVisits: 18760,
      uniqueVisitors: 5240,
      bounceRate: 45.2,
      avgSessionDuration: "2m 48s",
      trend: -3.2,
    },
    lastUpdated: "2026-03-09T16:45:00Z",
  },
  {
    id: "4",
    name: "HealthPlus",
    url: "https://healthplus.com.br",
    status: "active",
    client: {
      name: "HealthPlus Clínica",
      email: "atendimento@healthplus.com.br",
      phone: "(11) 95432-1098",
    },
    analytics: {
      totalVisits: 28940,
      uniqueVisitors: 7830,
      bounceRate: 35.8,
      avgSessionDuration: "5m 06s",
      trend: 15.7,
    },
    lastUpdated: "2026-03-12T11:20:00Z",
  },
  {
    id: "5",
    name: "EduSpace",
    url: "https://eduspace.com.br",
    status: "active",
    client: {
      name: "EduSpace Educação",
      email: "contato@eduspace.com.br",
      phone: "(11) 94321-0987",
    },
    analytics: {
      totalVisits: 52380,
      uniqueVisitors: 15670,
      bounceRate: 29.4,
      avgSessionDuration: "6m 32s",
      trend: 22.1,
    },
    lastUpdated: "2026-03-11T18:00:00Z",
  },
  {
    id: "6",
    name: "AutoMax",
    url: "https://automax.com.br",
    status: "active",
    client: {
      name: "AutoMax Veículos",
      email: "vendas@automax.com.br",
      phone: "(11) 93210-9876",
    },
    analytics: {
      totalVisits: 21560,
      uniqueVisitors: 6340,
      bounceRate: 41.5,
      avgSessionDuration: "3m 54s",
      trend: 5.8,
    },
    lastUpdated: "2026-03-10T13:30:00Z",
  },
];

export function generateWeeklyData() {
  return [
    { day: "Seg", visitors: 1240 },
    { day: "Ter", visitors: 1580 },
    { day: "Qua", visitors: 1920 },
    { day: "Qui", visitors: 1750 },
    { day: "Sex", visitors: 2100 },
    { day: "Sáb", visitors: 890 },
    { day: "Dom", visitors: 720 },
  ];
}

export function generateDeviceData() {
  return [
    { name: "Desktop", value: 45 },
    { name: "Mobile", value: 40 },
    { name: "Tablet", value: 12 },
    { name: "Outros", value: 3 },
  ];
}

export function generatePageViewsData() {
  return [
    { page: "/home", views: 5240 },
    { page: "/produtos", views: 3890 },
    { page: "/sobre", views: 2150 },
    { page: "/contato", views: 1680 },
    { page: "/blog", views: 1420 },
  ];
}
