/**
 * auth.ts — Utilitário centralizado de autenticação para chamadas ao backend.
 *
 * FONTE DA VERDADE: getLiveSession() do AuthContext
 * ─────────────────────────────────────────────────────────────────────────────
 *
 * BUGS CORRIGIDOS nesta versão:
 *
 * BUG 1 — Double-consume do refresh token (single-use)
 * ─────────────────────────────────────────────────────
 * Versões anteriores chamavam doRefresh() de DOIS lugares:
 *   a) getToken() — proativamente, quando token expirado
 *   b) fetchWithAuth() — reativamente, no 401
 *
 * Sequência problemática:
 *   1. getToken() → token expirado → doRefresh() #1 → refreshSession() → OK
 *      → TOKEN_REFRESHED → _liveSession = freshToken1
 *   2. getToken() retorna freshToken1
 *   3. fetchWithAuth: initialToken = freshToken1
 *   4. Attempt 1 com freshToken1 → 401 (clock skew ou gateway rejeitou)
 *   5. liveToken = _liveSession.access_token = freshToken1 = initialToken
 *   6. liveToken !== initialToken → FALSE → doRefresh() #2 → refreshSession()
 *   7. "Auth session missing!" (refresh token já consumido em #1)
 *
 * SOLUÇÃO: getToken() NUNCA chama doRefresh(). Apenas aguarda TOKEN_REFRESHED
 * (auto-refresh do SDK). doRefresh() é chamado APENAS de fetchWithAuth(), de
 * forma deduplicada. Isso garante no máximo 1 refreshSession() por ciclo.
 *
 * BUG 2 — Token quase-expirado aceito pelo cliente, rejeitado pelo gateway
 * ──────────────────────────────────────────────────────────────────────────
 * O gateway do Supabase valida a expiração do JWT. Tokens com < ~30s restantes
 * podem ser rejeitados por clock-skew entre cliente e servidor.
 *
 * SOLUÇÃO: getToken() considera tokens com < TOKEN_EXPIRY_BUFFER_SECS como
 * "efetivamente expirados" e aguarda o auto-refresh do SDK.
 *
 * ─────────────────────────────────────────────────────────────────────────────
 */

import { supabase, getLiveSession } from '../context/AuthContext';
import { publicAnonKey } from '/utils/supabase/info';

// Tokens com menos de 60s restantes são tratados como expirados.
// Margem de segurança contra clock-skew entre cliente e gateway Supabase.
const TOKEN_EXPIRY_BUFFER_SECS = 60;

// ─── Helpers ──────────────────────────────────────────────────────────────────

function decodeJwtPayload(jwt: string): Record<string, unknown> | null {
  try {
    const parts = jwt.split('.');
    if (parts.length !== 3) return null;
    const b64 = parts[1].replace(/-/g, '+').replace(/_/g, '/');
    const padded = b64 + '='.repeat((4 - (b64.length % 4)) % 4);
    return JSON.parse(atob(padded));
  } catch {
    return null;
  }
}

/** True se o JWT tem `sub` (user JWT). O anon key não tem `sub`. */
function isUserJwt(jwt: string): boolean {
  const p = decodeJwtPayload(jwt);
  return typeof p?.sub === 'string' && (p.sub as string).length > 0;
}

/**
 * Segundos até expirar. Negativo = já expirado.
 * Subtrai TOKEN_EXPIRY_BUFFER_SECS para margem de clock-skew.
 */
function secsUntilExpiry(jwt: string, bufferSecs = 0): number {
  const p = decodeJwtPayload(jwt);
  if (typeof p?.exp !== 'number') return Infinity;
  return (p.exp as number) - Math.floor(Date.now() / 1000) - bufferSecs;
}

/** True se o token está expirado (com buffer de segurança). */
function isTokenEffectivelyExpired(jwt: string): boolean {
  return secsUntilExpiry(jwt, TOKEN_EXPIRY_BUFFER_SECS) <= 0;
}

const sleep = (ms: number) => new Promise<void>((r) => setTimeout(r, ms));

// ─── Refresh deduplicado ──────────────────────────────────────────────────────

/**
 * Promise compartilhado entre chamadas concorrentes.
 * Garante no máximo 1 refreshSession() em andamento ao mesmo tempo.
 * Refresh tokens são single-use — chamadas concorrentes compartilham o
 * resultado em vez de consumir o token mais de uma vez.
 */
let _refreshPromise: Promise<string | null> | null = null;

/**
 * Chama refreshSession() de forma deduplicada.
 * Retorna o novo access_token ou null em caso de falha.
 *
 * ÚNICO lugar que chama refreshSession(). Chamado APENAS de fetchWithAuth().
 * getToken() NÃO chama esta função (vide BUG 1 no cabeçalho).
 */
async function doRefresh(): Promise<string | null> {
  if (_refreshPromise) {
    console.log('[Auth] Aguardando refresh já em andamento…');
    return _refreshPromise;
  }

  _refreshPromise = (async (): Promise<string | null> => {
    try {
      console.log('[Auth] Chamando refreshSession()…');
      const { data, error } = await supabase.auth.refreshSession();
      if (error || !data.session) {
        console.warn('[Auth] refreshSession falhou:', error?.message ?? 'sem sessão');
        return null;
      }
      console.log('[Auth] Token renovado com sucesso.');
      return data.session.access_token;
    } catch (e) {
      console.error('[Auth] Exceção em refreshSession:', e);
      return null;
    }
  })();

  // Limpar a referência após resolve/reject para permitir nova chamada futura
  _refreshPromise.finally(() => {
    _refreshPromise = null;
  });

  return _refreshPromise;
}

// ─── Polling para novo token ──────────────────────────────────────────────────

/**
 * Aguarda até `maxMs` para _liveSession ter um token diferente do `oldToken`
 * e efetivamente não-expirado (com buffer de clock-skew).
 * Polling a cada 100ms. Retorna o novo token ou null se timeout.
 */
async function waitForFreshToken(oldToken: string, maxMs: number): Promise<string | null> {
  const start = Date.now();
  while (Date.now() - start < maxMs) {
    await sleep(100);
    const fresh = getLiveSession()?.access_token;
    if (
      fresh &&
      fresh !== oldToken &&
      isUserJwt(fresh) &&
      !isTokenEffectivelyExpired(fresh)
    ) {
      return fresh;
    }
  }
  return null;
}

// ─── getToken ─────────────────────────────────────────────────────────────────

/**
 * Retorna o token atual de _liveSession.
 *
 * Se o token está quase-expirado (< TOKEN_EXPIRY_BUFFER_SECS), aguarda até
 * 4s para o SDK auto-refresh atualizar _liveSession via TOKEN_REFRESHED.
 * Se não chegar no tempo, retorna o token como está (potencialmente expirado)
 * e deixa fetchWithAuth() tratar o 401 com doRefresh().
 *
 * IMPORTANTE: Esta função NUNCA chama doRefresh(). Vide BUG 1 no cabeçalho.
 */
export async function getToken(): Promise<string> {
  const session = getLiveSession();
  const token = session?.access_token;

  if (!token || !isUserJwt(token)) return publicAnonKey;

  // Token com folga suficiente — caso mais comum, retorna diretamente
  if (!isTokenEffectivelyExpired(token)) return token;

  // Token expirado ou quase-expirado: aguardar o auto-refresh do SDK
  const secsLeft = secsUntilExpiry(token);
  console.warn(
    `[Auth] Token com ${secsLeft}s restantes (abaixo do buffer de ${TOKEN_EXPIRY_BUFFER_SECS}s) ` +
    `— aguardando auto-refresh do SDK…`
  );

  // Aguardar TOKEN_REFRESHED atualizar _liveSession (máximo 4s)
  const freshToken = await waitForFreshToken(token, 4000);
  if (freshToken) {
    console.log('[Auth] Auto-refresh do SDK concluído — usando novo token.');
    return freshToken;
  }

  // SDK não renovou no tempo: retornar o token atual e deixar
  // fetchWithAuth() chamar doRefresh() em caso de 401.
  console.warn(
    '[Auth] SDK não renovou em 4s — enviando token atual. ' +
    'fetchWithAuth() fará doRefresh() se necessário.'
  );
  return getLiveSession()?.access_token ?? publicAnonKey;
}

// ─── getAuthHeaders ───────────────────────────────────────────────────────────

export async function getAuthHeaders(
  includeContentType = true,
): Promise<Record<string, string>> {
  const token = await getToken();
  return {
    ...(includeContentType ? { 'Content-Type': 'application/json' } : {}),
    apikey: publicAnonKey,
    Authorization: `Bearer ${token}`,
  };
}

// ─── fetchWithAuth ─────────────────────────────────────────────────────────────

/**
 * Substituto do fetch() que injeta headers JWT e trata 401 com retry.
 *
 * Fluxo em caso de 401:
 *   1. Aguardar 300ms → TOKEN_REFRESHED pode ter chegado enquanto o request
 *      estava em voo (SDK auto-refreshing concorrentemente).
 *   2. Se _liveSession já tem um token diferente e válido: retentar com ele
 *      SEM chamar doRefresh() (evita double-consume do refresh token).
 *   3. Se _liveSession ainda tem o mesmo token (ou inválido): chamar doRefresh()
 *      UMA VEZ (deduplicado). Falha → signOut, retorna 401.
 *   4. Retry com freshToken. Se ainda 401: sessão revogada → signOut.
 *
 * INVARIANTE: doRefresh() é chamado no máximo UMA VEZ por ciclo de request.
 * getToken() nunca chama doRefresh(), então não há risco de double-consume.
 */
export async function fetchWithAuth(
  url: string,
  options: RequestInit = {},
): Promise<Response> {
  const isFormData = options.body instanceof FormData;
  const authHeaders = await getAuthHeaders(!isFormData);

  const initialToken = authHeaders.Authorization.replace('Bearer ', '');
  const startedWithUserJwt = isUserJwt(initialToken);

  const callerHeaders: Record<string, string> =
    options.headers instanceof Headers
      ? Object.fromEntries((options.headers as Headers).entries())
      : ((options.headers ?? {}) as Record<string, string>);

  // Auth headers sobrescrevem caller para apikey e Authorization
  const headers: Record<string, string> = { ...callerHeaders, ...authHeaders };

  const makeOpts = (hdrs: Record<string, string>): RequestInit => ({
    ...options,
    headers: hdrs,
  });

  // ── Attempt 1 ─────────────────────────────────────────────────────────────
  let res = await fetch(url, makeOpts(headers));
  if (res.status !== 401) return res;

  const body1 = await res.clone().json().catch(() => ({}));
  console.warn(`[Auth] 401 em attempt 1 → ${url}`, body1);

  // Sem user JWT: anon key foi rejeitado — nada a renovar
  if (!startedWithUserJwt) {
    console.error(`[Auth] 401 com anon key → ${url} — usuário não autenticado.`);
    return res;
  }

  // ── Aguardar TOKEN_REFRESHED que pode estar em voo ─────────────────────────
  // O SDK pode ter iniciado um auto-refresh concorrentemente ao request.
  // Aguardar 300ms antes de verificar _liveSession.
  await sleep(300);

  // ── Verificar se _liveSession já foi atualizado pelo SDK ──────────────────
  // CRÍTICO: Ler de _liveSession (fonte: onAuthStateChange), NUNCA de
  // supabase.auth.getSession() (fonte: localStorage, pode ser stale).
  let freshToken: string | null = null;
  const liveToken = getLiveSession()?.access_token;

  if (
    liveToken &&
    liveToken !== initialToken &&
    isUserJwt(liveToken) &&
    !isTokenEffectivelyExpired(liveToken)
  ) {
    // SDK já atualizou _liveSession enquanto o request estava em voo
    console.log('[Auth] _liveSession atualizada pelo SDK — retentando com novo token.');
    freshToken = liveToken;
  } else {
    // SDK não atualizou — fazer refresh manual (deduplicado, single-use safe)
    freshToken = await doRefresh();
    if (!freshToken) {
      console.error('[Auth] Refresh falhou após 401 — fazendo signOut.');
      await supabase.auth.signOut().catch(() => {});
      return res;
    }
  }

  // ── Attempt 2 ─────────────────────────────────────────────────────────────
  headers.Authorization = `Bearer ${freshToken}`;
  res = await fetch(url, makeOpts(headers));

  if (res.status === 401) {
    const body2 = await res.clone().json().catch(() => ({}));
    console.error(`[Auth] Ainda 401 após refresh → ${url}`, body2);
    // Token recém-emitido também rejeitado → sessão revogada server-side
    await supabase.auth.signOut().catch(() => {});
  }

  return res;
}
