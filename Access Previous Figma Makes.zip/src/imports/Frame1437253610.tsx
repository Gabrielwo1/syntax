import imgFreepikReateAModernFuturisticLogoForAUxuiDesignA417041 from "figma:asset/315d8cb9df218a4d108c1796691e847942e27f6b.png";

export default function Frame() {
  return (
    <div className="content-stretch flex items-center relative size-full">
      <div className="h-[188.292px] relative shrink-0 w-[128.381px]" data-name="freepik__reate-a-modern-futuristic-logo-for-a-uxui-design-a__41704 1">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-[364.55%] left-[-93.33%] max-w-none top-[-132.27%] w-[534.67%]" src={imgFreepikReateAModernFuturisticLogoForAUxuiDesignA417041} />
        </div>
      </div>
      <div className="h-[188.292px] relative shrink-0 w-[352.619px]" data-name="freepik__reate-a-modern-futuristic-logo-for-a-uxui-design-a__41704 2">
        <div className="absolute inset-0 overflow-hidden pointer-events-none">
          <img alt="" className="absolute h-[364.55%] left-[-72.33%] max-w-none top-[-132.27%] w-[194.66%]" src={imgFreepikReateAModernFuturisticLogoForAUxuiDesignA417041} />
        </div>
      </div>
    </div>
  );
}